/* مطالعۂ قرآن (login version) — offline cache. Bump CACHE_NAME whenever any file changes. */
const CACHE_NAME = 'mq-login-v1';
const PRECACHE = [
 "./",
 "404.html",
 "about.html",
 "assets/css/style.css",
 "assets/data/config.js",
 "assets/data/registry.js",
 "assets/fonts/README.txt",
 "assets/icons/icon-192.png",
 "assets/icons/icon-512.png",
 "assets/img/me.jpg",
 "assets/js/auth.js",
 "assets/js/core.js",
 "assets/js/firebase-config.js",
 "assets/js/gate.js",
 "assets/js/pages.js",
 "assets/js/practice.js",
 "assets/js/shell.js",
 "bookmarks.html",
 "index.html",
 "manifest.json",
 "me.html",
 "privacy.html",
 "revision.html",
 "search.html",
 "section.html",
 "terms.html",
 "test.html"
];
/* fonts + icon font come from CDNs (same as the reference portal); cache them too so the site works offline after the first visit */
const CDN_HOSTS = ['fonts.googleapis.com', 'fonts.gstatic.com', 'cdn.jsdelivr.net', 'www.gstatic.com'];
const CDN_PRECACHE = [
  'https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;600;700&family=Amiri+Quran&display=swap',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css'
];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE_NAME).then(c => Promise.all(PRECACHE.concat(CDN_PRECACHE).map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(k => Promise.all(k.filter(n => n.indexOf('mq-login-') === 0 && n !== CACHE_NAME).map(n => caches.delete(n)))).then(() => self.clients.claim())); });
/* stale-while-revalidate for same-origin GETs; page URLs match regardless of ?id=… */
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url); if (r.method !== 'GET' || (u.origin !== location.origin && !CDN_HOSTS.includes(u.hostname))) return;
  e.respondWith(caches.open(CACHE_NAME).then(async c => {
    const hit = await c.match(r, { ignoreSearch: r.mode === 'navigate' });
    const net = fetch(r).then(res => { if (res && (res.ok || res.type === 'opaque')) c.put(r, res.clone()); return res; }).catch(() => null);
    return hit || (await net) || (r.mode === 'navigate' ? c.match('index.html') : Response.error());
  }));
});
