/* Mutalea Quran — admin console. Realtime dashboard over Firestore: users, notifications, audit log, settings, content. */
const CFG = window.MQ_FIREBASE, B = 'https://www.gstatic.com/firebasejs/10.12.2/';
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let A, S, AP;
try { A = await import(B + 'firebase-auth.js'); S = await import(B + 'firebase-firestore.js'); AP = await import(B + 'firebase-app.js'); }
catch (e) { $('boot').innerHTML = '<p style="padding:20px;text-align:center">Could not load Firebase. Check your internet and reload.</p>'; throw e; }
const { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithEmailAndPassword, signOut } = A;
const { initializeFirestore, collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, addDoc, writeBatch, serverTimestamp, onSnapshot, query, orderBy, limit, Timestamp } = S;
const app = AP.initializeApp(CFG), auth = getAuth(app), db = initializeFirestore(app, {});
const isAdmin = u => !!(u && u.email && u.email.toLowerCase() === CFG.adminEmail.toLowerCase());

/* ---------- helpers ---------- */
const ms = t => (t && typeof t.toMillis === 'function') ? t.toMillis() : (t && t.seconds ? t.seconds * 1000 : 0);
const D = t => { const m = typeof t === 'number' ? t : ms(t); return m ? new Date(m).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '—'; };
const DT = t => { const m = typeof t === 'number' ? t : ms(t); return m ? new Date(m).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'; };
const ago = t => { const m = typeof t === 'number' ? t : ms(t); if (!m) return 'never'; const s = Math.max(0, (Date.now() - m) / 1000); if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago'; if (s < 86400) return Math.floor(s / 3600) + ' h ago'; if (s < 86400 * 30) return Math.floor(s / 86400) + ' d ago'; return D(m); };
const nameOf = u => u.name || u.username || (u.email || '').split('@')[0] || 'Unnamed';
const init = u => (nameOf(u).trim()[0] || '?').toUpperCase();
const hue = s => { let h = 0; for (const c of String(s)) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
const av = (u, cls) => `<div class="avatar ${cls || ''}" style="background:hsl(${hue(u.email || u.id)} 45% 42%)">${esc(init(u))}</div>`;
const dispEmail = u => (u.email || '').endsWith('@mq-students.app') ? '@' + (u.username || u.email.split('@')[0]) : (u.email || '');
const DAY = 864e5;
const effStatus = u => (u.status === 'approved' && ms(u.expiresAt) && ms(u.expiresAt) < Date.now()) ? 'expired' : (u.status || 'pending');
const online = u => Date.now() - ms(u.lastSeen) < 5 * 60e3;
const BADGE = { pending: ['t-warn', 'Pending'], approved: ['t-ok', 'Approved'], blocked: ['t-bad', 'Blocked'], expired: ['t-info', 'Expired'] };
const badge = s => `<span class="badge ${BADGE[s][0]}">${BADGE[s][1]}</span>`;
const dl = (name, text, type) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); };
const errMsg = e => (e && (e.code || e.message)) || 'error';

/* toasts, confirm, sheet */
function toast(t, err) {
  const el = document.createElement('div'); el.className = 'tst' + (err ? ' err' : ''); el.innerHTML = `<i class="bi ${err ? 'bi-exclamation-circle' : 'bi-check-circle'}"></i>${esc(t)}`;
  $('toasts').appendChild(el); setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, err ? 4800 : 2600);
}
function confirmBox(title, text, okLabel, danger) {
  return new Promise(res => {
    const m = $('modal'); m.innerHTML = `<h3>${esc(title)}</h3><p>${esc(text)}</p><div class="row" style="justify-content:flex-end"><button class="btn" id="cNo">Cancel</button><button class="btn ${danger ? 'bad' : 'pri'}" id="cYes">${esc(okLabel || 'Confirm')}</button></div>`;
    m.classList.add('on'); $('scrim').classList.add('on');
    const done = v => { m.classList.remove('on'); if (!$('sheet').classList.contains('on')) $('scrim').classList.remove('on'); res(v); };
    $('cNo').onclick = () => done(false); $('cYes').onclick = () => done(true);
  });
}
function openSheet(html) { $('sheet').innerHTML = '<div class="grab"></div>' + html; $('sheet').classList.add('on'); $('scrim').classList.add('on'); }
function closeSheet() { $('sheet').classList.remove('on'); if (!$('modal').classList.contains('on')) $('scrim').classList.remove('on'); }
$('scrim').onclick = () => { if (!$('modal').classList.contains('on')) { closeSheet(); closeCmd(); } };
async function busy(btn, fn) {
  if (!btn) return fn(); const h = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<span class="sp"></span>';
  try { return await fn(); } finally { btn.disabled = false; btn.innerHTML = h; }
}

/* ---------- state ---------- */
const st = { users: [], notifs: [], audit: [], site: {}, theme: {}, content: null, page: 'dashboard', filter: 'all', q: '', sort: 'new', sel: new Set(), selMode: false, shown: 30, range: 30, ready: false, me: null, fb: [], prog: null, progAt: 0 };
const PAGES = [
  ['dashboard', 'Dashboard', 'bi-grid-1x2', 'Overview of your students'],
  ['students', 'Students', 'bi-people', 'Approve, edit and manage accounts'],
  ['insights', 'Insights', 'bi-bar-chart-line', 'Activity, popular lessons and expiring accounts'],
  ['notify', 'Notifications', 'bi-megaphone', 'Send messages to every student'],
  ['feedback', 'Feedback', 'bi-flag', 'Mistake reports from students'],
  ['content', 'Content', 'bi-journal-text', 'Lessons stored in the protected database'],
  ['activity', 'Activity', 'bi-clock-history', 'Audit log of admin actions'],
  ['settings', 'Settings', 'bi-sliders', 'Access, colours and backups']
];
const pending = () => st.users.filter(u => effStatus(u) === 'pending');
function audit(action, target, detail) { return addDoc(collection(db, 'audit'), { action, target: target || '', detail: detail || '', by: st.me.email, at: serverTimestamp() }).catch(() => {}); }

/* ---------- auth ---------- */
const showLogin = (err, note) => { $('boot').classList.add('hide'); $('app').classList.add('hide'); $('login').classList.remove('hide'); const e = $('lErr'); e.textContent = err || ''; e.classList.toggle('hide', !err); $('lNote').textContent = note || ''; };
$('gBtn').onclick = () => busy($('gBtn'), async () => { try { await signInWithPopup(auth, new GoogleAuthProvider()); } catch (e) { if (e.code !== 'auth/popup-closed-by-user') showLogin('Sign-in failed: ' + errMsg(e)); } });
$('lForm').onsubmit = ev => { ev.preventDefault(); busy($('lBtn'), async () => { try { await signInWithEmailAndPassword(auth, $('lEmail').value.trim(), $('lPass').value); } catch (e) { showLogin(e.code === 'auth/invalid-credential' ? 'Wrong email or password.' : 'Sign-in failed: ' + errMsg(e)); } }); };
const out = () => signOut(auth).then(() => location.reload());
$('sbOut').onclick = out; $('outBtn').onclick = out;
onAuthStateChanged(auth, u => {
  if (!u) { showLogin(); return; }
  if (!isAdmin(u)) { signOut(auth); showLogin('This account (' + (u.email || 'unknown') + ') is not the admin account.'); return; }
  st.me = u; if (!st.ready) { st.ready = true; boot(); }
});

/* ---------- shell ---------- */
function boot() {
  $('login').classList.add('hide'); $('app').classList.remove('hide'); $('boot').classList.add('hide');
  $('sbName').textContent = st.me.email; $('sbAv').style.background = 'hsl(150 45% 38%)'; $('sbAv').textContent = (st.me.email[0] || 'A').toUpperCase();
  $('nav').innerHTML = PAGES.map(p => `<button data-go="${p[0]}"><i class="bi ${p[2]}"></i>${p[1]}${p[0] === 'students' ? '<span class="cnt hide" id="navCnt">0</span>' : p[0] === 'feedback' ? '<span class="cnt hide" id="fbCnt">0</span>' : ''}</button>`).join('');
  const BN = ['dashboard', 'students', 'insights', 'notify'];
  $('bnav').innerHTML = PAGES.filter(p => BN.includes(p[0])).map(p => `<button data-go="${p[0]}"><i class="bi ${p[2]}"></i>${p[1] === 'Notifications' ? 'Notify' : p[1]}${p[0] === 'students' ? '<span class="cnt hide" id="bnCnt">0</span>' : ''}</button>`).join('') + '<button id="bMore"><i class="bi bi-three-dots"></i>More<span class="cnt hide" id="bmCnt">0</span></button>';
  document.querySelectorAll('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));
  $('bMore').onclick = () => { openSheet('<h3 style="margin:0 0 8px">More</h3>' + PAGES.filter(p => !BN.includes(p[0])).map(p => `<button class="btn full" style="justify-content:flex-start;margin-bottom:8px" data-mgo="${p[0]}"><i class="bi ${p[2]}"></i>${p[1]}</button>`).join('')); $('sheet').querySelectorAll('[data-mgo]').forEach(b => b.onclick = () => go(b.dataset.mgo)); };
  $('cmdBtn').onclick = openCmd; $('thBtn').onclick = toggleTheme; $('pendBtn').onclick = () => { st.filter = 'pending'; go('students'); };
  syncTheme();
  const L = (q, fn) => onSnapshot(q, fn, e => toast('Live update failed: ' + errMsg(e), true));
  L(query(collection(db, 'feedback'), orderBy('createdAt', 'desc'), limit(100)), s => { st.fb = s.docs.map(d => ({ id: d.id, ...d.data() })); counts(); refresh(); });
  L(collection(db, 'users'), s => { st.users = s.docs.map(d => ({ id: d.id, ...d.data() })); st.usersReady = true; counts(); refresh(); });
  L(query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), limit(60)), s => { st.notifs = s.docs.map(d => ({ id: d.id, ...d.data() })); refresh(); });
  L(query(collection(db, 'audit'), orderBy('at', 'desc'), limit(150)), s => { st.audit = s.docs.map(d => ({ id: d.id, ...d.data() })); refresh(); });
  L(doc(db, 'settings', 'site'), s => { st.site = s.exists() ? s.data() : {}; refresh(); });
  L(doc(db, 'settings', 'theme'), s => { st.theme = s.exists() ? s.data() : {}; if (st.page === 'settings') syncSettings(); });
  go(location.hash.slice(1) && PAGES.some(p => p[0] === location.hash.slice(1)) ? location.hash.slice(1) : 'dashboard');
}
function counts() {
  const n = pending().length;
  ['pendN'].forEach(i => { $(i).textContent = n; $(i).classList.toggle('hide', !n); });
  ['navCnt', 'bnCnt'].forEach(i => { const e = $(i); if (e) { e.textContent = n; e.classList.toggle('hide', !n); } });
  const fn = (st.fb || []).filter(x => x.status !== 'done').length;
  ['fbCnt', 'bmCnt'].forEach(i => { const e = $(i); if (e) { e.textContent = fn; e.classList.toggle('hide', !fn); } });
}
function go(p) {
  st.page = p; location.hash = p; closeSheet();
  document.querySelectorAll('[data-go]').forEach(b => b.classList.toggle('on', b.dataset.go === p));
  const pg = PAGES.find(x => x[0] === p); $('pgT').textContent = pg[1]; $('pgS').textContent = pg[3];
  st.sel.clear(); st.selMode = false; st.shown = 30; $('view').innerHTML = ''; ({ dashboard: vDash, students: vStudents, insights: vInsights, notify: vNotify, feedback: vFeedback, content: vContent, activity: vActivity, settings: vSettings })[p](); window.scrollTo(0, 0);
}
function refresh() { if (!st.ready) return; counts(); ({ dashboard: vDash, students: lStudents, insights: () => { }, notify: lNotifs, feedback: lFeedback, content: () => { }, activity: lActivity, settings: syncSettings })[st.page](); }
const skeleton = n => Array.from({ length: n }, () => '<div class="skel"></div>').join('');
function syncTheme() { const d = document.documentElement.getAttribute('data-theme') === 'dark'; $('thBtn').innerHTML = `<i class="bi ${d ? 'bi-sun' : 'bi-moon-stars'}"></i>`; }
function toggleTheme() { const d = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', d); try { localStorage.setItem('mq_admin_theme', d); } catch (e) { } syncTheme(); if (st.page === 'dashboard') vDash(); }

/* ---------- dashboard ---------- */
function signupSeries(days) {
  const end = new Date(); end.setHours(0, 0, 0, 0); const t0 = end.getTime() - (days - 1) * DAY, arr = new Array(days).fill(0);
  st.users.forEach(u => { const c = ms(u.createdAt); if (c >= t0) arr[Math.min(days - 1, Math.floor((c - t0) / DAY))]++; });
  return { arr, t0 };
}
function chartSvg(arr, t0) {
  const W = 600, H = 190, P = { l: 28, r: 8, t: 12, b: 22 }, mx = Math.max(3, ...arr), n = arr.length;
  const x = i => P.l + (n === 1 ? 0 : i * (W - P.l - P.r) / (n - 1)), y = v => H - P.b - v / mx * (H - P.t - P.b);
  const pts = arr.map((v, i) => [x(i), y(v)]);
  let d = 'M' + pts[0][0] + ',' + pts[0][1];
  for (let i = 1; i < n; i++) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], cx = (x0 + x1) / 2; d += ` C${cx},${y0} ${cx},${y1} ${x1},${y1}`; }
  const area = d + ` L${x(n - 1)},${H - P.b} L${x(0)},${H - P.b}Z`;
  const grid = [0, .5, 1].map(f => { const yy = P.t + (1 - f) * (H - P.t - P.b); return `<line x1="${P.l}" x2="${W - P.r}" y1="${yy}" y2="${yy}" style="stroke:var(--line)" stroke-dasharray="3 4"/><text x="${P.l - 6}" y="${yy + 4}" text-anchor="end" font-size="11" style="fill:var(--mut)">${Math.round(mx * f)}</text>`; }).join('');
  const lab = i => { const dt = new Date(t0 + i * DAY); return dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }); };
  const xs = [0, Math.floor((n - 1) / 2), n - 1].map((i, k) => `<text x="${x(i)}" y="${H - 4}" text-anchor="${k === 0 ? 'start' : k === 2 ? 'end' : 'middle'}" font-size="11" style="fill:var(--mut)">${lab(i)}</text>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" id="chSvg" role="img" aria-label="Sign-ups per day"><defs><linearGradient id="ga" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--pri);stop-opacity:.35"/><stop offset="1" style="stop-color:var(--pri);stop-opacity:0"/></linearGradient></defs>${grid}<path d="${area}" fill="url(#ga)"/><path d="${d}" fill="none" style="stroke:var(--pri)" stroke-width="2.5" stroke-linecap="round"/>${xs}<line id="chLine" y1="${P.t}" y2="${H - P.b}" style="stroke:var(--pri)" stroke-width="1" opacity="0"/><circle id="chDot" r="5" style="fill:var(--card);stroke:var(--pri)" stroke-width="2.5" opacity="0"/></svg><div class="tip" id="chTip"></div>`;
}
function hookChart(arr, t0) {
  const svg = $('chSvg'); if (!svg) return; const W = 600, H = 190, P = { l: 28, r: 8, t: 12, b: 22 }, n = arr.length, mx = Math.max(3, ...arr);
  const mv = ev => {
    const r = svg.getBoundingClientRect(), px = (ev.clientX - r.left) / r.width * W; let i = Math.round((px - P.l) / ((W - P.l - P.r) / (n - 1))); i = Math.max(0, Math.min(n - 1, i));
    const xx = P.l + i * (W - P.l - P.r) / (n - 1), yy = H - P.b - arr[i] / mx * (H - P.t - P.b);
    $('chLine').setAttribute('x1', xx); $('chLine').setAttribute('x2', xx); $('chLine').setAttribute('opacity', 1); $('chDot').setAttribute('cx', xx); $('chDot').setAttribute('cy', yy); $('chDot').setAttribute('opacity', 1);
    const tip = $('chTip'); tip.textContent = new Date(t0 + i * DAY).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) + ' · ' + arr[i] + ' sign-up' + (arr[i] === 1 ? '' : 's'); tip.style.left = (xx / W * 100) + '%'; tip.style.top = (yy / H * 100) + '%'; tip.style.opacity = 1;
  };
  svg.addEventListener('pointermove', mv); svg.addEventListener('pointerdown', mv); svg.addEventListener('pointerleave', () => { $('chTip').style.opacity = 0; $('chLine').setAttribute('opacity', 0); $('chDot').setAttribute('opacity', 0); });
}
function donut(parts) {
  const tot = parts.reduce((a, p) => a + p[1], 0) || 1; let off = 25;
  const rings = parts.map(p => { const pc = p[1] / tot * 100, s = `<circle r="15.9155" cx="21" cy="21" fill="none" stroke="${p[2]}" stroke-width="5.5" stroke-dasharray="${pc} ${100 - pc}" stroke-dashoffset="${off}"/>`; off -= pc; return s; }).join('');
  return `<svg viewBox="0 0 42 42" width="132" height="132" role="img" aria-label="Students by status"><circle r="15.9155" cx="21" cy="21" fill="none" style="stroke:var(--line)" stroke-width="5.5"/>${rings}<text x="21" y="22.5" text-anchor="middle" font-size="7.5" font-weight="700" style="fill:var(--ink)">${tot === 1 && !parts.some(p => p[1]) ? 0 : parts.reduce((a, p) => a + p[1], 0)}</text><text x="21" y="28" text-anchor="middle" font-size="3.4" style="fill:var(--mut)">students</text></svg>`;
}
function vDash() {
  const U = st.users, now = Date.now(), cnt = f => U.filter(f).length;
  if (!st.usersReady) { $('view').innerHTML = `<div class="grid kpis">${skeleton(4)}</div>${skeleton(3)}`; return; }
  const pend = pending(), appr = cnt(u => effStatus(u) === 'approved'), blk = cnt(u => u.status === 'blocked'), exp = cnt(u => effStatus(u) === 'expired');
  const wk = cnt(u => ms(u.createdAt) > now - 7 * DAY), wk0 = cnt(u => { const c = ms(u.createdAt); return c > now - 14 * DAY && c <= now - 7 * DAY; });
  const on = cnt(online), a24 = cnt(u => ms(u.lastSeen) > now - DAY), a7 = cnt(u => ms(u.lastSeen) > now - 7 * DAY), paid = cnt(u => u.paid);
  const soon = cnt(u => { const e = ms(u.expiresAt); return e && e > now && e < now + 7 * DAY; });
  const delta = wk - wk0, kp = (ic, tone, n, label, extra, go) => `<button class="kpi" ${go ? `data-kgo="${go}"` : ''}><div class="ic ${tone}"><i class="bi ${ic}"></i></div><b>${n}</b><span>${label}</span>${extra || ''}</button>`;
  const ser = signupSeries(st.range), gProv = cnt(u => u.provider === 'google.com'), pProv = U.length - gProv;
  $('view').innerHTML = `
  ${pend.length ? `<div class="alert"><i class="bi bi-hourglass-split" style="font-size:1.3rem"></i><div class="grow">${pend.length} student${pend.length > 1 ? 's are' : ' is'} waiting for approval</div><button class="btn xs pri" id="dRev">Review</button></div>` : ''}
  <div class="grid kpis">
    ${kp('bi-people-fill', 't-pri', U.length, 'Total students', `<em class="${delta >= 0 ? 'up' : 'dn'}">${delta >= 0 ? '▲' : '▼'} ${Math.abs(delta)} vs last week</em>`, 'all')}
    ${kp('bi-hourglass-split', 't-warn', pend.length, 'Pending approval', '', 'pending')}
    ${kp('bi-patch-check-fill', 't-ok', appr, 'Approved', `<em class="up">+${wk} this week</em>`, 'approved')}
    ${kp('bi-broadcast', 't-info', on, 'Online now', `<em class="mut">${a24} active in 24 h</em>`, 'online')}
    ${kp('bi-calendar-check', 't-pri', a7, 'Active in 7 days', `<em class="mut">${U.length ? Math.round(a7 / U.length * 100) : 0}% of all</em>`)}
    ${kp('bi-slash-circle', 't-bad', blk, 'Blocked', '', 'blocked')}
    ${kp('bi-wallet2', 't-ok', paid, 'Marked paid', '', 'paid')}
    ${kp('bi-alarm', 't-info', exp, 'Expired', soon ? `<em class="dn">${soon} expiring in 7 d</em>` : '', 'expired')}
  </div>
  <div class="grid cols mt">
    <div class="card"><div class="row" style="margin-bottom:8px"><h2 style="margin:0"><i class="bi bi-graph-up-arrow"></i>New sign-ups</h2><div class="seg right" id="rng">${[7, 30, 90].map(r => `<button data-r="${r}" class="${st.range === r ? 'on' : ''}">${r}d</button>`).join('')}</div></div><div class="chart">${chartSvg(ser.arr, ser.t0)}</div><div class="sm mut">${ser.arr.reduce((a, b) => a + b, 0)} sign-ups in the last ${st.range} days</div></div>
    <div class="card"><h2><i class="bi bi-pie-chart"></i>Status</h2><div class="donut">${donut([['Approved', appr, 'var(--ok)'], ['Pending', pend.length, 'var(--warn)'], ['Blocked', blk, 'var(--bad)'], ['Expired', exp, 'var(--info)']])}<div class="legend">
      <div><i style="background:var(--ok)"></i>Approved<b>${appr}</b></div><div><i style="background:var(--warn)"></i>Pending<b>${pend.length}</b></div><div><i style="background:var(--bad)"></i>Blocked<b>${blk}</b></div><div><i style="background:var(--info)"></i>Expired<b>${exp}</b></div></div></div>
      <div class="sm mut mt">Sign-in method: Google ${gProv} · Username/email ${pProv}</div></div>
  </div>
  <div class="grid cols2 mt">
    <div class="card"><h2><i class="bi bi-person-plus"></i>Latest sign-ups</h2><div class="list">${[...U].sort((a, b) => ms(b.createdAt) - ms(a.createdAt)).slice(0, 6).map(u => `<div class="li" data-u="${u.id}">${av(u)}<div class="grow"><div class="nm">${esc(nameOf(u))}</div><div class="sub">${esc(dispEmail(u))}</div></div>${badge(effStatus(u))}<span class="sm mut">${ago(u.createdAt)}</span></div>`).join('') || '<div class="empty"><i class="bi bi-person"></i>No students yet</div>'}</div></div>
    <div class="card"><h2><i class="bi bi-clock-history"></i>Recent activity</h2>${actHtml(st.audit.slice(0, 6)) || '<div class="empty"><i class="bi bi-inbox"></i>Nothing yet</div>'}</div>
  </div>
  <div class="grid cols2 mt"><div class="card"><h2><i class="bi bi-lightning-charge"></i>Quick actions</h2><div class="row">
    <button class="btn pri" id="qN"><i class="bi bi-megaphone"></i>Send notification</button><button class="btn" id="qA" ${pend.length ? '' : 'disabled'}><i class="bi bi-check2-all"></i>Approve all pending (${pend.length})</button><button class="btn" id="qE"><i class="bi bi-filetype-csv"></i>Export CSV</button><button class="btn" id="qK"><i class="bi bi-command"></i>Commands</button></div></div>
    <div class="card"><h2><i class="bi bi-shield-check"></i>System</h2><div class="setrow"><div class="grow"><b>Maintenance mode</b><span class="sm mut">${st.site.maintenance ? 'ON — students see a maintenance screen' : 'Off'}</span></div><span class="badge ${st.site.maintenance ? 't-bad' : 't-ok'}">${st.site.maintenance ? 'ON' : 'OFF'}</span></div><div class="setrow"><div class="grow"><b>New sign-ups</b><span class="sm mut">${st.site.signupOpen === false ? 'Closed' : 'Open'}</span></div><span class="badge ${st.site.signupOpen === false ? 't-warn' : 't-ok'}">${st.site.signupOpen === false ? 'CLOSED' : 'OPEN'}</span></div></div></div>`;
  document.querySelectorAll('[data-kgo]').forEach(b => b.onclick = () => { const k = b.dataset.kgo; st.filter = k; go('students'); });
  document.querySelectorAll('[data-u]').forEach(b => b.onclick = () => openUser(b.dataset.u));
  document.querySelectorAll('#rng button').forEach(b => b.onclick = () => { st.range = +b.dataset.r; vDash(); });
  const q = (i, f) => { const e = $(i); if (e) e.onclick = f; };
  q('dRev', () => { st.filter = 'pending'; go('students'); }); q('qN', () => go('notify')); q('qA', approveAll); q('qE', exportCsv); q('qK', openCmd);
  hookChart(ser.arr, ser.t0);
}
function actHtml(rows) {
  const IC = { approve: ['bi-check-lg', 't-ok'], block: ['bi-slash-circle', 't-bad'], delete: ['bi-trash', 't-bad'], edit: ['bi-pencil', 't-pri'], notify: ['bi-megaphone', 't-info'], settings: ['bi-sliders', 't-warn'], content: ['bi-journal-text', 't-pri'], export: ['bi-download', 't-pri'] };
  return `<div class="timeline">${rows.map(r => { const k = IC[r.action.split('.')[0]] || ['bi-dot', 't-pri']; return `<div class="tl"><div class="d ${k[1]}"><i class="bi ${k[0]}"></i></div><div class="grow"><div style="font-weight:650">${esc(r.detail || r.action)}</div><div class="sm mut">${esc(r.target || '')}${r.target ? ' · ' : ''}${DT(r.at)}</div></div></div>`; }).join('')}</div>`;
}

/* ---------- students ---------- */
const FILTERS = [['all', 'All'], ['pending', 'Pending'], ['approved', 'Approved'], ['blocked', 'Blocked'], ['expired', 'Expired'], ['paid', 'Paid'], ['online', 'Online']];
const fMatch = (u, f) => f === 'all' ? true : f === 'paid' ? !!u.paid : f === 'online' ? online(u) : effStatus(u) === f;
function vStudents() {
  $('view').innerHTML = `<div class="toolbar"><div class="search"><i class="bi bi-search"></i><input type="search" id="sq" placeholder="Search name, email or note…" value="${esc(st.q)}"></div>
    <select id="ss" style="width:auto"><option value="new">Newest</option><option value="old">Oldest</option><option value="seen">Last seen</option><option value="name">Name A–Z</option></select>
    <button class="btn" id="sMode"><i class="bi bi-check2-square"></i>Select</button><button class="btn" id="sCsv"><i class="bi bi-download"></i>CSV</button></div>
    <div class="chips" id="sf"></div><div class="card" style="padding:6px 12px"><div id="ul"></div></div><div id="more" class="row mt" style="justify-content:center"></div><div id="bulk"></div>`;
  $('ss').value = st.sort; $('sq').oninput = e => { st.q = e.target.value; st.shown = 30; lStudents(); }; $('ss').onchange = e => { st.sort = e.target.value; lStudents(); };
  $('sMode').onclick = () => { st.selMode = !st.selMode; if (!st.selMode) st.sel.clear(); $('sMode').classList.toggle('pri', st.selMode); lStudents(); };
  $('sCsv').onclick = exportCsv; $('sMode').classList.toggle('pri', st.selMode);
  lStudents();
}
function lStudents() {
  if (st.page !== 'students' || !$('ul')) return;
  if (!st.usersReady) { $('ul').innerHTML = skeleton(5); return; }
  $('sf').innerHTML = FILTERS.map(f => `<button class="chip ${st.filter === f[0] ? 'on' : ''}" data-f="${f[0]}">${f[1]}<small>${st.users.filter(u => fMatch(u, f[0])).length}</small></button>`).join('');
  $('sf').querySelectorAll('button').forEach(b => b.onclick = () => { st.filter = b.dataset.f; st.shown = 30; lStudents(); });
  const q = st.q.trim().toLowerCase();
  let rows = st.users.filter(u => fMatch(u, st.filter) && (!q || [u.name, u.email, u.username, u.note].some(v => String(v || '').toLowerCase().includes(q))));
  const cmp = { new: (a, b) => ms(b.createdAt) - ms(a.createdAt), old: (a, b) => ms(a.createdAt) - ms(b.createdAt), seen: (a, b) => ms(b.lastSeen) - ms(a.lastSeen), name: (a, b) => nameOf(a).localeCompare(nameOf(b)) }[st.sort];
  rows.sort(cmp); const total = rows.length; rows = rows.slice(0, st.shown);
  $('ul').innerHTML = rows.length ? rows.map(u => { const s = effStatus(u);
    return `<div class="li uc" data-u="${u.id}">${st.selMode ? `<input class="ck" type="checkbox" data-ck="${u.id}" ${st.sel.has(u.id) ? 'checked' : ''}>` : ''}${av(u)}<div class="grow"><div class="nm">${esc(nameOf(u))}${online(u) ? ' <span title="online" style="color:var(--ok)">●</span>' : ''}</div><div class="sub">${esc(dispEmail(u))}</div><div style="margin-top:3px">${badge(s)}${u.paid ? '<span class="pill">Paid</span>' : ''}${u.note ? '<span class="pill" style="background:var(--infobg);color:var(--info)">Note</span>' : ''}</div></div>
    <div class="meta">Joined<br><b style="color:var(--ink)">${D(u.createdAt)}</b></div><div class="meta">Last seen<br><b style="color:var(--ink)">${ago(u.lastSeen)}</b></div>
    <div class="acts">${s === 'pending' || s === 'blocked' || s === 'expired' ? `<button class="btn xs ok" data-a="approve" data-id="${u.id}"><i class="bi bi-check-lg"></i>Approve</button>` : ''}${s !== 'blocked' ? `<button class="btn xs bad" data-a="block" data-id="${u.id}"><i class="bi bi-slash-circle"></i>Block</button>` : ''}</div></div>`; }).join('')
    : `<div class="empty"><i class="bi bi-search"></i>No students match</div>`;
  $('ul').querySelectorAll('.li').forEach(r => r.onclick = ev => {
    const a = ev.target.closest('[data-a]'); if (a) { ev.stopPropagation(); setStatus([a.dataset.id], a.dataset.a === 'approve' ? 'approved' : 'blocked', a); return; }
    const ck = ev.target.closest('[data-ck]'); if (ck) { ev.stopPropagation(); ck.checked ? st.sel.add(ck.dataset.ck) : st.sel.delete(ck.dataset.ck); bulkBar(); return; }
    if (st.selMode) { const id = r.dataset.u; st.sel.has(id) ? st.sel.delete(id) : st.sel.add(id); lStudents(); return; }
    openUser(r.dataset.u);
  });
  $('more').innerHTML = total > st.shown ? `<button class="btn" id="moreB">Show more (${total - st.shown})</button>` : (total ? `<span class="sm mut">${total} student${total > 1 ? 's' : ''}</span>` : '');
  const mb = $('moreB'); if (mb) mb.onclick = () => { st.shown += 30; lStudents(); };
  bulkBar(rows.map(u => u.id));
}
function bulkBar() {
  const n = st.sel.size, el = $('bulk'); if (!el) return;
  if (!st.selMode || !n) { el.innerHTML = ''; return; }
  el.innerHTML = `<div class="bulk"><b>${n} selected</b><button class="btn xs" data-b="approved"><i class="bi bi-check-lg"></i>Approve</button><button class="btn xs" data-b="blocked"><i class="bi bi-slash-circle"></i>Block</button><button class="btn xs" data-b="paid"><i class="bi bi-wallet2"></i>Paid</button><button class="btn xs" data-b="unpaid">Unpaid</button><button class="btn xs" data-b="notify"><i class="bi bi-megaphone"></i></button><button class="btn xs" data-b="del"><i class="bi bi-trash"></i></button><button class="btn xs ghost right" data-b="clear"><i class="bi bi-x-lg"></i></button></div>`;
  el.querySelectorAll('[data-b]').forEach(b => b.onclick = async () => {
    const k = b.dataset.b, ids = [...st.sel];
    if (k === 'clear') { st.sel.clear(); lStudents(); return; }
    if (k === 'approved' || k === 'blocked') return setStatus(ids, k, b);
    if (k === 'paid' || k === 'unpaid') return batchUpdate(ids, { paid: k === 'paid' }, `${k === 'paid' ? 'Marked paid' : 'Marked unpaid'}: ${ids.length} student(s)`, 'edit.paid', b);
    if (k === 'del') return delUsers(ids);
    if (k === 'notify') { go('notify'); toast('Compose a message for everyone — per-student messages are not supported yet.'); }
  });
}
async function batchUpdate(ids, fields, detail, action, btn) {
  await busy(btn, async () => {
    try { for (let i = 0; i < ids.length; i += 400) { const b = writeBatch(db); ids.slice(i, i + 400).forEach(id => b.update(doc(db, 'users', id), fields)); await b.commit(); } toast(detail); audit(action, ids.length === 1 ? (nameOf(st.users.find(u => u.id === ids[0]) || {}) ) : ids.length + ' students', detail); st.sel.clear(); }
    catch (e) { toast('Failed: ' + errMsg(e), true); }
  });
}
async function setStatus(ids, status, btn) {
  const word = status === 'approved' ? 'Approved' : 'Blocked';
  if (status === 'blocked' && ids.length > 1 && !await confirmBox('Block ' + ids.length + ' students?', 'They will lose access immediately.', 'Block', true)) return;
  const f = { status }; if (status === 'approved') f.expiresAt = null;
  await batchUpdate(ids, f, `${word} ${ids.length === 1 ? nameOf(st.users.find(u => u.id === ids[0]) || {}) : ids.length + ' students'}`, status === 'approved' ? 'approve' : 'block', btn);
}
async function approveAll() { const ids = pending().map(u => u.id); if (!ids.length) return; if (await confirmBox('Approve all pending?', ids.length + ' student(s) will get access.', 'Approve all')) setStatus(ids, 'approved'); }
async function delUsers(ids) {
  if (!await confirmBox('Delete ' + ids.length + ' account record(s)?', 'This removes them from this list. If they sign in again they will appear as a new pending request.', 'Delete', true)) return;
  try { for (let i = 0; i < ids.length; i += 400) { const b = writeBatch(db); ids.slice(i, i + 400).forEach(id => b.delete(doc(db, 'users', id))); await b.commit(); } toast('Deleted'); audit('delete', ids.length + ' students', 'Deleted ' + ids.length + ' account record(s)'); st.sel.clear(); closeSheet(); }
  catch (e) { toast('Failed: ' + errMsg(e), true); }
}
function openUser(id) {
  const u = st.users.find(x => x.id === id); if (!u) return; const s = effStatus(u), exp = ms(u.expiresAt);
  const iso = exp ? new Date(exp).toISOString().slice(0, 10) : '';
  openSheet(`<div class="row" style="gap:14px">${av(u, 'lg')}<div class="grow"><h3 style="margin:0;word-break:break-word">${esc(nameOf(u))}</h3><div class="sm mut" style="word-break:break-all">${esc(dispEmail(u))}</div><div style="margin-top:4px">${badge(s)}${u.paid ? '<span class="pill">Paid</span>' : ''}${online(u) ? '<span class="pill" style="background:var(--okbg);color:var(--ok)">Online</span>' : ''}</div></div><button class="btn xs ghost" id="uX" aria-label="Close"><i class="bi bi-x-lg"></i></button></div>
  <dl class="kv mt"><dt>Joined</dt><dd>${DT(u.createdAt)}</dd><dt>Last seen</dt><dd>${u.lastSeen ? DT(u.lastSeen) + ' (' + ago(u.lastSeen) + ')' : 'never'}</dd><dt>Sign-in</dt><dd>${u.provider === 'google.com' ? 'Google' : 'Username / email'}</dd>${exp ? `<dt>Access ends</dt><dd>${D(exp)}</dd>` : ''}</dl>
  <label class="fld"><span>Display name</span><input type="text" id="uName" value="${esc(u.name || '')}" maxlength="60"></label>
  <div class="fld"><span>Status</span><div class="seg" id="uSt">${['pending', 'approved', 'blocked'].map(k => `<button data-s="${k}" class="${u.status === k || (!u.status && k === 'pending') ? 'on' : ''}">${BADGE[k][1]}</button>`).join('')}</div></div>
  <label class="fld"><span>Access ends on (optional)</span><div class="row"><input type="date" id="uExp" value="${iso}" style="flex:1"><button class="btn xs" data-add="30">+30d</button><button class="btn xs" data-add="90">+90d</button><button class="btn xs" data-add="365">+1y</button><button class="btn xs" data-add="0">Clear</button></div></label>
  <div class="setrow"><div class="grow"><b>Marked as paid</b><span class="sm mut">For your own records</span></div><label class="sw"><input type="checkbox" id="uPaid" ${u.paid ? 'checked' : ''}><i></i></label></div>
  <div class="fld"><span>Devices</span><div id="uDev" class="sm mut">Loading…</div><div class="row" style="margin-top:6px"><button class="btn xs" id="uDevR">Reset devices</button><button class="btn xs bad" id="uOutAll">Sign out everywhere</button></div></div>
  <label class="fld"><span>Private note</span><textarea id="uNote" maxlength="500" placeholder="Only you can see this">${esc(u.note || '')}</textarea></label>
  <div class="row mt"><button class="btn pri grow" id="uSave"><i class="bi bi-check2"></i>Save changes</button><button class="btn" id="uCopy"><i class="bi bi-clipboard"></i></button><button class="btn bad" id="uDel"><i class="bi bi-trash"></i></button></div>`);
  let status = u.status || 'pending';
  $('uX').onclick = closeSheet;
  $('uSt').querySelectorAll('button').forEach(b => b.onclick = () => { status = b.dataset.s; $('uSt').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); });
  $('sheet').querySelectorAll('[data-add]').forEach(b => b.onclick = () => { const n = +b.dataset.add; $('uExp').value = n ? new Date(Date.now() + n * DAY).toISOString().slice(0, 10) : ''; });
  $('uCopy').onclick = () => { navigator.clipboard && navigator.clipboard.writeText(u.email || ''); toast('Copied'); };
  $('uDel').onclick = () => delUsers([id]);
  const devCol = collection(db, 'users', id, 'devices');
  const loadDev = () => getDocs(devCol).then(sn => { const el = $('uDev'); if (!el) return; el.innerHTML = sn.size ? sn.docs.map(d => { const x = d.data(); return `<div>• ${esc((x.ua || '').replace(/^Mozilla\/5\.0 /, '').slice(0, 60))} <span class="mut">(${ago(x.last)})</span></div>`; }).join('') : 'No device recorded yet'; }).catch(() => { const el = $('uDev'); if (el) el.textContent = 'Could not load'; });
  loadDev();
  const wipeDev = async () => { const sn = await getDocs(devCol); await Promise.all(sn.docs.map(d => deleteDoc(d.ref))); };
  $('uDevR').onclick = () => busy($('uDevR'), async () => { try { await wipeDev(); toast('Devices reset'); audit('edit', nameOf(u), 'Reset devices of ' + nameOf(u)); loadDev(); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
  $('uOutAll').onclick = async () => { if (!await confirmBox('Sign out everywhere?', nameOf(u) + ' will be signed out on every phone and must sign in again.', 'Sign out', true)) return; busy($('uOutAll'), async () => { try { await updateDoc(doc(db, 'users', id), { sessionEpoch: Date.now() }); await wipeDev(); toast('Signed out everywhere'); audit('edit', nameOf(u), 'Signed out ' + nameOf(u) + ' everywhere'); loadDev(); } catch (e) { toast('Failed: ' + errMsg(e), true); } }); };
  $('uSave').onclick = () => busy($('uSave'), async () => {
    const e = $('uExp').value, f = { name: $('uName').value.trim(), status, paid: $('uPaid').checked, note: $('uNote').value.trim(), expiresAt: e ? Timestamp.fromMillis(new Date(e + 'T23:59:59').getTime()) : null };
    try { await updateDoc(doc(db, 'users', id), f); toast('Saved'); audit('edit', nameOf({ ...u, ...f }), 'Updated ' + nameOf({ ...u, ...f })); closeSheet(); } catch (er) { toast('Failed: ' + errMsg(er), true); }
  });
}
function exportCsv() {
  const q = v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"', iso = t => ms(t) ? new Date(ms(t)).toISOString() : '';
  const rows = [['Name', 'Email', 'Username', 'Status', 'Paid', 'Note', 'Provider', 'Joined', 'Last seen', 'Access ends']].concat(st.users.map(u => [u.name, u.email, u.username, effStatus(u), u.paid ? 'yes' : 'no', u.note, u.provider, iso(u.createdAt), iso(u.lastSeen), iso(u.expiresAt)]));
  dl('students-' + new Date().toISOString().slice(0, 10) + '.csv', '﻿' + rows.map(r => r.map(q).join(',')).join('\r\n'), 'text/csv;charset=utf-8'); toast('CSV downloaded'); audit('export', '', 'Exported students CSV');
}
function exportJson() {
  const ser = o => JSON.parse(JSON.stringify(o, (k, v) => (v && typeof v.toMillis === 'function') ? v.toMillis() : v));
  dl('backup-' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify({ exportedAt: new Date().toISOString(), users: ser(st.users), notifications: ser(st.notifs), settings: { site: st.site, theme: st.theme } }, null, 1), 'application/json'); toast('Backup downloaded'); audit('export', '', 'Downloaded JSON backup');
}

/* ---------- notifications ---------- */
const NTYPES = [['info', 'Info', 'bi-info-lg'], ['success', 'Good news', 'bi-check-lg'], ['warn', 'Warning', 'bi-exclamation-lg'], ['important', 'Important', 'bi-megaphone-fill']];
let nType = 'info';
const TPL = [['New lessons', 'نئے اسباق شامل ہو گئے', 'ایپ میں نئے اسباق دیکھیں۔', 'success'], ['Renewal', 'رسائی کی تجدید', 'آپ کی رسائی جلد ختم ہو رہی ہے۔ تجدید کے لیے رابطہ کریں۔', 'warn'], ['Exam tip', 'امتحان کی تیاری', 'آج کم از کم ایک سبق دہرائیں۔', 'info'], ['Update', 'عارضی اپ ڈیٹ', 'سائٹ کچھ دیر کے لیے اپ ڈیٹ ہوگی۔', 'important']];
function vNotify() {
  $('view').innerHTML = `<div class="grid cols2"><div class="card"><h2><i class="bi bi-pencil-square"></i>New notification</h2>
    <div class="seg" id="nT" style="flex-wrap:wrap">${NTYPES.map(t => `<button data-t="${t[0]}" class="${nType === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>
    <div class="fld"><span>Quick templates</span><div class="chips" id="nTpl" style="flex-wrap:wrap">${TPL.map((t, i) => `<button class="chip" data-i="${i}">${t[0]}</button>`).join('')}</div></div>
    <label class="fld"><span>Title</span><input type="text" id="nTitle" maxlength="80" placeholder="e.g. New lessons added" dir="auto"></label>
    <label class="fld"><span>Message (optional)</span><textarea id="nBody" maxlength="400" dir="auto" placeholder="Write the details…"></textarea></label>
    <label class="fld"><span>Disappears from the list after</span><select id="nExp"><option value="0">Never</option><option value="24">1 day</option><option value="168">7 days</option><option value="720">30 days</option></select></label>
    <div class="fld"><span>Preview</span><div class="nprev" id="nPrev"></div></div>
    <button class="btn pri full mt" id="nSend"><i class="bi bi-send"></i>Send to all students</button><p class="sm mut" style="margin:8px 0 0">Students see a toast for a few seconds and the bell shows a red dot until they open it.</p></div>
    <div class="card"><h2><i class="bi bi-list-ul"></i>Sent history</h2><div id="nHist"></div></div></div>`;
  const prev = () => { const t = $('nTitle').value.trim() || 'Notification title', b = $('nBody').value.trim(), k = NTYPES.find(x => x[0] === nType); $('nPrev').innerHTML = `<div class="ni ${nType}"><i class="bi ${k[2]}"></i></div><div class="grow" dir="auto"><b>${esc(t)}</b><div class="sm mut" style="white-space:pre-line">${esc(b)}</div></div>`; };
  $('nT').querySelectorAll('button').forEach(b => b.onclick = () => { nType = b.dataset.t; $('nT').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); prev(); });
  $('nTitle').oninput = prev; $('nBody').oninput = prev; prev();
  $('nTpl').querySelectorAll('button').forEach(b => b.onclick = () => { const t = TPL[b.dataset.i]; $('nTitle').value = t[1]; $('nBody').value = t[2]; nType = t[3]; $('nT').querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.t === nType)); prev(); });
  $('nSend').onclick = () => busy($('nSend'), async () => {
    const title = $('nTitle').value.trim(); if (!title) { toast('Please write a title', true); return; }
    const h = +$('nExp').value, d = { title, body: $('nBody').value.trim(), type: nType, createdAt: serverTimestamp(), by: st.me.email };
    if (h) d.expiresAt = Timestamp.fromMillis(Date.now() + h * 36e5);
    try { await addDoc(collection(db, 'notifications'), d); toast('Notification sent'); audit('notify', title, 'Sent notification “' + title + '”'); $('nTitle').value = ''; $('nBody').value = ''; prev(); } catch (e) { toast('Failed: ' + errMsg(e), true); }
  });
  lNotifs();
}
function lNotifs() {
  const el = $('nHist'); if (!el || st.page !== 'notify') return;
  el.innerHTML = st.notifs.length ? st.notifs.map(n => { const k = NTYPES.find(x => x[0] === n.type) || NTYPES[0], e = ms(n.expiresAt);
    return `<div class="li" style="cursor:default;align-items:flex-start"><div class="ni ${esc(n.type || 'info')}" style="width:34px;height:34px;border-radius:11px;display:grid;place-items:center;color:#fff;flex:none"><i class="bi ${k[2]}"></i></div><div class="grow"><div class="nm" dir="auto">${esc(n.title)}</div>${n.body ? `<div class="sub" dir="auto" style="white-space:pre-line;word-break:normal">${esc(n.body)}</div>` : ''}<div class="sm mut">${DT(n.createdAt)}${e ? ' · ' + (e < Date.now() ? 'expired' : 'until ' + D(e)) : ''}</div></div><button class="btn xs ghost bad" data-del="${n.id}" aria-label="Delete"><i class="bi bi-trash"></i></button></div>`; }).join('')
    : '<div class="empty"><i class="bi bi-bell-slash"></i>No notifications sent yet</div>';
  el.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this notification?', 'Students will no longer see it.', 'Delete', true)) return; try { await deleteDoc(doc(db, 'notifications', b.dataset.del)); toast('Deleted'); audit('delete', '', 'Deleted a notification'); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
}

/* ---------- content ---------- */
let bundle = null;
function vContent() {
  $('view').innerHTML = `<div class="grid cols2"><div class="card"><h2><i class="bi bi-cloud-arrow-up"></i>Upload lessons</h2><p class="sm mut" style="margin:0 0 10px">Choose <b>mq-content-bundle.json</b> (Mutalea Quran) or <b>urdu-content-bundle.json</b> (Urdu notes). Uploading again replaces those lessons; students refresh them automatically.</p><input type="file" id="fIn" accept=".json,application/json"><div class="sm mut mt" id="fInfo"></div><div class="pbar hide" id="pb"><i></i></div><button class="btn pri full mt" id="upB" disabled><i class="bi bi-upload"></i>Upload to database</button></div>
  <div class="card"><h2><i class="bi bi-database"></i>Stored lessons</h2><div id="cStat">${skeleton(2)}</div></div></div><div class="card mt"><h2><i class="bi bi-list-check"></i>Documents</h2><div id="cList"></div></div>`;
  $('fIn').onchange = async e => { bundle = null; $('upB').disabled = true; const f = e.target.files[0]; if (!f) return;
    try { const j = JSON.parse(await f.text()); if (!(j.chapters && j.exercises) && !j.docs) throw new Error('This is not a content bundle.'); bundle = j; $('fInfo').textContent = (j.docs ? Object.keys(j.docs).length + ' documents ready' : Object.keys(j.chapters).length + ' lessons and ' + Object.keys(j.exercises).length + ' exercises ready') + ' (' + Math.round(f.size / 1024) + ' KB).'; $('upB').disabled = false; }
    catch (er) { $('fInfo').textContent = 'Could not read that file: ' + er.message; } };
  $('upB').onclick = () => busy($('upB'), async () => {
    $('pb').classList.remove('hide'); const bar = $('pb').firstElementChild; bar.style.width = '0';
    try {
      const rev = Date.now(), items = [];
      for (const id in (bundle.chapters || {})) items.push(['ch_' + id, bundle.chapters[id]]);
      for (const id in (bundle.exercises || {})) items.push(['ex_' + id, bundle.exercises[id]]);
      for (const k in (bundle.docs || {})) items.push([k, bundle.docs[k]]);
      let old = {}; try { const s = await getDoc(doc(db, 'content', '_rev')); if (s.exists()) old = s.data().map || {}; } catch (e) { }
      const map = { ...old };
      for (let i = 0; i < items.length; i += 20) { const b = writeBatch(db); items.slice(i, i + 20).forEach(([k, o]) => { b.set(doc(db, 'content', k), { json: JSON.stringify(o), rev, updatedAt: serverTimestamp() }); map[k] = rev; }); await b.commit(); bar.style.width = Math.round(Math.min(i + 20, items.length) / items.length * 100) + '%'; }
      await setDoc(doc(db, 'content', '_rev'), { map });
      toast('Done — ' + items.length + ' documents uploaded'); audit('content', '', 'Uploaded ' + items.length + ' lesson documents'); loadContent();
    } catch (e) { toast('Upload failed: ' + errMsg(e), true); }
  });
  loadContent();
}
async function loadContent() {
  try {
    const s = await getDocs(collection(db, 'content')); st.content = s.docs.filter(d => d.id !== '_rev').map(d => ({ id: d.id, size: (d.data().json || '').length, rev: d.data().rev })).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
    if (st.page !== 'content') return;
    const ch = st.content.filter(c => c.id.startsWith('ch_')).length, ur = st.content.filter(c => c.id.startsWith('ur_')).length, ex = st.content.length - ch - ur, kb = Math.round(st.content.reduce((a, c) => a + c.size, 0) / 1024), last = Math.max(0, ...st.content.map(c => c.rev || 0));
    $('cStat').innerHTML = `<div class="grid g2"><div><b style="font-size:1.5rem">${ch}</b><div class="sm mut">Lessons</div></div><div><b style="font-size:1.5rem">${ex}</b><div class="sm mut">Exercises</div></div><div><b style="font-size:1.5rem">${ur}</b><div class="sm mut">Urdu notes pages</div></div><div><b style="font-size:1.5rem">${kb} KB</b><div class="sm mut">Total size</div></div><div><b style="font-size:1rem">${last ? D(last) : '—'}</b><div class="sm mut">Last upload</div></div></div>`;
    $('cList').innerHTML = st.content.length ? `<div class="chips" style="flex-wrap:wrap">${st.content.map(c => `<span class="chip" title="${Math.round(c.size / 1024)} KB">${esc(c.id)}<small>${Math.max(1, Math.round(c.size / 1024))}K</small></span>`).join('')}</div>` : '<div class="empty"><i class="bi bi-inbox"></i>No lessons uploaded yet</div>';
  } catch (e) { if ($('cStat')) $('cStat').innerHTML = '<div class="err">Could not read content: ' + esc(errMsg(e)) + '</div>'; }
}

/* ---------- activity ---------- */
function vActivity() { $('view').innerHTML = `<div class="card"><div class="row" style="margin-bottom:6px"><h2 style="margin:0"><i class="bi bi-clock-history"></i>Audit log</h2><span class="sm mut right">last ${st.audit.length}</span></div><div id="aList"></div></div>`; lActivity(); }
function lActivity() { const el = $('aList'); if (el && st.page === 'activity') el.innerHTML = st.audit.length ? actHtml(st.audit) : '<div class="empty"><i class="bi bi-inbox"></i>No admin actions recorded yet</div>'; }

/* ---------- settings ---------- */
const PRESETS = [['Original green', '', ''], ['White + green', '#2A7459', '#FFFFFF'], ['White + blue', '#2C6CB0', '#FFFFFF'], ['White + black', '#1F2937', '#FFFFFF'], ['White + purple', '#6B46C1', '#FFFFFF'], ['White + maroon', '#9B2C4A', '#FFFFFF'], ['Warm paper', '#8A5C00', '#FFF8EE']];
const lum = h => { const c = [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255).map(v => v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4)); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
function vSettings() {
  $('view').innerHTML = `<div class="grid cols2"><div class="card"><h2><i class="bi bi-shield-lock"></i>Access control</h2>
    <div class="setrow"><div class="grow"><b>Allow new sign-ups</b><span class="sm mut">Off = nobody new can create an account</span></div><label class="sw"><input type="checkbox" id="sSign"><i></i></label></div>
    <div class="setrow"><div class="grow"><b>Maintenance mode</b><span class="sm mut">Students see a “be right back” screen (you still get in)</span></div><label class="sw"><input type="checkbox" id="sMain"><i></i></label></div>
    <label class="fld"><span>Maintenance message (Urdu or English)</span><input type="text" id="sMsg" dir="auto" maxlength="160" placeholder="کچھ دیر بعد دوبارہ آئیں"></label><button class="btn full mt" id="sMsgB">Save message</button>
    <label class="fld"><span>Devices allowed per student (0 = no limit)</span><div class="row"><input type="number" id="sDev" min="0" max="10" value="0" style="flex:1"><button class="btn" id="sDevB">Save</button></div></label><p class="sm mut" style="margin:0">A soft limit: a new phone is refused once the student already uses this many. Reset a student's devices from their profile.</p></div>
  <div class="card"><h2><i class="bi bi-palette"></i>Site colour</h2><div class="chips" id="pre" style="flex-wrap:wrap"></div>
    <div class="row mt"><label class="sm mut">Accent <input type="color" id="cA" value="#2A7459"></label><label class="sm mut">Background <input type="color" id="cB" value="#F5F8F3"></label><div id="pvw" class="grow" style="min-width:120px;border-radius:14px;padding:10px;text-align:center;border:1px solid var(--line)"><b id="pvT">مطالعہ قرآن</b></div></div>
    <p class="sm mut" id="tMsg">Applies in light mode; dark mode is untouched.</p><div class="row"><button class="btn pri" id="tSave">Save colour</button><button class="btn" id="tReset">Back to green</button></div></div></div>
  <div class="grid cols2 mt"><div class="card"><h2><i class="bi bi-cloud-download"></i>Backup & export</h2><p class="sm mut" style="margin:0 0 10px">Download your student list and settings any time.</p><div class="row"><button class="btn" id="bCsv"><i class="bi bi-filetype-csv"></i>Students CSV</button><button class="btn" id="bJson"><i class="bi bi-filetype-json"></i>Full backup (JSON)</button></div></div>
  <div class="card"><h2><i class="bi bi-person-badge"></i>Account</h2><dl class="kv"><dt>Signed in as</dt><dd>${esc(st.me.email)}</dd><dt>Project</dt><dd>${esc(CFG.projectId)}</dd><dt>Students</dt><dd>${st.users.length}</dd></dl><div class="row mt"><button class="btn" id="aCmd"><i class="bi bi-command"></i>Commands <kbd>Ctrl K</kbd></button><button class="btn bad" id="aOut"><i class="bi bi-box-arrow-right"></i>Sign out</button></div></div></div>`;
  $('pre').innerHTML = PRESETS.map((p, i) => `<button class="chip" data-i="${i}">${p[0]}</button>`).join('');
  const pv = () => { $('pvw').style.background = $('cB').value; $('pvT').style.color = $('cA').value; };
  $('pre').querySelectorAll('button').forEach(b => b.onclick = () => { const p = PRESETS[b.dataset.i]; $('cA').value = p[1] || '#2A7459'; $('cB').value = p[2] || '#F5F8F3'; pv(); $('tMsg').textContent = p[1] ? 'Preview only — tap “Save colour” to apply.' : 'Tap “Back to green” to restore the original.'; });
  $('cA').oninput = pv; $('cB').oninput = pv;
  const setSite = async (f, label) => { try { await setDoc(doc(db, 'settings', 'site'), { ...f, updatedAt: serverTimestamp() }, { merge: true }); toast(label); audit('settings', '', label); } catch (e) { toast('Failed: ' + errMsg(e), true); syncSettings(); } };
  $('sSign').onchange = e => setSite({ signupOpen: e.target.checked }, e.target.checked ? 'Sign-ups opened' : 'Sign-ups closed');
  $('sMain').onchange = async e => { if (e.target.checked && !await confirmBox('Turn on maintenance mode?', 'Students will be locked out until you turn it off.', 'Turn on', true)) { e.target.checked = false; return; } setSite({ maintenance: e.target.checked }, e.target.checked ? 'Maintenance mode ON' : 'Maintenance mode OFF'); };
  $('sDevB').onclick = () => { const n = Math.max(0, Math.min(10, parseInt($('sDev').value, 10) || 0)); setSite({ deviceLimit: n }, n ? 'Device limit set to ' + n : 'Device limit off'); };
  $('sMsgB').onclick = () => setSite({ maintenanceMsg: $('sMsg').value.trim() }, 'Maintenance message saved');
  $('tSave').onclick = () => busy($('tSave'), async () => { const a = $('cA').value, b = $('cB').value; if (lum(b) <= .7) { $('tMsg').textContent = 'Please pick a lighter background so the text stays readable.'; return; }
    try { await setDoc(doc(db, 'settings', 'theme'), { a, b, updatedAt: serverTimestamp() }); $('tMsg').textContent = 'Saved. Students see it next time they open the app online.'; toast('Colour saved'); audit('settings', '', 'Changed site colour'); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
  $('tReset').onclick = () => busy($('tReset'), async () => { try { await setDoc(doc(db, 'settings', 'theme'), { a: '', b: '', updatedAt: serverTimestamp() }); $('cA').value = '#2A7459'; $('cB').value = '#F5F8F3'; pv(); $('tMsg').textContent = 'Back to the original green.'; toast('Colour reset'); audit('settings', '', 'Reset site colour'); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
  $('bCsv').onclick = exportCsv; $('bJson').onclick = exportJson; $('aCmd').onclick = openCmd; $('aOut').onclick = out;
  syncSettings(true); pv();
}
function syncSettings(first) {
  if (st.page !== 'settings' || !$('sSign')) return;
  if (first || document.activeElement !== $('sDev')) $('sDev').value = st.site.deviceLimit || 0;
  $('sSign').checked = st.site.signupOpen !== false; $('sMain').checked = !!st.site.maintenance;
  if (first || document.activeElement !== $('sMsg')) $('sMsg').value = st.site.maintenanceMsg || '';
  if (st.theme.a && (first || !$('cA').dataset.t)) { $('cA').value = st.theme.a; $('cB').value = st.theme.b || '#FFFFFF'; $('pvw').style.background = $('cB').value; $('pvT').style.color = $('cA').value; }
}

/* ---------- command palette ---------- */
let cmdI = 0, cmdList = [];
const COMMANDS = () => [
  ...PAGES.map(p => ({ g: 'Go to', t: p[1], i: p[2], f: () => go(p[0]) })),
  { g: 'Actions', t: 'Send a notification', i: 'bi-megaphone', f: () => go('notify') },
  { g: 'Actions', t: `Approve all pending (${pending().length})`, i: 'bi-check2-all', f: approveAll },
  { g: 'Actions', t: 'Show pending students', i: 'bi-hourglass-split', f: () => { st.filter = 'pending'; go('students'); } },
  { g: 'Actions', t: 'Show online students', i: 'bi-broadcast', f: () => { st.filter = 'online'; go('students'); } },
  { g: 'Actions', t: 'Export students CSV', i: 'bi-filetype-csv', f: exportCsv },
  { g: 'Actions', t: 'Download full backup (JSON)', i: 'bi-cloud-download', f: exportJson },
  { g: 'Actions', t: st.site.maintenance ? 'Turn maintenance mode OFF' : 'Turn maintenance mode ON', i: 'bi-tools', f: async () => { if (!st.site.maintenance && !await confirmBox('Turn on maintenance mode?', 'Students will be locked out.', 'Turn on', true)) return; await setDoc(doc(db, 'settings', 'site'), { maintenance: !st.site.maintenance, updatedAt: serverTimestamp() }, { merge: true }); toast('Maintenance ' + (!st.site.maintenance ? 'ON' : 'OFF')); audit('settings', '', 'Maintenance ' + (!st.site.maintenance ? 'ON' : 'OFF')); } },
  { g: 'Actions', t: st.site.signupOpen === false ? 'Open new sign-ups' : 'Close new sign-ups', i: 'bi-person-plus', f: async () => { const o = st.site.signupOpen === false; await setDoc(doc(db, 'settings', 'site'), { signupOpen: o, updatedAt: serverTimestamp() }, { merge: true }); toast(o ? 'Sign-ups opened' : 'Sign-ups closed'); audit('settings', '', o ? 'Sign-ups opened' : 'Sign-ups closed'); } },
  { g: 'Actions', t: 'Toggle dark / light', i: 'bi-moon-stars', f: toggleTheme },
  { g: 'Actions', t: 'Sign out', i: 'bi-box-arrow-right', f: out }
];
function openCmd() { $('cmdk').classList.add('on'); $('scrim').classList.add('on'); $('cmdIn').value = ''; cmdI = 0; renderCmd(); setTimeout(() => $('cmdIn').focus(), 30); }
function closeCmd() { $('cmdk').classList.remove('on'); if (!$('sheet').classList.contains('on') && !$('modal').classList.contains('on')) $('scrim').classList.remove('on'); }
function renderCmd() {
  const q = $('cmdIn').value.trim().toLowerCase();
  let list = COMMANDS().filter(c => !q || c.t.toLowerCase().includes(q));
  const stu = q.length > 1 ? st.users.filter(u => [u.name, u.email, u.username].some(v => String(v || '').toLowerCase().includes(q))).slice(0, 6).map(u => ({ g: 'Students', t: nameOf(u), i: 'bi-person', s: dispEmail(u), f: () => { go('students'); openUser(u.id); } })) : [];
  cmdList = [...stu, ...list]; cmdI = Math.min(cmdI, Math.max(0, cmdList.length - 1)); let g = '';
  $('cmdRes').innerHTML = cmdList.map((c, i) => `${c.g !== g ? `<div class="grp">${g = c.g}</div>` : ''}<div class="it ${i === cmdI ? 'on' : ''}" data-i="${i}"><i class="bi ${c.i}"></i>${esc(c.t)}<small>${esc(c.s || '')}</small></div>`).join('') || '<div class="empty">No matches</div>';
  $('cmdRes').querySelectorAll('.it').forEach(e => e.onclick = () => runCmd(+e.dataset.i));
}
function runCmd(i) { const c = cmdList[i]; if (!c) return; closeCmd(); c.f(); }
$('cmdIn').oninput = () => { cmdI = 0; renderCmd(); };
document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); if (st.ready) $('cmdk').classList.contains('on') ? closeCmd() : openCmd(); return; }
  if (e.key === 'Escape') { closeCmd(); closeSheet(); return; }
  if ($('cmdk').classList.contains('on')) {
    if (e.key === 'ArrowDown') { e.preventDefault(); cmdI = Math.min(cmdList.length - 1, cmdI + 1); renderCmd(); $('cmdRes').querySelector('.on')?.scrollIntoView({ block: 'nearest' }); }
    if (e.key === 'ArrowUp') { e.preventDefault(); cmdI = Math.max(0, cmdI - 1); renderCmd(); $('cmdRes').querySelector('.on')?.scrollIntoView({ block: 'nearest' }); }
    if (e.key === 'Enter') { e.preventDefault(); runCmd(cmdI); }
  }
});
setInterval(() => { if (st.ready && st.page === 'dashboard') vDash(); }, 60000);


/* ---------- insights ---------- */
async function loadProg(force) { if (!force && st.prog && Date.now() - st.progAt < 60000) return; const sn = await getDocs(query(collection(db, 'progress'), limit(500))); st.prog = sn.docs.map(d => ({ id: d.id, ...d.data() })); st.progAt = Date.now(); }
function vInsights() {
  $('view').innerHTML = `<div class="grid kpis">${skeleton(4)}</div>${skeleton(3)}`;
  loadProg().then(drawInsights).catch(e => { $('view').innerHTML = `<div class="card"><div class="empty"><i class="bi bi-exclamation-circle"></i>Could not load progress data (${esc(errMsg(e))}). Publish the new Firestore rules first.</div></div>`; });
}
function drawInsights() {
  if (st.page !== 'insights') return;
  const U = st.users, now = Date.now(), t0 = new Date(); t0.setHours(0, 0, 0, 0);
  const appr = U.filter(u => effStatus(u) === 'approved'), act = d => appr.filter(u => ms(u.lastSeen) > now - d * DAY).length;
  const opens = {}, reads = {}, perUser = [];
  const SITES = [['', 'Quran · '], ['ur:', 'Urdu · '], ['en:', 'English · ']], pj = x => { try { return JSON.parse(x || 'null'); } catch (e) { return null; } };
  (st.prog || []).forEach(p => { const d = p.d || {}; let n = 0;
    SITES.forEach(([pf, lab]) => {
      const o = pj(d[pf + 'opens']) || {}, r = pj(d[pf + (pf ? 'readPages' : 'read')]) || {}, rk = Array.isArray(r) ? r : Object.keys(r);
      Object.keys(o).forEach(k => opens[lab + k] = (opens[lab + k] || 0) + (+o[k] || 0)); rk.forEach(k => { reads[lab + k] = (reads[lab + k] || 0) + 1; }); n += rk.length; });
    perUser.push({ id: p.id, n }); });
  const top = (m, n) => Object.entries(m).sort((a, b) => b[1] - a[1]).slice(0, n);
  const bars = (arr, empty) => { const mx = arr.length ? arr[0][1] : 1; return arr.length ? arr.map(([k, v]) => `<div class="li" style="cursor:default"><div class="grow"><div class="nm" dir="auto">${esc(k)}</div><div style="height:6px;border-radius:9px;background:var(--soft);margin-top:5px"><i style="display:block;height:100%;width:${Math.max(4, Math.round(v / mx * 100))}%;border-radius:9px;background:var(--pri)"></i></div></div><b>${v}</b></div>`).join('') : `<div class="empty"><i class="bi bi-bar-chart"></i>${empty}</div>`; };
  const idle = appr.filter(u => !ms(u.lastSeen) || ms(u.lastSeen) < now - 14 * DAY).sort((a, b) => ms(a.lastSeen) - ms(b.lastSeen)).slice(0, 15);
  const soon = U.filter(u => u.status === 'approved' && ms(u.expiresAt) && ms(u.expiresAt) < now + 14 * DAY).sort((a, b) => ms(a.expiresAt) - ms(b.expiresAt)).slice(0, 15);
  const nm = id => { const u = U.find(x => x.id === id); return u ? nameOf(u) : id.slice(0, 6); };
  const lead = perUser.sort((a, b) => b.n - a.n).filter(x => x.n).slice(0, 5).map(x => [nm(x.id), x.n]);
  const li = (u, extra) => `<div class="li" data-u="${u.id}">${av(u)}<div class="grow"><div class="nm">${esc(nameOf(u))}</div><div class="sub">${esc(dispEmail(u))}</div></div>${extra}</div>`;
  $('view').innerHTML = `<div class="grid kpis">
    <div class="kpi"><div class="ic t-ok"><i class="bi bi-lightning-charge"></i></div><b>${appr.filter(u => ms(u.lastSeen) > t0.getTime()).length}</b><span>Active today</span></div>
    <div class="kpi"><div class="ic t-pri"><i class="bi bi-calendar-week"></i></div><b>${act(7)}</b><span>Active in 7 days</span></div>
    <div class="kpi"><div class="ic t-warn"><i class="bi bi-moon"></i></div><b>${appr.length - act(14)}</b><span>Silent 14+ days</span></div>
    <div class="kpi"><div class="ic t-info"><i class="bi bi-journal-check"></i></div><b>${Object.values(reads).reduce((a, b) => a + b, 0)}</b><span>Lessons marked read</span></div></div>
  <div class="grid cols2 mt"><div class="card"><h2><i class="bi bi-fire"></i>Most opened lessons</h2>${bars(top(opens, 8), 'No lesson opens recorded yet')}</div>
    <div class="card"><h2><i class="bi bi-check2-square"></i>Most completed lessons</h2>${bars(top(reads, 8), 'Nobody has marked a lesson read yet')}</div></div>
  <div class="grid cols2 mt"><div class="card"><h2><i class="bi bi-alarm"></i>Expiring within 14 days</h2>${soon.map(u => li(u, `<button class="btn xs" data-ext="${u.id}">+30d</button><span class="sm mut">${D(u.expiresAt)}</span>`)).join('') || '<div class="empty"><i class="bi bi-check-circle"></i>Nobody is about to expire</div>'}</div>
    <div class="card"><h2><i class="bi bi-person-dash"></i>Silent for 14+ days</h2>${idle.map(u => li(u, `<span class="sm mut">${ago(u.lastSeen)}</span>`)).join('') || '<div class="empty"><i class="bi bi-emoji-smile"></i>Everyone has been active</div>'}</div></div>
  <div class="grid cols2 mt"><div class="card"><h2><i class="bi bi-trophy"></i>Most lessons completed</h2>${bars(lead, 'No progress saved yet')}</div>
    <div class="card"><h2><i class="bi bi-arrow-repeat"></i>Data</h2><p class="sm mut" style="margin:0 0 10px">Progress comes from the ${(st.prog || []).length} students whose phones have synced. Updated ${ago(st.progAt)}.</p><button class="btn" id="iRef"><i class="bi bi-arrow-clockwise"></i>Refresh</button></div></div>`;
  document.querySelectorAll('[data-u]').forEach(b => b.onclick = () => openUser(b.dataset.u));
  document.querySelectorAll('[data-ext]').forEach(b => b.onclick = ev => { ev.stopPropagation(); const u = U.find(x => x.id === b.dataset.ext); busy(b, async () => { try { const base = Math.max(ms(u.expiresAt), Date.now()); await updateDoc(doc(db, 'users', u.id), { expiresAt: Timestamp.fromMillis(base + 30 * DAY) }); toast('Extended by 30 days'); audit('edit', nameOf(u), 'Extended access of ' + nameOf(u) + ' by 30 days'); } catch (e) { toast('Failed: ' + errMsg(e), true); } }); });
  $('iRef').onclick = () => busy($('iRef'), async () => { try { await loadProg(true); drawInsights(); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
}

/* ---------- feedback ---------- */
let fbF = 'new';
function vFeedback() { $('view').innerHTML = `<div class="card"><div class="row" style="margin-bottom:8px"><h2 style="margin:0"><i class="bi bi-flag"></i>Mistake reports</h2><div class="seg right" id="fbS">${[['new', 'New'], ['all', 'All']].map(x => `<button data-f="${x[0]}" class="${fbF === x[0] ? 'on' : ''}">${x[1]}</button>`).join('')}</div></div><div id="fbL"></div></div>`; $('fbS').querySelectorAll('button').forEach(b => b.onclick = () => { fbF = b.dataset.f; vFeedback(); }); lFeedback(); }
function lFeedback() {
  const el = $('fbL'); if (!el || st.page !== 'feedback') return;
  const rows = st.fb.filter(x => fbF === 'all' || x.status !== 'done');
  el.innerHTML = rows.length ? rows.map(x => `<div class="li" style="cursor:default;align-items:flex-start"><div class="grow"><div class="nm">${esc(x.name || x.email || 'Student')} <span class="sm mut">· ${ago(x.createdAt)}</span></div><div class="sub" style="word-break:break-all">${esc(x.page || '')}</div><div dir="auto" style="white-space:pre-line;margin-top:4px">${esc(x.msg)}</div></div><div style="display:flex;flex-direction:column;gap:6px">${x.status === 'done' ? '<span class="badge t-ok">Done</span>' : `<button class="btn xs pri" data-ok="${x.id}">Done</button>`}<button class="btn xs bad" data-rm="${x.id}"><i class="bi bi-trash"></i></button></div></div>`).join('') : '<div class="empty"><i class="bi bi-check-circle"></i>No reports</div>';
  el.querySelectorAll('[data-ok]').forEach(b => b.onclick = () => busy(b, async () => { try { await updateDoc(doc(db, 'feedback', b.dataset.ok), { status: 'done' }); } catch (e) { toast('Failed: ' + errMsg(e), true); } }));
  el.querySelectorAll('[data-rm]').forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this report?', 'This cannot be undone.', 'Delete', true)) return; try { await deleteDoc(doc(db, 'feedback', b.dataset.rm)); } catch (e) { toast('Failed: ' + errMsg(e), true); } });
}
