OPTIONAL FONT FILES (for the best Arabic / Urdu look, and fully offline)
Put these woff2 files in this folder (free, open-licence fonts):
  AmiriQuran-Regular.woff2        -> Quran text (Arabic)
  NotoNastaliqUrdu-Regular.woff2  -> Urdu translations / questions
  NotoSansArabic-Regular.woff2    -> menu and buttons
If a file is missing, the site uses a font already on your phone, then a safe fallback.
The service worker caches these files automatically after the first visit.
