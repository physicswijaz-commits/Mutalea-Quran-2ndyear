/* مطالعہ قرآن — shell: header, drawer, light/dark theme, scroll-hide, gate, boot */
(function(){
'use strict';
const S=MQ.S, root=document.documentElement, R=matchMedia('(prefers-reduced-motion: reduce)').matches;
const STEPS=[.85,.95,1,1.12,1.25,1.4,1.6];
function applyScale(){ root.style.setProperty('--ar-scale',S.get('ar',1)); root.style.setProperty('--ur-scale',S.get('ur',1)); }
function stepScale(k,d){ const cur=S.get(k,1); let i=STEPS.findIndex(v=>Math.abs(v-cur)<.01); if(i<0) i=2; i=Math.max(0,Math.min(STEPS.length-1,i+d)); S.set(k,STEPS[i]); applyScale(); }
function setTheme(t){ root.setAttribute('data-theme',t); try{ localStorage.setItem('mq_theme',t); }catch(e){} const m=document.querySelector('meta[name=theme-color]'); if(m) m.content=t==='dark'?'#0F1714':'#F5F8F3'; const b=document.getElementById('theme-btn'); if(b) b.innerHTML=MQ.i(t==='dark'?'sun':'moon-stars'); }
function toggleTheme(e){ const next=root.getAttribute('data-theme')==='dark'?'light':'dark';
  if(!document.startViewTransition||R){ setTheme(next); return; }
  const r=e.currentTarget.getBoundingClientRect(), x=r.left+r.width/2, y=r.top+r.height/2, rad=Math.hypot(Math.max(x,innerWidth-x),Math.max(y,innerHeight-y));
  root.classList.add('theme-vt'); const t=document.startViewTransition(()=>setTheme(next));
  t.ready.then(()=>root.animate({clipPath:[`circle(0px at ${x}px ${y}px)`,`circle(${rad}px at ${x}px ${y}px)`]},{duration:650,easing:'cubic-bezier(.2,.8,.2,1)',pseudoElement:'::view-transition-new(root)'})).catch(()=>{});
  t.finished.finally(()=>root.classList.remove('theme-vt')); }

MQ.shell=function(o){
  o=o||{}; applyScale();
  const h=document.createElement('header'); h.className='bar';
  h.className='bar'+(o.progress?' has-prog':'');
  const ttl=`<div class="bar-title"><b>${MQ.esc(o.title||'مطالعہ قرآن')}</b>${o.sub?`<small>${MQ.esc(o.sub)}</small>`:''}</div>`;
  h.innerHTML=`<div class="bar-in"><button class="icon-btn lead" id="menu-btn" aria-label="مینو کھولیں">${MQ.i('list')}</button>${ttl}
    <div class="pill-group">${o.back?`<a class="icon-btn" href="${o.back}" aria-label="واپس">${MQ.i('arrow-right')}</a>`:''}<button class="icon-btn" id="theme-btn" aria-label="دن / رات بدلیں"></button></div></div><div class="bar-prog"></div>`;
  const back=document.createElement('div'); back.id='backdrop';
  const dr=document.createElement('aside'); dr.id='drawer'; dr.setAttribute('aria-label','مینو');
  const cur=MQ.qs('id'), lessons=MQ.registry.surahs.map(s=>`<h3>${MQ.esc(s.ur)}</h3>`+s.chapters.map(c=>`<a class="d-link${cur===c.id?' cur':''}" href="section.html?id=${c.id}&s=content">${MQ.i(MQ.isRead(c.id)?'check-circle-fill':'journal-text')}<span>سبق ${MQ.nUr(c.n)} · ${MQ.rangeLabel(c.range)}</span></a>`).join('')).join('')||'<p class="muted" style="padding:0 10px;font-size:.8rem">ابھی کوئی سبق موجود نہیں</p>';
  dr.innerHTML=`<div class="d-row"><b style="font-family:var(--f-ar);font-size:1.4rem;font-weight:400">مطالعہ قرآن</b><button class="icon-btn" id="d-close" aria-label="بند کریں">${MQ.i('x-lg')}</button></div>
    <a class="d-link" href="index.html">${MQ.i('house-door')}<span>تمام اسباق</span></a><a class="d-link${location.pathname.endsWith('revision.html')?' cur':''}" href="revision.html">${MQ.i('arrow-repeat')}<span>ریویژن — اہم آیات</span></a><a class="d-link" href="search.html">${MQ.i('search')}<span>تلاش</span></a><a class="d-link" href="bookmarks.html">${MQ.i('bookmark-star')}<span>محفوظ آیات</span></a><a class="d-link" href="test.html">${MQ.i('clipboard-check')}<span>امتحانی ٹیسٹ</span></a>${lessons}
    <h3>سیٹنگز</h3>
    <div class="d-row"><span>عربی متن کا سائز</span><div class="stepper"><button data-s="ar" data-d="-1" aria-label="چھوٹا">−</button><span id="v-ar"></span><button data-s="ar" data-d="1" aria-label="بڑا">+</button></div></div>
    <div class="d-row"><span>اردو متن کا سائز</span><div class="stepper"><button data-s="ur" data-d="-1" aria-label="چھوٹا">−</button><span id="v-ur"></span><button data-s="ur" data-d="1" aria-label="بڑا">+</button></div></div>
    <div class="d-row"><span>سطروں کا فاصلہ</span><div class="seg" id="seg-lh" role="group" aria-label="سطروں کا فاصلہ"><button type="button" data-v="0">عام</button><button type="button" data-v="1">کھلا</button><button type="button" data-v="2">بہت کھلا</button></div></div>
    <div class="d-row"><span>نرم رنگ (آنکھوں کے لیے)</span><button class="switch" id="sw-sepia" role="switch" aria-checked="${S.get('sepia',false)}"></button></div>
    <div class="d-row"><span>خود جانچ (ترجمہ چھپائیں)</span><button class="switch" id="sw-test" role="switch" aria-checked="${S.get('test',false)}"></button></div>
    <div class="d-row"><span>عربی دھندلی کریں (دبا کر دیکھیں)</span><button class="switch" id="sw-har" role="switch" aria-checked="${S.get('har',false)}"></button></div>
    <div class="d-row" id="row-awake" hidden><span>پڑھتے وقت اسکرین جاگتی رکھیں</span><button class="switch" id="sw-awake" role="switch" aria-checked="${S.get('awake',false)}"></button></div>
    <div class="d-row col"><label for="exam-d">امتحان کی تاریخ</label><div class="exam-in"><input type="date" id="exam-d" value="${S.get('exam','')}"><button type="button" id="exam-x" aria-label="تاریخ ہٹائیں">${MQ.i('x-lg')}</button></div></div>
    <button class="d-link" id="inst-btn" hidden style="width:100%;text-align:start">${MQ.i('download')}<span>ایپ انسٹال کریں</span></button>
    <button class="d-link" id="share-site" style="width:100%;text-align:start">${MQ.i('send')}<span>سائٹ دوستوں کو بھیجیں</span></button>
    <h3>معلومات</h3><a class="d-link" href="about.html">${MQ.i('info-circle')}<span>ہمارے بارے میں</span></a><a class="d-link" href="me.html">${MQ.i('person-circle')}<span>بنانے والا</span></a><a class="d-link" href="privacy.html">${MQ.i('shield-check')}<span>رازداری</span></a><a class="d-link" href="terms.html">${MQ.i('file-earmark-text')}<span>استعمال کی شرائط</span></a>
    <h3>ریکارڈ</h3><button class="d-link" id="reset-btn" style="width:100%;text-align:start">${MQ.i('arrow-counterclockwise')}<span>پڑھائی کا ریکارڈ مٹائیں</span></button>`;
  const ft=document.createElement('footer'); ft.className='site-foot'; ft.innerHTML='<p class="made" dir="ltr">Made with <span class="heart" role="img" aria-label="love">♥</span> by <a href="me.html" class="made-by"><b>M. Ijaz</b></a></p><nav aria-label="معلومات"><a href="about.html">ہمارے بارے میں</a><a href="privacy.html">رازداری</a><a href="terms.html">استعمال کی شرائط</a></nav><small dir="ltr">© 2026 Mutalea Quran</small>';
  document.body.prepend(h); document.body.append(back,dr,ft); setTheme(root.getAttribute('data-theme')==='dark'?'dark':'light');
  const $=id=>document.getElementById(id), show=()=>{ $('v-ar').textContent=MQ.nUr(Math.round(S.get('ar',1)*100))+'%'; $('v-ur').textContent=MQ.nUr(Math.round(S.get('ur',1)*100))+'%'; }; show();
  document.body.classList.toggle('test',!!S.get('test',false)); document.body.classList.toggle('hide-ar',!!S.get('har',false));
  const open=v=>{ dr.classList.toggle('open',v); back.classList.toggle('open',v); document.body.classList.toggle('drawer-lock',v); };
  $('menu-btn').onclick=()=>open(true); $('d-close').onclick=()=>open(false); back.onclick=()=>open(false); $('theme-btn').onclick=toggleTheme;
  dr.addEventListener('click',e=>{ const b=e.target.closest('[data-s]'); if(b){ stepScale(b.dataset.s,+b.dataset.d); show(); } });
  /* exam date, install, share-site, study days */
  $('exam-d').onchange=e=>{ e.target.value?S.set('exam',e.target.value):S.del('exam'); MQ.toast('امتحان کی تاریخ محفوظ ہو گئی'); };
  $('exam-x').onclick=()=>{ $('exam-d').value=''; S.del('exam'); };
  if(window.__mqInstall) $('inst-btn').hidden=false; addEventListener('mq-installable',()=>{ $('inst-btn').hidden=false; });
  $('inst-btn').onclick=async()=>{ const e=window.__mqInstall; if(!e) return; e.prompt(); try{ await e.userChoice; }catch(_){} window.__mqInstall=null; $('inst-btn').hidden=true; };
  $('share-site').onclick=()=>{ const u=new URL('index.html',location.href).href, txt='مطالعہ قرآن — سیکنڈ ایئر کی تیاری (آیات، ترجمہ، سوال جواب، ٹیسٹ)'; if(navigator.share) navigator.share({title:'مطالعہ قرآن',text:txt,url:u}).catch(()=>{}); else if(navigator.clipboard) navigator.clipboard.writeText(txt+'\n'+u).then(()=>MQ.toast('لنک کاپی ہو گیا')).catch(()=>MQ.toast('کاپی نہیں ہو سکا')); };
  try{ const d=MQ.today(), a=S.get('days',[]); if(a[a.length-1]!==d){ a.push(d); S.set('days',a.slice(-400)); } }catch(_){}
  /* keep the screen on while reading (only where the browser supports it) */
  let wl=null; const awake=async()=>{ try{ if(S.get('awake',false)&&document.visibilityState==='visible'&&!wl){ wl=await navigator.wakeLock.request('screen'); wl.addEventListener('release',()=>{ wl=null; }); } else if(!S.get('awake',false)&&wl){ await wl.release(); wl=null; } }catch(_){ wl=null; } };
  if('wakeLock' in navigator){ $('row-awake').hidden=false; awake(); document.addEventListener('visibilitychange',awake);
    $('sw-awake').onclick=e=>{ const on=!S.get('awake',false); S.set('awake',on); e.currentTarget.setAttribute('aria-checked',on); awake(); MQ.toast(on?'اب اسکرین بند نہیں ہو گی':'اسکرین عام طرح بند ہو گی'); }; }
  /* back-to-top button */
  const up=document.createElement('button'); up.type='button'; up.className='to-top'; up.setAttribute('aria-label','اوپر جائیں'); up.innerHTML=MQ.i('arrow-up'); document.body.appendChild(up);
  let ut; addEventListener('scroll',()=>{ clearTimeout(ut); ut=setTimeout(()=>up.classList.toggle('show',scrollY>700),80); },{passive:true});
  up.onclick=()=>scrollTo({top:0,behavior:'smooth'});
  $('sw-har').onclick=e=>{ const on=!S.get('har',false); S.set('har',on); e.currentTarget.setAttribute('aria-checked',on); document.body.classList.toggle('hide-ar',on); document.querySelectorAll('.v-ar.shown').forEach(x=>x.classList.remove('shown')); };
  document.addEventListener('click',e=>{ const v=e.target.closest('.v-ar'); if(v&&document.body.classList.contains('hide-ar')) v.classList.toggle('shown'); });
  /* sepia reading colours + line spacing */
  const setLh=v=>{ ['lh1','lh2'].forEach(c=>root.classList.remove(c)); if(v) root.classList.add('lh'+v); document.querySelectorAll('#seg-lh button').forEach(b=>b.classList.toggle('on',+b.dataset.v===v)); };
  setLh(+S.get('lh',0)); $('seg-lh').onclick=e=>{ const b=e.target.closest('button'); if(!b) return; const v=+b.dataset.v; S.set('lh',v); setLh(v); };
  $('sw-sepia').onclick=e=>{ const on=!S.get('sepia',false); S.set('sepia',on); e.currentTarget.setAttribute('aria-checked',on); root.classList.toggle('sepia',on); };
  $('sw-test').onclick=e=>{ const on=!S.get('test',false); S.set('test',on); e.currentTarget.setAttribute('aria-checked',on); document.body.classList.toggle('test',on); };
  $('reset-btn').onclick=()=>{ if(confirm('پڑھے ہوئے اسباق اور محفوظ مقام مٹ جائیں گے۔ ٹھیک ہے؟')){ S.clearProgress(); location.reload(); } };
  let sx=null; dr.addEventListener('touchstart',e=>{ sx=e.touches[0].clientX; },{passive:true}); dr.addEventListener('touchend',e=>{ if(sx!==null&&e.changedTouches[0].clientX-sx>60) open(false); sx=null; },{passive:true});
  document.addEventListener('keydown',e=>{ if(e.key==='Escape') open(false); });
  /* header tucks away while reading down, returns on scroll up */
  let last=scrollY, tick=false;
  addEventListener('scroll',()=>{ if(tick) return; tick=true; requestAnimationFrame(()=>{ const y=scrollY, d=y-last; root.classList.toggle('scrolled',y>4); if(o.progress){ const mx=root.scrollHeight-root.clientHeight; h.style.setProperty('--rp',mx>0?Math.min(1,Math.max(0,y/mx)):0); }
    if(y<=90||dr.classList.contains('open')){ root.classList.remove('hide-bars'); last=y; } else if(Math.abs(d)>=10){ root.classList.toggle('hide-bars',d>0); last=y; } tick=false; }); },{passive:true});
};
/* bottom dock: switch between the four sections of the current lesson */
MQ.dock=function(id,cur){
  const D=[['content','آیات و ترجمہ','book-half'],['qa','سوال و جواب','chat-left-text'],['quiz','ٹیسٹ','ui-radios']];
  const rr=MQ.ref(id); if(rr&&rr.ref.ex) D.push(['ex','مشق','pencil-square']);
  const n=document.createElement('nav'); n.className='dock'; n.setAttribute('aria-label','سبق کے حصے');
  n.innerHTML=D.map(d=>`<a href="section.html?id=${id}&s=${d[0]}" class="${d[0]===cur?'on':''}"${d[0]===cur?' aria-current="page"':''}>${MQ.i(d[2])}<span>${d[1]}</span>${d[3]?`<em>${d[3]}</em>`:''}</a>`).join('');
  document.body.append(n); document.body.classList.add('has-dock');
};
MQ.gate=function(){ const g=MQ.config.gate; if(!g||!g.enabled||!g.key||S.get('unlocked','')===g.key) return Promise.resolve();
  return new Promise(res=>{ const d=document.createElement('div'); d.id='gate'; d.innerHTML=`<div class="box"><h2>مطالعہ قرآن</h2><p style="font-size:.78rem;color:var(--muted)">جاری رکھنے کے لیے پاس کی درج کریں</p><input type="password" id="gk" autocomplete="off"><div class="err" id="ge"></div><button id="gb">کھولیں</button></div>`;
    document.body.appendChild(d); const go=()=>{ if(d.querySelector('#gk').value===g.key){ S.set('unlocked',g.key); d.remove(); res(); } else d.querySelector('#ge').textContent='پاس کی درست نہیں'; };
    d.querySelector('#gb').onclick=go; d.querySelector('#gk').onkeydown=e=>{ if(e.key==='Enter') go(); }; }); };
/* zoom lock (backstop for the viewport meta) */
['gesturestart','gesturechange','gestureend'].forEach(t=>document.addEventListener(t,e=>e.preventDefault(),{passive:false}));
document.addEventListener('touchmove',e=>{ if(e.touches&&e.touches.length>1) e.preventDefault(); },{passive:false});
let lastTap=0; document.addEventListener('touchend',e=>{ const n=Date.now(); if(n-lastTap<300) e.preventDefault(); lastTap=n; },{passive:false});
MQ.boot=function(init){ document.addEventListener('DOMContentLoaded',async()=>{ await MQ.gate();
    try{ await init(); }catch(e){ console.error(e); document.getElementById('app').innerHTML='<div class="empty">صفحہ کھولنے میں خرابی ہو گئی۔ دوبارہ کوشش کریں۔</div>'; } MQ.validate(); });
  if('serviceWorker' in navigator&&location.protocol.startsWith('http')){ const had=!!navigator.serviceWorker.controller; addEventListener('load',()=>navigator.serviceWorker.register('service-worker.js').catch(()=>{}));
    navigator.serviceWorker.addEventListener('controllerchange',()=>{ if(!had||document.querySelector('.upd-bar')) return; const b=document.createElement('div'); b.className='resume-bar upd-bar'; b.setAttribute('role','status'); b.innerHTML=`<span>${MQ.i('arrow-clockwise')} سائٹ کا نیا ورژن آ گیا ہے</span><button type="button">تازہ کریں</button>`; document.body.appendChild(b); b.querySelector('button').onclick=()=>location.reload(); }); }
  addEventListener('offline',()=>MQ.toast('انٹرنیٹ بند ہے — سائٹ پھر بھی چلتی رہے گی')); addEventListener('online',()=>MQ.toast('انٹرنیٹ واپس آ گیا')); };
})();
