/* مطالعہ قرآن — shared pieces: rich text, Q&A, answer key, quiz */
(function(){
'use strict';
const LET=['A','B','C','D'];
MQ.rich=text=>{ const toks=MQ.esc(text).split(' '), out=[]; let run=[]; const flush=()=>{ if(run.length){ out.push('<span class="ari" lang="ar">'+run.join(' ')+'</span>'); run=[]; } };
  toks.forEach(t=>{ if(/[\u064B-\u0652\u0670]/.test(t)) run.push(t); else{ flush(); out.push(t); } }); flush(); return out.join(' '); };
MQ.arHtml=t=>MQ.esc(t).replace(/\((\d+)\)/g,(m,n)=>`<span class="ayah-end">﴿${MQ.nUr(n)}﴾</span>`);

MQ.qaItem=(q,n,always)=>{ const el=document.createElement('div'); el.className='qa rise'+(always?' always':''); el.style.setProperty('--i',Math.min(n,8));
  el.innerHTML=`<div class="q"><span class="n">${MQ.nUr(n)}</span><span>${MQ.rich(q.q)}</span></div><div class="hint">${MQ.i('hand-index-thumb')} جواب دیکھنے کے لیے دبائیں</div><div class="a">${MQ.rich(q.a)}${q.slo?`<div style="font-size:.68rem;color:var(--muted)">SLO: ${MQ.esc(q.slo)}</div>`:''}</div>`;
  if(!always) el.onclick=()=>el.classList.toggle('open'); return el; };

MQ.keyCard=(m,n,total)=>{ const el=document.createElement('div'); el.className='qcard rise'; el.style.setProperty('--i',Math.min(n,8));
  el.innerHTML=`<div class="qn">سوال ${MQ.nUr(n)} / ${MQ.nUr(total)}</div><div class="qt">${MQ.rich(m.q)}</div>`+m.options.map((t,i)=>`<div class="o${i===m.answer?' ok':''}" style="cursor:default"><span class="k">${LET[i]}</span><span>${MQ.rich(t)}</span></div>`).join(''); return el; };

MQ.initQuiz=(box,items,opts)=>{ const total=items.length; let answered=0, right=0, wrong=[];
  const render=()=>{ answered=0; right=0; wrong=[];
    box.innerHTML=`<div class="score"><div><b class="c" id="sc">${MQ.nUr(0)}</b><span>درست</span></div><div><b class="w" id="sw">${MQ.nUr(0)}</b><span>غلط</span></div><div><b id="st">${MQ.nUr(0)}/${MQ.nUr(total)}</b><span>جواب دیئے</span></div></div><div id="qw"></div>
      <div class="result" id="res"><div class="big" id="rp"></div><p id="rs"></p><div class="row"><button id="again">دوبارہ شروع کریں</button><button id="rw" hidden></button></div></div>`;
    const wrap=box.querySelector('#qw');
    items.forEach((m,qi)=>{ const opts=MQ.shuffle(m.options.map((t,i)=>({t,ok:i===m.answer}))), card=document.createElement('div'); card.className='qcard rise'; card.style.setProperty('--i',Math.min(qi,8));
      card.innerHTML=`<div class="qn">سوال ${MQ.nUr(qi+1)} / ${MQ.nUr(total)}</div><div class="qt">${MQ.rich(m.q)}</div>`+opts.map((p,i)=>`<button class="o" data-ok="${p.ok?1:0}"><span class="k">${LET[i]}</span><span>${MQ.rich(p.t)}</span></button>`).join('');
      card.onclick=e=>{ const b=e.target.closest('.o'); if(!b||b.disabled) return; const good=b.dataset.ok==='1';
        card.querySelectorAll('.o').forEach(x=>{ x.disabled=true; if(x.dataset.ok==='1') x.classList.add('ok'); }); if(!good) b.classList.add('bad');
        answered++; if(good) right++; else wrong.push(m); try{ let w=MQ.S.get('wrong',[]); const k=m.q; if(good) w=w.filter(x=>x!==k); else if(!w.includes(k)) w.unshift(k); MQ.S.set('wrong',w.slice(0,300)); }catch(_){} try{ navigator.vibrate&&navigator.vibrate(good?10:[12,25,12]); }catch(_){}
        box.querySelector('#sc').textContent=MQ.nUr(right); box.querySelector('#sw').textContent=MQ.nUr(wrong.length); box.querySelector('#st').textContent=`${MQ.nUr(answered)}/${MQ.nUr(total)}`; if(answered===total) finish(); };
      wrap.appendChild(card); });
    box.querySelector('#again').onclick=()=>{ render(); scrollTo({top:0,behavior:'smooth'}); }; };
  const finish=()=>{ const pct=Math.round(right/total*100), res=box.querySelector('#res');
    if(opts&&opts.key){ const b=MQ.S.get('best',{}); if(pct>(b[opts.key]||0)){ b[opts.key]=pct; MQ.S.set('best',b); } }
    box.querySelector('#rp').textContent=pct+'%'; box.querySelector('#rs').textContent=pct>=80?'ماشاء اللہ! بہت خوب':pct>=60?'اچھی کوشش — تھوڑی مزید مشق کریں':'دوبارہ آیات اور نکات پڑھیں';
    const w=box.querySelector('#rw'); if(wrong.length){ w.hidden=false; w.textContent=`غلط سوالات (${MQ.nUr(wrong.length)})`; const wl=wrong.slice(); w.onclick=()=>{ MQ.initQuiz(box,MQ.shuffle(wl)); scrollTo({top:0,behavior:'smooth'}); }; }
    res.classList.add('show'); res.scrollIntoView({behavior:'smooth',block:'center'}); };
  render(); };
})();
