/* مطالعہ قرآن — login gate. Hides the page until the student is signed in and approved,
   and replaces the lesson loaders so lessons come from the protected database (see auth.js). */
(function(){
'use strict';
var MQ=window.MQ=window.MQ||{};
var page=document.body?document.body.getAttribute('data-page'):'';
if(page==='doc')return;
var wa=(MQ.config&&MQ.config.links&&MQ.config.links.whatsapp)||'';
MQ.authReady=new Promise(function(res){ MQ._authOk=res; });
var ov=document.createElement('div'); ov.id='mq-gate'; ov.setAttribute('role','dialog'); ov.setAttribute('aria-live','polite');
ov.style.cssText='position:fixed;top:0;right:0;bottom:0;left:0;z-index:99999;display:flex;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;background:var(--cream,#F5F8F3);color:var(--text,#14231C);font-family:var(--f-ui,system-ui,sans-serif);overflow:auto;line-height:2';
document.body.appendChild(ov);
function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
function btn(id,label,kind){
  var base='display:block;width:100%;box-sizing:border-box;margin:10px 0 0;padding:10px 14px;border-radius:14px;font:inherit;font-weight:600;cursor:pointer;text-align:center;text-decoration:none;';
  var st=kind==='primary'?'border:0;background:var(--btn,#2A7459);color:#fff;':'border:1px solid var(--border,#D9E5DC);background:transparent;color:inherit;';
  return '<button type="button" id="'+id+'" style="'+base+st+'">'+label+'</button>';
}
function card(inner){
  ov.innerHTML='<div style="width:100%;max-width:360px;text-align:center;background:var(--white,#fff);border:1px solid var(--border,#D9E5DC);border-radius:20px;padding:26px 20px;box-shadow:var(--shadow,0 4px 18px rgba(0,0,0,.1))"><div style="font-size:1.5rem;font-weight:700;margin-bottom:6px">مطالعہ قرآن</div>'+inner+'</div>';
}
function on(id,fn){ var e=document.getElementById(id); if(e) e.onclick=fn; }
var G=MQ.login={ handlers:{}, user:null };
G.show=function(state,info){
  info=info||{}; ov.style.display='flex'; document.documentElement.style.overflow='hidden';
  if(state==='loading'){ card('<p style="margin:14px 0 4px">لوڈ ہو رہا ہے…</p>'); return; }
  if(state==='signin'){
    card('<p style="margin:8px 0 12px">اسباق دیکھنے کے لیے اپنے گوگل اکاؤنٹ سے سائن اِن کریں۔</p>'+btn('g-in','گوگل سے سائن اِن کریں','primary')+(info.err?'<p style="color:var(--bad,#C94A4A);font-size:.9rem;margin:12px 0 0">'+esc(info.err)+'</p>':''));
    on('g-in',function(){ G.handlers.signIn&&G.handlers.signIn(); }); return;
  }
  if(state==='pending'||state==='blocked'){
    var msg=state==='pending'?'آپ کی درخواست بھیج دی گئی ہے۔ رسائی منظور ہونے کا انتظار کریں؛ منظوری کے لیے نیچے دیے گئے بٹن سے واٹس ایپ پر رابطہ کریں۔':'اس اکاؤنٹ کے لیے رسائی فی الحال بند ہے۔ مزید معلومات کے لیے واٹس ایپ پر رابطہ کریں۔';
    var text=encodeURIComponent('السلام علیکم! مطالعہ قرآن سائٹ کے لیے میری رسائی منظور کر دیں۔ میرا ای میل: '+(info.email||''));
    card('<p style="margin:8px 0">'+msg+'</p><p dir="ltr" style="margin:6px 0;font-size:.9rem;opacity:.8;word-break:break-all">'+esc(info.email||'')+'</p>'
      +(wa?'<a href="https://wa.me/'+esc(wa)+'?text='+text+'" target="_blank" rel="noopener noreferrer" style="display:block;margin:10px 0 0;padding:10px 14px;border-radius:14px;background:var(--btn,#2A7459);color:#fff;font-weight:600;text-decoration:none">واٹس ایپ پر رابطہ کریں</a>':'')
      +(state==='pending'?btn('g-re','دوبارہ جانچیں'):'')+btn('g-out','سائن آؤٹ'));
    on('g-re',function(){ G.handlers.recheck&&G.handlers.recheck(); }); on('g-out',function(){ G.handlers.signOut&&G.handlers.signOut(); }); return;
  }
  if(state==='error'){
    card('<p style="margin:8px 0 4px">'+esc(info.msg||'اکاؤنٹ کی جانچ نہیں ہو سکی۔ انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔')+'</p>'+btn('g-retry','دوبارہ کوشش کریں','primary'));
    on('g-retry',function(){ location.reload(); }); return;
  }
};
G.hide=function(){ ov.style.display='none'; document.documentElement.style.overflow=''; };
G.show('loading');
/* lesson loaders: wait for approval, then read from the protected database */
var cache={};
MQ.chapters=MQ.chapters||{}; MQ.exercises=MQ.exercises||{};
MQ.load=function(id){
  if(MQ.chapters[id]) return Promise.resolve(MQ.chapters[id]);
  if(!MQ.ref(id)) return Promise.resolve(null);
  if(cache['c'+id]) return cache['c'+id];
  return cache['c'+id]=MQ.authReady.then(function(){ return MQ.fetchDoc('ch_'+id); }).then(function(o){ if(o) MQ.chapters[id]=o; else delete cache['c'+id]; return o; });
};
MQ.loadEx=function(id){
  if(MQ.exercises[id]) return Promise.resolve(MQ.exercises[id]);
  if(cache['e'+id]) return cache['e'+id];
  return cache['e'+id]=MQ.authReady.then(function(){ return MQ.fetchDoc('ex_'+id); }).then(function(o){ if(o) MQ.exercises[id]=o; else delete cache['e'+id]; return o; });
};
})();
