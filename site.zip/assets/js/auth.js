/* مطالعہ قرآن — Firebase sign-in (Google + username/email & password), approval, maintenance, access expiry,
   notifications feed and protected lesson loading. Screens live in gate.js, bell/toast in notify.js. */
const CFG = window.MQ_FIREBASE, MQ = window.MQ, G = MQ.login;
const USER_DOMAIN = 'mq-students.app';          /* username-only accounts are stored as username@mq-students.app */
let fbApp, fbAuth, fbStore;
if (G) {
  const B = 'https://www.gstatic.com/firebasejs/10.12.2/';
  try {
    [fbApp, fbAuth, fbStore] = await Promise.all([import(B + 'firebase-app.js'), import(B + 'firebase-auth.js'), import(B + 'firebase-firestore.js')]);
  } catch (e) {
    G.show('error', { msg: 'ضروری فائلیں لوڈ نہیں ہو سکیں۔ پہلی بار سائن اِن کے لیے انٹرنیٹ درکار ہے۔' });
  }
  if (fbApp) start();
}
function start() {
  const { initializeApp } = fbApp;
  const A = fbAuth, S = fbStore;
  const { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signOut,
    createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile, sendPasswordResetEmail } = A;
  const { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, doc, getDoc, getDocFromCache, setDoc, updateDoc, serverTimestamp,
    collection, query, orderBy, limit, onSnapshot } = S;
  const app = initializeApp(CFG), auth = getAuth(app);
  let db;
  try { db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }); }
  catch (e) { db = initializeFirestore(app, {}); }
  const isAdmin = u => !!(u && u.email && u.email.toLowerCase() === CFG.adminEmail.toLowerCase());
  let revMap = {}, revReady = Promise.resolve(), site = {}, unsubN = null, unsubSelf = null, lastKey = '', hold = false, flash = null;

  async function readDoc(ref) {
    if (navigator.onLine === false) { try { return await getDocFromCache(ref); } catch (e) {} }
    try { return await getDoc(ref); } catch (e) { return await getDocFromCache(ref); }
  }
  /* public settings: site colour + maintenance / sign-up switches */
  const pub = Promise.all([
    readDoc(doc(db, 'settings', 'theme')).then(s => { if (window.MQ_applyTheme) window.MQ_applyTheme(s.exists() ? s.data() : null); }).catch(() => {}),
    readDoc(doc(db, 'settings', 'site')).then(s => { if (s.exists()) site = s.data(); }).catch(() => {})
  ]);

  const ms = t => (t && typeof t.toMillis === 'function') ? t.toMillis() : (t && t.seconds ? t.seconds * 1000 : 0);
  const uname = u => { const e = (u.email || '').toLowerCase(); return e.endsWith('@' + USER_DOMAIN) ? e.split('@')[0] : ''; };
  const provider = u => (u.providerData && u.providerData[0] && u.providerData[0].providerId) || 'password';

  async function status(u) {
    if (isAdmin(u)) return { st: 'approved' };
    const ref = doc(db, 'users', u.uid), snap = await readDoc(ref);
    if (!snap.exists()) {
      if (site.signupOpen === false) { const e = new Error('closed'); e.code = 'mq/signup-closed'; throw e; }
      const d = { email: u.email || '', name: u.displayName || uname(u) || '', status: 'pending', provider: provider(u), createdAt: serverTimestamp() };
      if (uname(u)) d.username = uname(u);
      await setDoc(ref, d);
      return { st: 'pending' };
    }
    if (navigator.onLine !== false) updateDoc(ref, { lastSeen: serverTimestamp() }).catch(() => {});
    const d = snap.data(); let st = d.status || 'pending';
    const exp = ms(d.expiresAt);
    if (st === 'approved' && exp && exp < Date.now()) st = 'expired';
    return { st, data: d };
  }
  async function loadRev() {
    try { const s = await readDoc(doc(db, 'content', '_rev')); if (s.exists()) revMap = s.data().map || {}; } catch (e) {}
  }
  MQ.fetchDoc = async function (key) {
    await revReady;
    const ref = doc(db, 'content', key); let cached = null;
    try { cached = await getDocFromCache(ref); } catch (e) {}
    const want = revMap[key];
    if (cached && cached.exists()) { const d = cached.data(); if (want === undefined || d.rev === want) return JSON.parse(d.json); }
    try { const s = await getDoc(ref); if (s.exists()) return JSON.parse(s.data().json); } catch (e) {}
    return cached && cached.exists() ? JSON.parse(cached.data().json) : null;
  };

  function addDrawerItems(u) {
    let tries = 0;
    (function t() {
      const dr = document.getElementById('drawer');
      if (!dr) { if (++tries < 40) setTimeout(t, 250); return; }
      if (document.getElementById('mq-signout')) return;
      const who = u.displayName || uname(u) || u.email || '';
      let h = '<h3>اکاؤنٹ</h3><div class="d-row" dir="ltr" style="font-size:.85rem;opacity:.8;word-break:break-all">' + who.replace(/[<>&]/g, '') + '</div>';
      if (isAdmin(u)) h += '<a class="d-link" href="admin.html"><i class="bi bi-person-gear"></i><span>ایڈمن پیج</span></a>';
      h += '<button class="d-link" id="mq-signout" style="width:100%;text-align:start"><i class="bi bi-box-arrow-right"></i><span>سائن آؤٹ</span></button>';
      dr.insertAdjacentHTML('beforeend', h);
      document.getElementById('mq-signout').onclick = () => signOut(auth).then(() => location.reload());
    })();
  }

  /* live notifications feed (approved students + admin) */
  function startNotifications() {
    if (unsubN || !MQ.notify) return;
    try {
      unsubN = onSnapshot(query(collection(db, 'notifications'), orderBy('createdAt', 'desc'), limit(30)), snap => {
        MQ.notify.set(snap.docs.map(d => { const x = d.data(); return { id: d.id, title: x.title || '', body: x.body || '', type: x.type || 'info', ts: ms(x.createdAt) || Date.now(), exp: ms(x.expiresAt) }; }));
      }, () => {});
    } catch (e) {}
  }
  /* react at once when the admin approves / blocks / changes expiry for this account */
  function watchSelf(u) {
    if (unsubSelf || isAdmin(u)) return;
    try {
      unsubSelf = onSnapshot(doc(db, 'users', u.uid), s => {
        if (!s.exists()) return; const d = s.data(), k = (d.status || '') + '|' + ms(d.expiresAt);
        if (lastKey && k !== lastKey) { lastKey = k; check(u, true); } else lastKey = k;
      }, () => {});
    } catch (e) {}
  }

  async function check(u, quiet) {
    if (!quiet) G.show('loading');
    await pub;
    if (site.maintenance && !isAdmin(u)) { G.show('maintenance', { msg: site.maintenanceMsg }); return; }
    let r;
    try { r = await status(u); }
    catch (e) {
      if (e && e.code === 'mq/signup-closed') { flash = G.errText('mq/signup-closed'); await signOut(auth).catch(() => {}); return; }
      G.show('error'); return;
    }
    watchSelf(u);
    if (r.st === 'approved') {
      if (!MQ._approved) { MQ._approved = true; revReady = loadRev(); MQ._authOk(); addDrawerItems(u); if (MQ.onApproved) { try { MQ.onApproved(u, { isAdmin: isAdmin(u), name: u.displayName || uname(u) || u.email || '', signOut: () => signOut(auth).then(() => location.reload()) }); } catch (e) {} } }
      G.hide(); startNotifications();
    } else G.show(r.st === 'blocked' || r.st === 'expired' ? r.st : 'pending', { email: u.email && !u.email.endsWith('@' + USER_DOMAIN) ? u.email : '', name: u.displayName || uname(u) });
  }
  const toEmail = id => id.includes('@') ? id.trim() : id.trim().toLowerCase() + '@' + USER_DOMAIN;

  G.handlers.signIn = async function () {
    const p = new GoogleAuthProvider();
    try { await signInWithPopup(auth, p); }
    catch (e) {
      if (e && (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment')) { try { await signInWithRedirect(auth, p); return; } catch (e2) {} }
      if (e && (e.code === 'auth/popup-closed-by-user' || e.code === 'auth/cancelled-popup-request')) return;
      G.show('signin', { err: G.errText(e && e.code) });
    }
  };
  G.handlers.emailSignIn = async function (o) {
    try { await signInWithEmailAndPassword(auth, toEmail(o.id), o.password); return null; }
    catch (e) { return (e && e.code) || 'mq/generic'; }
  };
  G.handlers.emailSignUp = async function (o) {
    if (site.signupOpen === false) return 'mq/signup-closed';
    hold = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, o.email ? o.id.trim() : o.id.trim().toLowerCase() + '@' + USER_DOMAIN, o.password);
      try { await updateProfile(cred.user, { displayName: o.name }); } catch (e) {}
      hold = false; check(cred.user);
      return null;
    } catch (e) { hold = false; return (e && e.code) || 'mq/generic'; }
  };
  G.handlers.reset = async function (email) {
    try { await sendPasswordResetEmail(auth, email); return 'ok'; }
    catch (e) { return (e && e.code === 'auth/user-not-found') ? 'ok' : ((e && e.code) || 'mq/generic'); }
  };
  G.handlers.recheck = () => { if (auth.currentUser) check(auth.currentUser); };
  G.handlers.signOut = () => signOut(auth).then(() => location.reload());
  getRedirectResult(auth).catch(() => {});
  onAuthStateChanged(auth, u => {
    if (!u) { pub.then(() => { G.mode = 'in'; const f = flash; flash = null; G.show('signin', f ? { err: f } : {}); }); return; }
    if (hold) return;
    check(u);
  });
}
