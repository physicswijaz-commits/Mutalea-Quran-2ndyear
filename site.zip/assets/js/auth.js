/* مطالعہ قرآن — Firebase sign-in, approval check and protected lesson loading. */
const CFG = window.MQ_FIREBASE, MQ = window.MQ, G = MQ.login;
let fbApp, fbAuth, fbStore;
if (G) {
  const B = 'https://www.gstatic.com/firebasejs/10.12.2/';
  try {
    [fbApp, fbAuth, fbStore] = await Promise.all([import(B + 'firebase-app.js'), import(B + 'firebase-auth.js'), import(B + 'firebase-firestore.js')]);
  } catch (e) {
    G.show('error', { msg: 'ضروری فائلیں لوڈ نہیں ہو سکیں۔ پہلی بار سائن اِن کے لیے انٹرنیٹ درکار ہے۔' });
  }
  if (fbApp) start();
}
function start() {
  const { initializeApp } = fbApp;
  const { getAuth, onAuthStateChanged, GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, signOut } = fbAuth;
  const { initializeFirestore, persistentLocalCache, persistentMultipleTabManager, doc, getDoc, getDocFromCache, setDoc, updateDoc, serverTimestamp } = fbStore;
  const app = initializeApp(CFG), auth = getAuth(app);
  let db;
  try { db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }); }
  catch (e) { db = initializeFirestore(app, {}); }
  const isAdmin = u => !!(u && u.email && u.email.toLowerCase() === CFG.adminEmail.toLowerCase());
  let revMap = {}, revReady = Promise.resolve();

  async function readDoc(ref) {
    if (navigator.onLine === false) { try { return await getDocFromCache(ref); } catch (e) {} }
    try { return await getDoc(ref); } catch (e) { return await getDocFromCache(ref); }
  }
  async function status(u) {
    if (isAdmin(u)) return 'approved';
    const ref = doc(db, 'users', u.uid), snap = await readDoc(ref);
    if (!snap.exists()) {
      await setDoc(ref, { email: u.email || '', name: u.displayName || '', status: 'pending', createdAt: serverTimestamp() });
      return 'pending';
    }
    if (navigator.onLine !== false) updateDoc(ref, { lastSeen: serverTimestamp() }).catch(() => {});
    return snap.data().status || 'pending';
  }
  async function loadRev() {
    try { const s = await readDoc(doc(db, 'content', '_rev')); if (s.exists()) revMap = s.data().map || {}; } catch (e) {}
  }
  MQ.fetchDoc = async function (key) {
    await revReady;
    const ref = doc(db, 'content', key); let cached = null;
    try { cached = await getDocFromCache(ref); } catch (e) {}
    const want = revMap[key];
    if (cached && cached.exists()) { const d = cached.data(); if (want === undefined || d.rev === want) return JSON.parse(d.json); }
    try { const s = await getDoc(ref); if (s.exists()) return JSON.parse(s.data().json); } catch (e) {}
    return cached && cached.exists() ? JSON.parse(cached.data().json) : null;
  };

  function addDrawerItems(u) {
    let tries = 0;
    (function t() {
      const dr = document.getElementById('drawer');
      if (!dr) { if (++tries < 40) setTimeout(t, 250); return; }
      if (document.getElementById('mq-signout')) return;
      let h = '<h3>اکاؤنٹ</h3><div class="d-row" dir="ltr" style="font-size:.85rem;opacity:.8;word-break:break-all">' + (u.email || '') + '</div>';
      if (isAdmin(u)) h += '<a class="d-link" href="admin.html"><i class="bi bi-person-gear"></i><span>ایڈمن پیج</span></a>';
      h += '<button class="d-link" id="mq-signout" style="width:100%;text-align:start"><i class="bi bi-box-arrow-right"></i><span>سائن آؤٹ</span></button>';
      dr.insertAdjacentHTML('beforeend', h);
      document.getElementById('mq-signout').onclick = () => signOut(auth).then(() => location.reload());
    })();
  }

  async function showAnnouncement() {
    if (document.body.getAttribute('data-page') !== 'index') return;
    try {
      const snap = await readDoc(doc(db, 'settings', 'announcement')); const a = snap.exists() ? snap.data() : null;
      if (!a || !a.active || !String(a.text || '').trim()) return;
      const id = String(a.id || a.text); try { if (localStorage.getItem('mq_ann') === id) return; } catch (e) {}
      const host = document.getElementById('main') || document.body, d = document.createElement('div');
      d.setAttribute('role', 'status');
      d.style.cssText = 'margin:12px 14px;padding:12px 14px;border-radius:16px;background:var(--gold-light,#FFF6E0);border:1px solid var(--gold-line,#E6C566);display:flex;align-items:flex-start;gap:10px;line-height:2';
      const t = document.createElement('div'); t.style.cssText = 'flex:1;min-width:0;white-space:pre-line'; t.textContent = a.text;
      const x = document.createElement('button'); x.type = 'button'; x.textContent = '✕'; x.setAttribute('aria-label', 'بند کریں'); x.style.cssText = 'border:0;background:none;font:inherit;font-weight:700;cursor:pointer;color:inherit;padding:0 4px';
      x.onclick = () => { try { localStorage.setItem('mq_ann', id); } catch (e) {} d.remove(); };
      d.append(t, x); host.insertBefore(d, host.firstChild);
    } catch (e) {}
  }

  async function check(u) {
    G.show('loading');
    let st;
    try { st = await status(u); }
    catch (e) { G.show('error'); return; }
    if (st === 'approved') {
      revReady = loadRev(); G.hide(); MQ._authOk(); addDrawerItems(u); showAnnouncement();
    } else G.show(st === 'blocked' ? 'blocked' : 'pending', { email: u.email });
  }
  G.handlers.signIn = async function () {
    const p = new GoogleAuthProvider();
    try { await signInWithPopup(auth, p); }
    catch (e) {
      if (e && (e.code === 'auth/popup-blocked' || e.code === 'auth/operation-not-supported-in-this-environment')) { try { await signInWithRedirect(auth, p); return; } catch (e2) {} }
      if (e && e.code === 'auth/popup-closed-by-user') return;
      G.show('signin', { err: 'سائن اِن نہیں ہو سکا۔ دوبارہ کوشش کریں۔' });
    }
  };
  G.handlers.recheck = () => { if (auth.currentUser) check(auth.currentUser); };
  G.handlers.signOut = () => signOut(auth).then(() => location.reload());
  getRedirectResult(auth).catch(() => {});
  onAuthStateChanged(auth, u => { if (!u) { G.show('signin'); return; } check(u); });
}
