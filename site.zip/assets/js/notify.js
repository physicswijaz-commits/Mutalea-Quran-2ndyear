/* مطالعہ قرآن — notifications (reusable): bell in the header with a red dot, a toast that fades after a few seconds, and a history sheet.
   auth.js feeds it with MQ.notify.set(items) from the Firestore "notifications" collection. Local messages: MQ.notify.toast('text','success'). */
(function(){
'use strict';
var MQ=window.MQ=window.MQ||{};
var page=document.body?document.body.getAttribute('data-page'):'';
if(page==='doc')return;
var KEY='mq_n_seen', items=[], first=true, bell=null, sheet=null, toastEl=null, toastT=0;
var css=''
+'#mq-bell{position:relative}#mq-bell .bi{font-size:1.15rem}'
+'#mq-bell .dot{position:absolute;top:7px;inset-inline-start:9px;width:11px;height:11px;border-radius:50%;background:#E5484D;border:2px solid var(--material,#fff);display:none}'
+'#mq-bell.has .dot{display:block;animation:nPop .4s cubic-bezier(.2,1.6,.4,1)}'
+'#mq-bell.ring .bi{animation:nRing .9s ease}'
+'#mq-toast{position:fixed;top:max(10px,env(safe-area-inset-top));left:50%;z-index:99990;width:calc(100% - 24px);max-width:420px;transform:translate(-50%,-140%);opacity:0;transition:transform .45s cubic-bezier(.2,.9,.3,1.1),opacity .3s;pointer-events:none}'
+'#mq-toast.on{transform:translate(-50%,0);opacity:1;pointer-events:auto}'
+'.n-card{display:flex;gap:11px;align-items:flex-start;padding:12px 14px;border-radius:18px;background:var(--white,#fff);color:var(--text,#14231C);border:1px solid var(--border,#D9E5DC);box-shadow:0 12px 34px rgba(0,0,0,.18);line-height:1.8;cursor:pointer;position:relative;overflow:hidden}'
+'.n-ic{flex:none;width:34px;height:34px;border-radius:11px;display:grid;place-items:center;font-size:1.05rem;color:#fff;background:var(--primary,#2A7459)}'
+'.n-ic.success{background:#1F8A5B}.n-ic.warn{background:#D58A0B}.n-ic.important{background:#E5484D}.n-ic.info{background:var(--primary,#2A7459)}'
+'.n-b{flex:1;min-width:0}.n-t{font-weight:700;font-size:.95rem}.n-m{font-size:.88rem;opacity:.85;white-space:pre-line;word-break:break-word}.n-d{font-size:.74rem;opacity:.55;margin-top:2px}'
+'#mq-toast .n-bar{position:absolute;bottom:0;inset-inline:0;height:3px;background:var(--primary,#2A7459);transform-origin:right;animation:nBar 5s linear forwards}'
+'#mq-sheet{position:fixed;inset:0;z-index:99991;display:none}#mq-sheet.on{display:block}'
+'#mq-sheet .bk{position:absolute;inset:0;background:rgba(10,20,15,.45);opacity:0;transition:opacity .25s}'
+'#mq-sheet .pn{position:absolute;left:50%;bottom:0;width:100%;max-width:560px;max-height:82vh;display:flex;flex-direction:column;background:var(--cream,#F5F8F3);color:var(--text,#14231C);border-radius:24px 24px 0 0;transform:translate(-50%,100%);transition:transform .35s cubic-bezier(.2,.9,.3,1);padding-bottom:env(safe-area-inset-bottom);box-shadow:0 -10px 40px rgba(0,0,0,.25)}'
+'#mq-sheet.show .bk{opacity:1}#mq-sheet.show .pn{transform:translate(-50%,0)}'
+'#mq-sheet .gr{width:42px;height:5px;border-radius:9px;background:var(--border,#cfd9d2);margin:9px auto 4px}'
+'#mq-sheet .hd{display:flex;align-items:center;justify-content:space-between;padding:6px 18px 10px}'
+'#mq-sheet .hd b{font-size:1.1rem}#mq-sheet .hd button{border:0;background:var(--soft,#EAF1EC);color:inherit;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1rem}'
+'#mq-sheet .ls{overflow:auto;padding:0 12px 16px;display:grid;gap:8px;-webkit-overflow-scrolling:touch}'
+'#mq-sheet .n-card{cursor:default;box-shadow:none}#mq-sheet .n-card.new{border-color:var(--primary,#2A7459);background:var(--primary-light,#EAF5EF)}'
+'#mq-sheet .em{text-align:center;opacity:.6;padding:34px 10px}#mq-sheet .em .bi{font-size:2.4rem;display:block;margin-bottom:6px}'
+'@keyframes nPop{from{transform:scale(0)}}@keyframes nBar{to{transform:scaleX(0)}}'
+'@keyframes nRing{15%{transform:rotate(18deg)}30%{transform:rotate(-16deg)}45%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}75%{transform:rotate(4deg)}}'
+'@media(prefers-reduced-motion:reduce){#mq-toast,#mq-sheet .pn{transition:none}#mq-bell .bi,#mq-toast .n-bar{animation:none!important}}';
var st=document.createElement('style'); st.textContent=css; document.head.appendChild(st);

function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
var ICON={info:'bi-info-lg',success:'bi-check-lg',warn:'bi-exclamation-lg',important:'bi-megaphone-fill'};
function ago(ts){
  var s=Math.max(0,(Date.now()-ts)/1000);
  if(s<60) return 'ابھی';
  if(s<3600) return Math.floor(s/60)+' منٹ پہلے';
  if(s<86400) return Math.floor(s/3600)+' گھنٹے پہلے';
  if(s<86400*30) return Math.floor(s/86400)+' دن پہلے';
  return new Date(ts).toLocaleDateString('en-GB');
}
function seen(){ try{ return +localStorage.getItem(KEY)||0; }catch(e){ return 0; } }
function markSeen(){ var m=items.reduce(function(a,n){return Math.max(a,n.ts);},0); try{ localStorage.setItem(KEY,String(Math.max(m,seen()))); }catch(e){} refresh(); }
function unread(){ var s=seen(); return items.filter(function(n){return n.ts>s;}); }
function cardHtml(n,cls){
  return '<div class="n-card '+(cls||'')+'"><div class="n-ic '+esc(n.type||'info')+'"><i class="bi '+(ICON[n.type]||ICON.info)+'"></i></div><div class="n-b"><div class="n-t">'+esc(n.title)+'</div>'+(n.body?'<div class="n-m">'+esc(n.body)+'</div>':'')+(n.ts?'<div class="n-d">'+ago(n.ts)+'</div>':'')+'</div></div>';
}
function refresh(){
  if(!bell) return;
  var u=unread().length; bell.classList.toggle('has',u>0);
  bell.setAttribute('aria-label',u?('اطلاعات — '+u+' نئی'):'اطلاعات');
}
function ensureBell(){
  if(bell&&document.body.contains(bell)) return;
  var pg=document.querySelector('header.bar .pill-group'), th=document.getElementById('theme-btn');
  bell=document.createElement('button'); bell.type='button'; bell.id='mq-bell'; bell.className='icon-btn';
  bell.innerHTML='<i class="bi bi-bell"></i><span class="dot"></span>';
  bell.onclick=openSheet;
  if(pg){ pg.insertBefore(bell,th||null); }
  else { bell.style.cssText='position:fixed;top:calc(10px + env(safe-area-inset-top));inset-inline-start:12px;z-index:60;width:40px;height:40px;border-radius:50%;border:1px solid var(--border,#ddd);background:var(--white,#fff);display:grid;place-items:center'; document.body.appendChild(bell); }
  refresh();
}
function waitHeader(){ var n=0; (function t(){ if(document.querySelector('header.bar .pill-group')||++n>30){ ensureBell(); } else setTimeout(t,200); })(); }

function toast(n){
  if(!toastEl){ toastEl=document.createElement('div'); toastEl.id='mq-toast'; toastEl.setAttribute('role','status'); document.body.appendChild(toastEl); }
  clearTimeout(toastT); toastEl.classList.remove('on');
  void toastEl.offsetWidth;
  toastEl.innerHTML=cardHtml(n)+'<div class="n-bar" style="inset-inline:0;left:0;right:0"></div>';
  toastEl.firstChild.onclick=function(){ hideToast(); if(n.local) return; openSheet(); };
  toastEl.classList.add('on');
  if(bell&&!n.local){ bell.classList.remove('ring'); void bell.offsetWidth; bell.classList.add('ring'); }
  toastT=setTimeout(hideToast,5200);
}
function hideToast(){ if(toastEl) toastEl.classList.remove('on'); }

function openSheet(){
  if(!sheet){
    sheet=document.createElement('div'); sheet.id='mq-sheet'; sheet.setAttribute('role','dialog'); sheet.setAttribute('aria-label','اطلاعات');
    sheet.innerHTML='<div class="bk"></div><div class="pn"><div class="gr"></div><div class="hd"><b>اطلاعات</b><button type="button" aria-label="بند کریں">✕</button></div><div class="ls"></div></div>';
    document.body.appendChild(sheet);
    sheet.querySelector('.bk').onclick=closeSheet; sheet.querySelector('.hd button').onclick=closeSheet;
    document.addEventListener('keydown',function(e){ if(e.key==='Escape') closeSheet(); });
  }
  hideToast();
  var s=seen(), ls=sheet.querySelector('.ls');
  ls.innerHTML=items.length?items.map(function(n){ return cardHtml(n,n.ts>s?'new':''); }).join(''):'<div class="em"><i class="bi bi-bell-slash"></i>ابھی کوئی اطلاع نہیں</div>';
  sheet.classList.add('on'); requestAnimationFrame(function(){ sheet.classList.add('show'); });
  markSeen();
}
function closeSheet(){ if(!sheet) return; sheet.classList.remove('show'); setTimeout(function(){ sheet.classList.remove('on'); },320); }

MQ.notify={
  /* items: [{id,title,body,type,ts,exp}] newest first */
  set:function(list){
    var now=Date.now(), prev={}; items.forEach(function(n){ prev[n.id]=1; });
    items=(list||[]).filter(function(n){ return !n.exp||n.exp>now; }).sort(function(a,b){return b.ts-a.ts;});
    ensureBell(); refresh();
    var s=seen(), fresh=items.filter(function(n){ return n.ts>s&&(first?(now-n.ts<3*864e5):!prev[n.id]); });
    if(fresh.length){
      var n=fresh[0];
      if(fresh.length>1) n={title:n.title,body:(n.body?n.body+'\n':'')+'… اور '+(fresh.length-1)+' نئی اطلاعات',type:n.type,ts:n.ts};
      setTimeout(function(){ toast(n); },first?900:0);
    }
    first=false;
    if(sheet&&sheet.classList.contains('show')) markSeen();
  },
  toast:function(text,type){ toast({title:text,type:type||'info',local:true}); },
  open:openSheet
};
waitHeader();
})();
