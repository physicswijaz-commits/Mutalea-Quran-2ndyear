/* مطالعہ قرآن — notifications (reusable): bell in the header with a red dot, a toast that fades after a few seconds, and a history sheet.
   auth.js feeds it with MQ.notify.set(items) from the Firestore "notifications" collection. Local messages: MQ.notify.toast('text','success'). */
(function(){
'use strict';
var MQ=window.MQ=window.MQ||{};
var page=document.body?document.body.getAttribute('data-page'):'';
if(page==='doc')return;
var KEY='mq_n_seen', items=[], first=true, bell=null, sheet=null, toastEl=null, toastT=0;
var css=''
+'#mq-bell{position:relative}#mq-bell svg{width:20px;height:20px}'
+'#mq-bell .dot{position:absolute;top:7px;inset-inline-start:9px;width:11px;height:11px;border-radius:50%;background:#E5484D;border:2px solid var(--material,#fff);display:none}'
+'#mq-bell.has .dot{display:block;animation:nPop .4s cubic-bezier(.2,1.6,.4,1)}'
+'#mq-bell.ring svg{animation:nRing .9s ease}'
+'#mq-toast{position:fixed;top:max(10px,env(safe-area-inset-top));left:50%;z-index:99990;width:calc(100% - 24px);max-width:420px;transform:translate(-50%,-140%);opacity:0;transition:transform .45s cubic-bezier(.2,.9,.3,1.1),opacity .3s;pointer-events:none}'
+'#mq-toast.on{transform:translate(-50%,0);opacity:1;pointer-events:auto}'
+'.n-card{display:flex;gap:11px;align-items:flex-start;padding:12px 14px;border-radius:18px;background:var(--white,#fff);color:var(--text,#14231C);border:1px solid var(--border,#D9E5DC);box-shadow:0 12px 34px rgba(0,0,0,.18);line-height:1.8;cursor:pointer;position:relative;overflow:hidden}'
+'.n-ic{flex:none;width:34px;height:34px;border-radius:11px;display:grid;place-items:center;font-size:1.15rem;color:#fff;background:var(--primary,#2A7459)}'
+'.n-ic.success{background:#1F8A5B}.n-ic.warn{background:#D58A0B}.n-ic.important{background:#E5484D}.n-ic.info{background:var(--primary,#2A7459)}'
+'.n-b{flex:1;min-width:0}.n-t{font-weight:700;font-size:.95rem}.n-m{font-size:.88rem;opacity:.85;white-space:pre-line;word-break:break-word}.n-d{font-size:.74rem;opacity:.55;margin-top:2px}'
+'#mq-toast .n-bar{position:absolute;bottom:0;inset-inline:0;height:3px;background:var(--primary,#2A7459);transform-origin:right;animation:nBar 5s linear forwards}'
+'#mq-sheet{position:fixed;inset:0;z-index:99991;display:none}#mq-sheet.on{display:block}'
+'#mq-sheet .bk{position:absolute;inset:0;background:rgba(10,20,15,.45);opacity:0;transition:opacity .25s}'
+'#mq-sheet .pn{position:absolute;left:50%;bottom:0;width:100%;max-width:560px;max-height:82vh;display:flex;flex-direction:column;background:var(--cream,#F5F8F3);color:var(--text,#14231C);border-radius:24px 24px 0 0;transform:translate(-50%,100%);transition:transform .35s cubic-bezier(.2,.9,.3,1);padding-bottom:env(safe-area-inset-bottom);box-shadow:0 -10px 40px rgba(0,0,0,.25)}'
+'#mq-sheet.show .bk{opacity:1}#mq-sheet.show .pn{transform:translate(-50%,0)}'
+'#mq-sheet .gr{width:42px;height:5px;border-radius:9px;background:var(--border,#cfd9d2);margin:9px auto 4px}'
+'#mq-sheet .hd{display:flex;align-items:center;justify-content:space-between;padding:6px 18px 10px}'
+'#mq-sheet .hd b{font-size:1.1rem}#mq-sheet .hd button{border:0;background:var(--soft,#EAF1EC);color:inherit;width:36px;height:36px;border-radius:50%;cursor:pointer;font-size:1rem}'
+'#mq-sheet .ls{overflow:auto;padding:0 12px 16px;display:grid;gap:8px;-webkit-overflow-scrolling:touch}'
+'#mq-sheet .n-card{cursor:default;box-shadow:none}#mq-sheet .n-card.new{border-color:var(--primary,#2A7459);background:var(--primary-light,#EAF5EF)}'
+'#mq-sheet .em{text-align:center;opacity:.6;padding:34px 10px}#mq-sheet .em svg{width:2.4rem;height:2.4rem;margin-bottom:6px}'
+'@keyframes nPop{from{transform:scale(0)}}@keyframes nBar{to{transform:scaleX(0)}}'
+'@keyframes nRing{15%{transform:rotate(18deg)}30%{transform:rotate(-16deg)}45%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}75%{transform:rotate(4deg)}}'
+'@media(prefers-reduced-motion:reduce){#mq-toast,#mq-sheet .pn{transition:none}#mq-bell svg,#mq-toast .n-bar{animation:none!important}}';
var st=document.createElement('style'); st.textContent=css; document.head.appendChild(st);

function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
function sv(p){ return '<svg viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+p+'</svg>'; }
var ICON={info:sv('<path d="M12 11v6M12 7v.1"/>'),success:sv('<path d="m5 12.5 4.5 4.5L19 7.5"/>'),warn:sv('<path d="M12 6v8M12 18v.1"/>'),important:sv('<path d="M4 10v4h3l6 4V6L7 10zM17 9a4 4 0 0 1 0 6"/>')};
var BELL=sv('<path d="M6 9a6 6 0 0 1 12 0c0 6 2.5 7.5 2.5 7.5h-17S6 15 6 9zM10 20a2 2 0 0 0 4 0"/>'), BELLOFF=sv('<path d="M3 3l18 18M8.5 4.7A6 6 0 0 1 18 9c0 3 .6 4.7 1.3 5.8M6 9c0 6-2.5 7.5-2.5 7.5H14M10 20a2 2 0 0 0 4 0"/>');
var CFG=window.MQ_BELL||{host:'header.bar .pill-group',before:'#theme-btn',cls:'icon-btn'};
function ago(ts){
  var s=Math.max(0,(Date.now()-ts)/1000);
  if(s<60) return 'ابھی';
  if(s<3600) return Math.floor(s/60)+' منٹ پہلے';
  if(s<86400) return Math.floor(s/3600)+' گھنٹے پہلے';
  if(s<86400*30) return Math.floor(s/86400)+' دن پہلے';
  return new Date(ts).toLocaleDateString('en-GB');
}
function seen(){ try{ return +localStorage.getItem(KEY)||0; }catch(e){ return 0; } }
function markSeen(){ var m=items.reduce(function(a,n){return Math.max(a,n.ts);},0); try{ localStorage.setItem(KEY,String(Math.max(m,seen()))); }catch(e){} refresh(); }
function unread(){ var s=seen(); return items.filter(function(n){return n.ts>s;}); }
function cardHtml(n,cls){
  return '<div class="n-card '+(cls||'')+'"><div class="n-ic '+esc(n.type||'info')+'">'+(ICON[n.type]||ICON.info)+'</div><div class="n-b"><div class="n-t">'+esc(n.title)+'</div>'+(n.body?'<div class="n-m">'+esc(n.body)+'</div>':'')+(n.ts?'<div class="n-d">'+ago(n.ts)+'</div>':'')+'</div></div>';
}
function refresh(){
  if(!bell) return;
  var u=unread().length; bell.classList.toggle('has',u>0);
  bell.setAttribute('aria-label',u?('اطلاعات — '+u+' نئی'):'اطلاعات');
}
function ensureBell(){
  if(bell&&document.body.contains(bell)) return;
  var pg=document.querySelector(CFG.host), th=CFG.before?document.querySelector(CFG.before):null;
  bell=document.createElement('button'); bell.type='button'; bell.id='mq-bell'; bell.className=CFG.cls;
  bell.innerHTML=BELL+'<span class="dot"></span>';
  bell.onclick=openSheet;
  if(pg){ pg.insertBefore(bell,CFG.first?pg.firstChild:(th||null)); }
  else { bell.style.cssText='position:fixed;top:calc(10px + env(safe-area-inset-top));inset-inline-start:12px;z-index:60;width:40px;height:40px;border-radius:50%;border:1px solid var(--border,#ddd);background:var(--white,#fff);display:grid;place-items:center'; document.body.appendChild(bell); }
  refresh();
}
function waitHeader(){ var n=0; (function t(){ if(document.querySelector(CFG.host)||++n>30){ ensureBell(); } else setTimeout(t,200); })(); }

function toast(n){
  if(!toastEl){ toastEl=document.createElement('div'); toastEl.id='mq-toast'; toastEl.setAttribute('role','status'); document.body.appendChild(toastEl); }
  clearTimeout(toastT); toastEl.classList.remove('on');
  void toastEl.offsetWidth;
  toastEl.innerHTML=cardHtml(n)+'<div class="n-bar" style="inset-inline:0;left:0;right:0"></div>';
  toastEl.firstChild.onclick=function(){ hideToast(); if(n.local) return; openSheet(); };
  toastEl.classList.add('on');
  if(bell&&!n.local){ bell.classList.remove('ring'); void bell.offsetWidth; bell.classList.add('ring'); }
  toastT=setTimeout(hideToast,5200);
}
function hideToast(){ if(toastEl) toastEl.classList.remove('on'); }

function openSheet(){
  if(!sheet){
    sheet=document.createElement('div'); sheet.id='mq-sheet'; sheet.setAttribute('role','dialog'); sheet.setAttribute('aria-label','اطلاعات');
    sheet.innerHTML='<div class="bk"></div><div class="pn"><div class="gr"></div><div class="hd"><b>اطلاعات</b><button type="button" aria-label="بند کریں">✕</button></div><div class="ls"></div></div>';
    document.body.appendChild(sheet);
    sheet.querySelector('.bk').onclick=closeSheet; sheet.querySelector('.hd button').onclick=closeSheet;
    document.addEventListener('keydown',function(e){ if(e.key==='Escape') closeSheet(); });
  }
  hideToast();
  var s=seen(), ls=sheet.querySelector('.ls');
  ls.innerHTML=items.length?items.map(function(n){ return cardHtml(n,n.ts>s?'new':''); }).join(''):'<div class="em">'+BELLOFF+'<br>ابھی کوئی اطلاع نہیں</div>';
  sheet.classList.add('on'); requestAnimationFrame(function(){ sheet.classList.add('show'); });
  markSeen();
}
function closeSheet(){ if(!sheet) return; sheet.classList.remove('show'); setTimeout(function(){ sheet.classList.remove('on'); },320); }

MQ.notify={
  /* items: [{id,title,body,type,ts,exp}] newest first */
  set:function(list){
    var now=Date.now(), prev={}; items.forEach(function(n){ prev[n.id]=1; });
    items=(list||[]).filter(function(n){ return !n.exp||n.exp>now; }).sort(function(a,b){return b.ts-a.ts;});
    ensureBell(); refresh();
    var s=seen(), fresh=items.filter(function(n){ return n.ts>s&&(first?(now-n.ts<3*864e5):!prev[n.id]); });
    if(fresh.length){
      var n=fresh[0];
      if(fresh.length>1) n={title:n.title,body:(n.body?n.body+'\n':'')+'… اور '+(fresh.length-1)+' نئی اطلاعات',type:n.type,ts:n.ts};
      setTimeout(function(){ toast(n); },first?900:0);
    }
    first=false;
    if(sheet&&sheet.classList.contains('show')) markSeen();
  },
  toast:function(text,type){ toast({title:text,type:type||'info',local:true}); },
  open:openSheet
};
waitHeader();
})();
