/* Site colour: applies the accent and background chosen in the admin page (light mode only). */
(function(){
'use strict';
function rgb(h){h=String(h||'').replace('#','');if(h.length===3)h=h.replace(/./g,function(c){return c+c;});if(!/^[0-9a-fA-F]{6}$/.test(h))return null;return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];}
function hex(c){return'#'+c.map(function(v){return Math.max(0,Math.min(255,Math.round(v))).toString(16).padStart(2,'0');}).join('');}
function mix(a,b,t){return[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
function lum(c){var f=function(v){v/=255;return v<=0.03928?v/12.92:Math.pow((v+0.055)/1.055,2.4);};return 0.2126*f(c[0])+0.7152*f(c[1])+0.0722*f(c[2]);}
function css(t){
  if(!t)return'';
  var a=rgb(t.a),b=rgb(t.b),o='';
  if(a){var n=0;while(lum(a)>0.28&&n++<12)a=mix(a,[0,0,0],0.12);
    o+='--primary:'+hex(a)+';--btn:'+hex(a)+';--primary-dark:'+hex(mix(a,[0,0,0],0.3))+';--primary-light:'+hex(mix(a,[255,255,255],0.88))+';--icon:'+hex(mix(a,[255,255,255],0.18))+';';}
  if(b&&lum(b)>0.7){var ink=[20,35,28];
    o+='--cream:'+hex(b)+';--solid:'+hex(b)+';--material:rgba('+b.map(Math.round).join(',')+',.82);--soft:'+hex(mix(b,ink,0.05))+';--border:'+hex(mix(b,ink,0.13))+';';}
  return o?'html:not([data-theme=dark]){'+o+'}'+(b&&lum(b)>0.7?'html:not([data-theme=dark]) body{background:'+hex(b)+'}':''):'';
}
function apply(t){
  var el=document.getElementById('mq-theme');
  var c=css(t);
  if(!c){if(el)el.remove();return;}
  if(!el){el=document.createElement('style');el.id='mq-theme';document.head.appendChild(el);}
  el.textContent=c;
}
window.MQ_applyTheme=function(t){try{if(t&&(t.a||t.b))localStorage.setItem('mq_site_theme',JSON.stringify({a:t.a||'',b:t.b||''}));else localStorage.removeItem('mq_site_theme');}catch(e){}apply(t);};
window.MQ_themeCss=css;
try{var s=localStorage.getItem('mq_site_theme');if(s)apply(JSON.parse(s));}catch(e){}
})();
