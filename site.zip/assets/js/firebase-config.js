/* Public Firebase web settings (these are not passwords; the database rules decide who can read what). */
window.MQ_FIREBASE = {
  apiKey: "AIzaSyAG0SFH1DH3ZnlvC0_-cPfIi3tAA9labpI",
  authDomain: "mutalea-quran.firebaseapp.com",
  projectId: "mutalea-quran",
  storageBucket: "mutalea-quran.firebasestorage.app",
  messagingSenderId: "462216966621",
  appId: "1:462216966621:web:dd64bdd2cd00287e18c634",
  adminEmail: "monandaxoxi@gmail.com"
};
