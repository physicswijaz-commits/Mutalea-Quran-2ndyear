/* مطالعہ قرآن — core: storage, data loader, helpers */
(function(){
'use strict';
window.MQ=window.MQ||{}; MQ.chapters=MQ.chapters||{}; MQ.registry=MQ.registry||{surahs:[]}; MQ.config=MQ.config||{};
MQ.S={ get(k,d){ try{ const v=localStorage.getItem('mq:'+k); return v===null?d:JSON.parse(v); }catch(e){ return d; } },
  set(k,v){ try{ localStorage.setItem('mq:'+k,JSON.stringify(v)); }catch(e){} }, del(k){ try{ localStorage.removeItem('mq:'+k); }catch(e){} },
  clearProgress(){ ['read','pos','last','best','days','wrong'].forEach(k=>MQ.S.del(k)); } };
MQ.dig=t=>String(t).replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g,d=>'٠١٢٣٤٥٦٧٨٩'.indexOf(d));
MQ.nUr=n=>MQ.dig(n);
addEventListener('beforeinstallprompt',e=>{ e.preventDefault(); window.__mqInstall=e; dispatchEvent(new Event('mq-installable')); });
try{ localStorage.removeItem('mq:notes'); }catch(_){}
MQ.today=()=>{ const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0'); };
MQ.dayNum=iso=>{ const [y,m,d]=iso.split('-').map(Number); return Math.round(Date.UTC(y,m-1,d)/864e5); };
MQ.streak=()=>{ const a=MQ.S.get('days',[]); if(!a.length) return 0; const set=new Set(a.map(MQ.dayNum)); let n=MQ.dayNum(MQ.today()); if(!set.has(n)) n--; let k=0; while(set.has(n)){ k++; n--; } return k; };
MQ.examLeft=()=>{ const e=MQ.S.get('exam',''); if(!e) return null; const d=MQ.dayNum(e)-MQ.dayNum(MQ.today()); return d<0?null:d; };
MQ.esc=s=>MQ.dig(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
MQ.qs=k=>new URLSearchParams(location.search).get(k);
MQ.shuffle=a=>{ a=a.slice(); for(let i=a.length-1;i>0;i--){ const j=Math.random()*(i+1)|0; [a[i],a[j]]=[a[j],a[i]]; } return a; };
MQ.i=n=>`<i class="bi bi-${n}"></i>`;
MQ.allRefs=()=>{ const o=[]; MQ.registry.surahs.forEach(s=>s.chapters.forEach(c=>o.push({surah:s,ref:c}))); return o; };
MQ.ref=id=>MQ.allRefs().find(x=>x.ref.id===id)||null;
MQ.rangeLabel=r=>r[0]===r[1]?`آیت ${MQ.nUr(r[0])}`:`آیات ${MQ.nUr(r[0])} تا ${MQ.nUr(r[1])}`;
const loading={};
MQ.load=id=>{ if(MQ.chapters[id]) return Promise.resolve(MQ.chapters[id]); if(loading[id]) return loading[id]; const r=MQ.ref(id); if(!r) return Promise.resolve(null);
  return loading[id]=new Promise(res=>{ const s=document.createElement('script'); s.src=r.ref.file; s.onload=()=>res(MQ.chapters[id]||null); s.onerror=()=>{ console.warn('[MQ] could not load',id); res(null); }; document.head.appendChild(s); }); };
MQ.exercises=MQ.exercises||{};
MQ.loadEx=id=>{ if(MQ.exercises[id]) return Promise.resolve(MQ.exercises[id]); return new Promise(res=>{ const s=document.createElement('script'); s.src=`assets/data/exercises/${id}.js`; s.onload=()=>res(MQ.exercises[id]||null); s.onerror=()=>res(null); document.head.appendChild(s); }); };
MQ.loadAll=()=>Promise.all(MQ.allRefs().map(x=>MQ.load(x.ref.id))).then(a=>a.filter(Boolean));
MQ.validate=()=>{ const seen={}, w=[]; Object.values(MQ.chapters).forEach(c=>{
  c.groups.forEach(g=>{ if(!g.arabic) w.push(g.id+': Arabic missing'); if(!g.translation) w.push(g.id+': translation missing'); g.ayahs.forEach(a=>{ if(a<c.range[0]||a>c.range[1]) w.push(c.id+': ayah '+a+' outside range'); }); });
  [...c.mcqs,...c.qa,...c.groups].forEach(x=>{ if(seen[x.id]) w.push('duplicate id '+x.id); seen[x.id]=1; }); c.mcqs.forEach(m=>{ if(m.options.length!==4||m.answer==null) w.push(m.id+': MCQ incomplete'); }); });
  if(w.length) console.warn('[MQ] data warnings:\n'+w.join('\n')); };
MQ.isRead=id=>!!MQ.S.get('read',{})[id];
MQ.toggleRead=id=>{ const m=MQ.S.get('read',{}); if(m[id]) delete m[id]; else m[id]=Date.now(); MQ.S.set('read',m); return !!m[id]; };
MQ.counts=c=>({v:new Set(c.groups.flatMap(g=>g.ayahs)).size,m:c.mcqs.length,q:c.qa.length});
/* revision = every verse group whose ayah number is in the lesson's "important" list (the numbers sent at the end of each upload) */
MQ.impGroups=c=>{ const s=new Set(c.important||[]); return c.groups.filter(g=>g.ayahs.some(a=>s.has(a))); };
MQ.revision=chs=>chs.map(c=>({c,r:MQ.ref(c.id),groups:MQ.impGroups(c)})).filter(x=>x.groups.length);

MQ.nAr=n=>MQ.dig(n);
MQ.star='<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 2l4.6 6.2 7.7-.9-.9 7.7L38 20l-6.2 4.6.9 7.7-7.7-.9L20 38l-4.6-6.2-7.7.9.9-7.7L2 20l6.2-4.6-.9-7.7 7.7.9z" stroke-linejoin="round"/></svg>';
MQ.medal=t=>`<span class="medal">${MQ.star}<i>${t}</i></span>`;
MQ.toast=(msg,ms)=>{ document.querySelectorAll('.toast').forEach(t=>t.remove()); const t=document.createElement('div'); t.className='toast'; t.setAttribute('role','status'); t.innerHTML=`${MQ.i('info-circle-fill')}<span>${MQ.esc(msg)}</span>`; document.body.appendChild(t);
  setTimeout(()=>t.classList.add('out'),(ms||2600)-300); setTimeout(()=>t.remove(),ms||2600); };
MQ.burst=(x,y,n)=>{ if(matchMedia('(prefers-reduced-motion: reduce)').matches) return; const L=document.createElement('div'), C=['var(--primary)','var(--gold)','#C94A4A','#1F8A5B','#8A9EAA']; L.className='confetti';
  for(let i=0;i<n;i++){ const p=document.createElement('span'), a=Math.random()*6.283, d=50+Math.random()*90;
    p.style.cssText=`left:${x}px;top:${y}px;--s:${(5+Math.random()*4).toFixed(1)}px;--c:${C[i%5]};--dx:${(Math.cos(a)*d)|0}px;--dy:${(Math.sin(a)*d-50)|0}px;--r:${((Math.random()-.5)*720)|0}deg;animation-delay:${(Math.random()*60)|0}ms`; L.appendChild(p); }
  document.body.appendChild(L); setTimeout(()=>L.remove(),1200); };
MQ.burstAt=(el,n)=>{ const r=el.getBoundingClientRect(); MQ.burst(r.left+r.width/2,r.top+r.height/2,n||24); };
})();
