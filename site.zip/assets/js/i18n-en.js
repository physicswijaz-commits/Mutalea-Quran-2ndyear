/* English wording for the shared sign-in / bell / install pieces. Loaded only on English sites: it translates the exact
   Urdu strings those files produce, as soon as they appear on the page. */
(function(){
'use strict';
var D={
'اطلاعات':'Notifications','ابھی':'just now','ابھی کوئی اطلاع نہیں':'No notifications yet','بند کریں':'Close',
'شرائط':'Terms','رازداری':'Privacy','براہِ کرم انتظار کریں…':'Please wait…',
'یوزر نیم / ای میل یا پاس ورڈ درست نہیں۔':'Wrong username / email or password.','پاس ورڈ درست نہیں۔':'Wrong password.',
'اس نام سے کوئی اکاؤنٹ نہیں ملا۔':'No account found with that name.','ای میل یا یوزر نیم درست نہیں۔':'The email or username is not valid.',
'یہ یوزر نیم / ای میل پہلے سے استعمال میں ہے۔':'That username / email is already in use.','پاس ورڈ کم از کم 6 حروف کا رکھیں۔':'Use a password of at least 6 characters.',
'بہت زیادہ کوششیں ہو گئیں۔ کچھ دیر بعد دوبارہ کوشش کریں۔':'Too many attempts. Please try again in a while.',
'انٹرنیٹ کنکشن نہیں ہے۔ چیک کر کے دوبارہ کوشش کریں۔':'No internet connection. Check it and try again.',
'یہ طریقہ ابھی فعال نہیں۔ ایڈمن سے رابطہ کریں۔':'This sign-in method is not enabled yet. Contact the admin.',
'یہ اکاؤنٹ بند کر دیا گیا ہے۔':'This account has been disabled.','اس ای میل سے دوسرے طریقے سے اکاؤنٹ بنا ہوا ہے۔':'An account already exists for this email with another sign-in method.',
'فی الحال نئے اکاؤنٹ بنانا بند ہے۔ ایڈمن سے رابطہ کریں۔':'New sign-ups are closed right now. Contact the admin.',
'یوزر نیم 3 تا 20 حروف: انگریزی حروف، اعداد یا _ استعمال کریں۔':'Username: 3–20 characters, using letters, numbers or _.',
'کچھ گڑبڑ ہو گئی۔ دوبارہ کوشش کریں۔':'Something went wrong. Please try again.',
'سائٹ کی دیکھ بھال جاری ہے':'The site is under maintenance','کچھ دیر بعد دوبارہ آئیں۔ شکریہ!':'Please come back in a little while. Thank you!',
'سائن آؤٹ':'Sign out','رابطہ نہیں ہو سکا':'Could not connect','اکاؤنٹ کی جانچ نہیں ہو سکی۔ انٹرنیٹ چیک کر کے دوبارہ کوشش کریں۔':'We could not check your account. Check your internet and try again.',
'دوبارہ کوشش کریں':'Try again','ای میل':'Email','یوزر نیم':'Username','یوزر نیم یا ای میل':'Username or email','گوگل کے ساتھ جاری رکھیں':'Continue with Google',
'یا':'or','سائن اِن':'Sign in','نیا اکاؤنٹ':'New account','پورا نام':'Full name','3 تا 20 حروف: a-z، 0-9 یا _':'3–20 characters: a-z, 0-9 or _',
'پاس ورڈ':'Password','پاس ورڈ دکھائیں':'Show password','پاس ورڈ چھپائیں':'Hide password','کم از کم 6 حروف':'At least 6 characters',
'اکاؤنٹ بنائیں':'Create account','یوزر نیم سے بنائیں':'Use a username instead','ای میل سے بنائیں':'Use an email instead','پاس ورڈ بھول گئے؟':'Forgot password?',
'نیا اکاؤنٹ بنائیں':'Create a new account','اسباق دیکھنے کے لیے سائن اِن کریں':'Sign in to read the notes',
'اپنا نام لکھیں۔':'Enter your name.','ای میل لکھیں۔':'Enter your email.','یوزر نیم لکھیں۔':'Enter a username.','یوزر نیم یا ای میل لکھیں۔':'Enter your username or email.',
'ای میل درست نہیں۔':'That email is not valid.','پاس ورڈ لکھیں۔':'Enter your password.',
'اپنا ای میل لکھیں؛ ہم پاس ورڈ بدلنے کا لنک بھیج دیں گے۔':'Enter your email and we will send a link to reset your password.',
'لنک بھیجیں':'Send link','اگر آپ نے صرف یوزر نیم سے اکاؤنٹ بنایا تھا تو ایڈمن سے واٹس ایپ پر رابطہ کریں۔':'If you signed up with only a username, message the admin on WhatsApp.',
'← سائن اِن پر واپس':'← Back to sign in','پاس ورڈ بحال کریں':'Reset password','لنک بھیج دیا گیا ہے۔ اپنا ان باکس (اور اسپیم) چیک کریں۔':'Link sent. Check your inbox (and spam).',
'منظوری کا انتظار':'Waiting for approval','آپ کی درخواست ایڈمن کو بھیج دی گئی ہے۔ منظوری کے بعد اسباق کھل جائیں گے۔':'Your request has been sent to the admin. The notes unlock once you are approved.',
'رسائی بند ہے':'Access is off','اس اکاؤنٹ کے لیے رسائی فی الحال بند ہے۔ مزید معلومات کے لیے ایڈمن سے رابطہ کریں۔':'Access for this account is off right now. Contact the admin for details.',
'رسائی کی مدت ختم':'Access has expired','آپ کی رسائی کی مدت ختم ہو چکی ہے۔ تجدید کے لیے ایڈمن سے رابطہ کریں۔':'Your access period has ended. Contact the admin to renew it.',
'واٹس ایپ پر رابطہ کریں':'Contact on WhatsApp','دوبارہ جانچیں':'Check again',
'ضروری فائلیں لوڈ نہیں ہو سکیں۔ پہلی بار سائن اِن کے لیے انٹرنیٹ درکار ہے۔':'Required files could not load. The first sign-in needs internet.',
'اکاؤنٹ':'Account','ایڈمن پیج':'Admin page',
'یہ سبق لوڈ نہیں ہو سکا۔ انٹرنیٹ چیک کریں؛ پہلی بار کھولنے کے لیے انٹرنیٹ درکار ہے۔':'This chapter could not load. Check your internet; the first open needs internet.',
'سفاری میں نیچے «شیئر» کا بٹن دبائیں، پھر «ہوم اسکرین میں شامل کریں» چنیں۔':'In Safari, tap the Share button, then choose “Add to Home Screen”.',
'براؤزر کے مینو (⋮) میں «ایپ انسٹال کریں» یا «ہوم اسکرین میں شامل کریں» چنیں۔':'In your browser menu (⋮) choose “Install app” or “Add to Home screen”.',
'ایپ انسٹال کریں':'Install app','ٹھیک ہے':'OK'
};
var R=[[/^(\d+) منٹ پہلے$/,'$1 min ago'],[/^(\d+) گھنٹے پہلے$/,'$1 h ago'],[/^(\d+) دن پہلے$/,'$1 d ago'],
 [/^… اور (\d+) نئی اطلاعات$/,'… and $1 more'],[/^اطلاعات — (\d+) نئی$/,'Notifications — $1 new']];
function tx(s){
  var t=s.trim(); if(!t||!/[؀-ۿ]/.test(t)) return s;
  if(Object.prototype.hasOwnProperty.call(D,t)) return s.replace(t,D[t]);
  for(var i=0;i<R.length;i++) if(R[i][0].test(t)) return s.replace(t,t.replace(R[i][0],R[i][1]));
  return s;
}
function walk(n){
  if(n.nodeType===3){ var v=tx(n.nodeValue); if(v!==n.nodeValue) n.nodeValue=v; return; }
  if(n.nodeType!==1||n.tagName==='SCRIPT'||n.tagName==='STYLE') return;
  ['placeholder','aria-label','title'].forEach(function(a){ if(n.hasAttribute(a)){ var o=n.getAttribute(a),v=tx(o); if(v!==o) n.setAttribute(a,v); } });
  for(var c=n.firstChild;c;c=c.nextSibling) walk(c);
}
function start(){
  walk(document.body);
  new MutationObserver(function(ms){
    ms.forEach(function(m){
      if(m.type==='childList') m.addedNodes.forEach(walk);
      else if(m.type==='characterData') walk(m.target);
      else if(m.target.nodeType===1) walk(m.target);
    });
  }).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['aria-label','placeholder','title']});
}
if(document.body) start(); else document.addEventListener('DOMContentLoaded',start);
})();
