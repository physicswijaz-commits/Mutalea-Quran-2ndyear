/* مطالعہ قرآن — two pages: home (lesson cards with options) and section */
(function(){
'use strict';
const S=MQ.S, $=s=>document.querySelector(s), app=()=>document.getElementById('app'), P=MQ.pages={};
const SECTIONS={ content:{t:'آیات و ترجمہ',ic:'book-half'}, qa:{t:'سوال جواب',ic:'chat-left-text'}, quiz:{t:'ٹیسٹ',ic:'ui-radios'}, ex:{t:'مشق',ic:'pencil-square'} };

const BM={ all(){ return S.get('bm',[]); }, has(k){ return BM.all().includes(k); }, toggle(k){ let a=BM.all(); const on=!a.includes(k); a=on?[k,...a]:a.filter(x=>x!==k); S.set('bm',a); return on; } };
const isImp=(g,cid)=>{ const c=cid&&MQ.chapters[cid]; return !!(c&&(c.important||[]).some(n=>g.ayahs.includes(n))); };
const verseHtml=(g,i,id,cid)=>`<article class="verse rise${isImp(g,cid)?' imp':''}" id="${id||g.id}" style="--i:${Math.min(i,3)}"><div class="v-head">${MQ.medal(MQ.nAr(g.ayahs[0]))}<div class="lbl"><b>${MQ.esc(g.label)}</b>${isImp(g,cid)&&!(id||'').startsWith('rev-')?`<span class="imp-tag">${MQ.i('star-fill')} اہم آیت</span>`:''}</div>${cid?`<button class="v-act v-bm${BM.has(cid+'|'+g.id)?' on':''}" data-bm="${cid}|${g.id}" aria-label="محفوظ کریں" aria-pressed="${BM.has(cid+'|'+g.id)}">${MQ.i(BM.has(cid+'|'+g.id)?'bookmark-star-fill':'bookmark-star')}</button>`:''}<button class="v-act" data-share="${i}" aria-label="بھیجیں یا کاپی کریں">${MQ.i('share')}</button></div>
        ${g.topic?`<div class="v-topic">${MQ.i('pin-angle-fill')}<span>${MQ.esc(g.topic)}</span></div>`:''}
        ${g.arabic?`<div class="v-ar"><p class="ar" lang="ar" dir="rtl">${MQ.arHtml(g.arabic)}</p></div>`:''}<div class="v-tr"><p class="ur" lang="ur"><span class="lbl-t">ترجمہ:</span> ${MQ.esc(g.translation)}</p></div>
        ${g.points.length?`<div class="pts"><h4>${MQ.i('lightbulb')} امتحانی نکات</h4><ul>${g.points.map(p=>typeof p==='string'?`<li class="ur">${MQ.rich(p)}</li>`:`<li class="ur">${MQ.rich(p.t)}<ul class="subpts">${p.sub.map(x=>`<li>${MQ.rich(x)}</li>`).join('')}</ul></li>`).join('')}</ul></div>`:''}</article>`;
/* scroll to an element and keep re-aligning while content-visibility placeholders settle (unless the reader scrolls) */
const alignTo=(id,open)=>{ let touched=false; ['touchstart','wheel','keydown','mousedown'].forEach(e=>addEventListener(e,()=>{ touched=true; },{passive:true,once:true}));
  const go=first=>{ if(touched) return; const t=document.getElementById(id); if(!t) return; if(first){ if(open&&t.classList.contains('qa')) t.classList.add('open'); t.classList.add('flash'); setTimeout(()=>t.classList.remove('flash'),2600); } scrollTo({top:Math.max(0,t.getBoundingClientRect().top+scrollY-POS.topY()-4),behavior:'instant'}); };
  [0,150,400,800,1300,2000].forEach((d,i)=>setTimeout(()=>go(i===0),d)); };
const bmClick=(e,after)=>{ const b=e.target.closest('[data-bm]'); if(!b) return false; const on=BM.toggle(b.dataset.bm); b.classList.toggle('on',on); b.setAttribute('aria-pressed',on); b.innerHTML=MQ.i(on?'bookmark-star-fill':'bookmark-star'); MQ.toast(on?'آیت محفوظ ہو گئی':'محفوظ آیات سے ہٹا دی'); if(after) after(b,on); return true; };
const contactHref=msg=>{ const L=(MQ.config&&MQ.config.links)||{}, wa=String(L.whatsapp||'').replace(/\D/g,''), ig=String(L.instagram||'').replace(/^@/,'').replace(/[^\w.]/g,''); return wa?'https://wa.me/'+wa+'?text='+encodeURIComponent(msg):ig?'https://instagram.com/'+ig:''; };
const wordsOf=c=>{ const t=[c.intro&&c.intro.points,c.takeaways&&c.takeaways.points].flat().filter(Boolean).map(p=>typeof p==='string'?p:p.t+' '+(p.sub||[]).join(' ')).join(' ')+' '+c.groups.map(g=>g.translation+' '+(g.points||[]).map(p=>typeof p==='string'?p:p.t+' '+(p.sub||[]).join(' ')).join(' ')).join(' '); return t.split(/\s+/).filter(Boolean).length; };
const shareText=(g,sn)=>[g.label,g.arabic,g.translation].filter(Boolean).join('\n\n')+`\n\n— ${sn}`;
const shareIt=(txt)=>{ if(navigator.share) navigator.share({text:txt}).catch(()=>{}); else if(navigator.clipboard) navigator.clipboard.writeText(txt).then(()=>MQ.toast('آیت کاپی ہو گئی')).catch(()=>MQ.toast('کاپی نہیں ہو سکی')); };

/* exercise (مشق): tick-the-answer MCQs (right/wrong feedback from the ✔ in the notes), short / long answers and activities (tap to reveal) */
const exBlocks=bs=>bs.map(b=>{ const lb=b.label?`<b class="lbl-t">${MQ.esc(b.label)}:</b> `:'', ul=x=>`<ul class="ex-ul${x.every(y=>/^[۰-۹0-9]+\.\s/.test(y))?' numd':''}">${x.map(y=>`<li class="ur">${MQ.rich(y)}</li>`).join('')}</ul>`;
  if(b.t==='p') return `<div class="ex-p"><p>${lb}${MQ.rich(b.text)}</p>${b.items?ul(b.items):''}</div>`;
  if(b.t==='list') return `<div class="ex-l">${b.label?`<b class="lbl-t">${MQ.esc(b.label)}:</b>`:''}${ul(b.items)}</div>`;
  return `<div class="ex-tw">${b.label?`<b class="lbl-t">${MQ.esc(b.label)}:</b>`:''}<table class="ex-t"><thead><tr>${b.head.map(x=>`<th>${MQ.rich(x)}</th>`).join('')}</tr></thead><tbody>${b.rows.map(r=>`<tr>${r.map(x=>`<td>${MQ.rich(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`; }).join('');
const exPage=(d,box)=>{
  d.groups.forEach(g=>{ box.insertAdjacentHTML('beforeend',`<div class="sec-head ex-head"><b>${MQ.esc(g.heading)}</b></div>`);
    g.items.forEach((it,i)=>{
      if(g.kind==='mcq'){ const el=document.createElement('div'); el.className='qcard rise'; el.style.setProperty('--i',Math.min(i,8));
        el.innerHTML=`<div class="qn">سوال ${MQ.nUr(it.n)} / ${MQ.nUr(g.items.length)}</div><div class="qt">${MQ.rich(it.q)}</div>`+it.options.map((o,oi)=>`<button class="o" data-i="${oi}"><span class="k w">${MQ.esc(o.k)}</span><span>${MQ.rich(o.t)}</span></button>`).join('');
        el.onclick=e=>{ const b=e.target.closest('.o'); if(!b||b.disabled) return; const bs=[...el.querySelectorAll('.o')], oi=+b.dataset.i;
          if(it.answer==null){ const on=b.classList.contains('pick'); bs.forEach(x=>x.classList.remove('pick')); if(!on) b.classList.add('pick'); return; }
          bs.forEach((x,xi)=>{ x.disabled=true; if(xi===it.answer) x.classList.add('ok'); }); if(oi!==it.answer) b.classList.add('bad'); try{ navigator.vibrate&&navigator.vibrate(oi===it.answer?10:[12,25,12]); }catch(_){} };
        box.appendChild(el); return; }
      const el=document.createElement('div'); el.className='qa rise'; el.style.setProperty('--i',Math.min(i,8));
      const tag=it.k?`<span class="n w">${MQ.nUr(it.n)} ${MQ.esc(it.k)}</span>`:`<span class="n">${MQ.nUr(it.n)}</span>`;
      el.innerHTML=`<div class="q">${tag}<span>${MQ.rich(it.q)}</span></div><div class="hint">${MQ.i('hand-index-thumb')} جواب دیکھنے کے لیے دبائیں</div><div class="a">${exBlocks(it.a)}</div>`;
      el.onclick=()=>el.classList.toggle('open'); box.appendChild(el); }); }); };

/* ---------- reading position: remembered per lesson + section, restored on open ---------- */
const POS={
  all(){ return S.get('pos',{}); }, get(k){ return POS.all()[k]||null; },
  put(k,v){ const o=POS.all(); o[k]=v; const ks=Object.keys(o); if(ks.length>80) ks.sort((x,y)=>(o[x].t||0)-(o[y].t||0)).slice(0,ks.length-80).forEach(x=>delete o[x]); S.set('pos',o); },
  del(k){ const o=POS.all(); if(k in o){ delete o[k]; S.set('pos',o); } },
  topY(){ const h=document.querySelector('header.bar'); return (h?h.offsetHeight:56)+8; },
  place(box,pos){ const kids=[...box.children]; if(!kids.length) return; const k=kids[Math.min(pos.i,kids.length-1)];
    scrollTo({top:Math.max(0,k.getBoundingClientRect().top+scrollY-POS.topY()+(pos.o||0)),behavior:'instant'}); },
  /* box: container whose children are the anchors; last: {id,s} for the home "continue" card */
  track(key,box,last,restore,skip){
    let ready=false, touched=false, bar=null; const pos=restore&&!MQ.qs('top')?POS.get(key):null, mark=()=>{ touched=true; };
    ['touchstart','wheel','keydown','mousedown'].forEach(e=>addEventListener(e,mark,{passive:true,once:true}));
    const save=()=>{ if(!ready) return; const kids=[...box.children]; if(!kids.length) return; const top=POS.topY(); let i=0;
      for(;i<kids.length;i++) if(kids[i].getBoundingClientRect().bottom>top) break; if(i>=kids.length) i=kids.length-1;
      const max=document.documentElement.scrollHeight-innerHeight, p=max>0?Math.min(100,Math.round(scrollY/max*100)):0;
      S.set('last',Object.assign({t:Date.now()},last)); if(skip&&skip()) return;
      if(scrollY<80||p>=97) POS.del(key); else POS.put(key,{i,o:Math.max(0,Math.round(top-kids[i].getBoundingClientRect().top)),p,t:Date.now()}); };
    S.set('last',Object.assign({t:Date.now()},last));
    if(pos&&(pos.p>=3||pos.i>2)){ POS.place(box,pos);
      const again=()=>{ if(!touched) POS.place(box,pos); }; [120,350,700,1100,1700].forEach(d=>setTimeout(again,d)); addEventListener('load',again,{once:true});
      bar=document.createElement('div'); bar.className='resume-bar'; bar.setAttribute('role','status');
      bar.innerHTML=`<span>${MQ.i('bookmark-check-fill')} جہاں سے چھوڑا تھا وہیں سے جاری (${MQ.nUr(pos.p)}%)</span><button type="button">شروع سے</button>`;
      document.body.appendChild(bar); const gone=()=>{ if(bar){ bar.classList.add('out'); const b=bar; bar=null; setTimeout(()=>b.remove(),300); } };
      bar.querySelector('button').onclick=()=>{ touched=true; POS.del(key); scrollTo({top:0,behavior:'smooth'}); gone(); }; setTimeout(gone,7000); }
    setTimeout(()=>{ ready=true; },700);
    let t; addEventListener('scroll',()=>{ clearTimeout(t); t=setTimeout(save,250); },{passive:true});
    addEventListener('pagehide',save); document.addEventListener('visibilitychange',()=>{ if(document.hidden) save(); }); }
};
MQ.pos=POS;

/* ---------- HOME ---------- */
P.index=async function(){
  MQ.shell({title:'تمام اسباق',sub:'سیکنڈ ایئر · KPK بورڈ'}); const chs=await MQ.loadAll(), a=app(), refs=MQ.allRefs(), N=refs.length;
  const seen=new Set(), tot=chs.reduce((t,c)=>{ const k=MQ.counts(c); c.groups.forEach(g=>g.ayahs.forEach(x=>seen.add(c.surah+':'+x))); t.q+=k.m+k.q; return t; },{v:0,q:0}); tot.v=seen.size; const rv=MQ.revision(chs), rvSet=new Set(); rv.forEach(x=>x.groups.forEach(g=>g.ayahs.forEach(n=>{ if((x.c.important||[]).includes(n)) rvSet.add(x.c.surah+':'+n); }))); const done=refs.filter(r=>MQ.isRead(r.ref.id)).length;
  let h=`<section class="hero rise"><h1>مطالعہ قرآن</h1><div class="orn">${MQ.star}</div></section>
    <div class="stats rise" style="--i:1"><div class="stat"><b>${MQ.nUr(MQ.registry.surahs.length)}</b><span>سورتیں</span></div><div class="stat"><b>${MQ.nUr(N)}</b><span>اسباق</span></div><div class="stat"><b>${MQ.nUr(tot.v)}</b><span>آیات</span></div><div class="stat"><b>${MQ.nUr(tot.q)}</b><span>سوالات</span></div></div>
    ${N?`<div class="prog rise" style="--i:2"><div class="track"><div class="fill" style="width:${Math.round(done/N*100)}%"></div></div><span>${MQ.nUr(done)} / ${MQ.nUr(N)} مکمل</span></div>`:`<div class="empty">${MQ.i('journal')}ابھی کوئی سبق موجود نہیں۔</div>`}`;
  const last=S.get('last',null);
  if(last&&last.id==='rev'){ const pp=POS.get('rev'); h+=`<a class="resume rise" style="--i:3" href="revision.html"><span class="r-ic">${MQ.i('play-fill')}</span><span class="r-tx"><b>پڑھائی جاری رکھیں</b><small>ریویژن — اہم آیات${pp?' · '+MQ.nUr(pp.p)+'% پڑھا':''}</small></span>${MQ.i('chevron-left')}</a>`; }
  else if(last&&MQ.ref(last.id)&&SECTIONS[last.s]){ const lr=MQ.ref(last.id), pp=POS.get(last.id+':'+last.s); h+=`<a class="resume rise" style="--i:3" href="section.html?id=${last.id}&s=${last.s}"><span class="r-ic">${MQ.i('play-fill')}</span><span class="r-tx"><b>پڑھائی جاری رکھیں</b><small>${MQ.esc(lr.surah.ur)} · سبق ${MQ.nUr(lr.ref.n)} · ${SECTIONS[last.s].t}${pp?' · '+MQ.nUr(pp.p)+'% پڑھا':''}</small></span>${MQ.i('chevron-left')}</a>`; }
  { const st=MQ.streak(), ex=MQ.examLeft(); if(st>0||ex!==null) h+=`<div class="chips rise" style="--i:3">${st>0?`<span class="chip">${MQ.i('fire')} ${MQ.nUr(st)} دن لگاتار پڑھائی</span>`:''}${ex!==null?`<span class="chip ex">${MQ.i('calendar-event')} ${ex===0?'آج امتحان ہے':'امتحان میں '+MQ.nUr(ex)+' دن باقی'}</span>`:''}</div>`; }
  h+=`<div class="quick rise" style="--i:4"><a href="search.html">${MQ.i('search')}<span>تلاش</span></a><a href="bookmarks.html">${MQ.i('bookmark-star')}<span>محفوظ آیات${BM.all().length?' ('+MQ.nUr(BM.all().length)+')':''}</span></a><a href="test.html">${MQ.i('clipboard-check')}<span>امتحانی ٹیسٹ</span></a></div>`;
  if(rv.length){ const flat=rv.flatMap(x=>x.groups.map(g=>({g,sn:x.r.surah.ur}))); if(flat.length){ const n=Math.min(3,flat.length), st=(MQ.dayNum(MQ.today())*n)%flat.length, pick=Array.from({length:n},(_,i)=>flat[(st+i)%flat.length]);
    h+=`<div class="today rise" style="--i:4"><h3>${MQ.i('sunrise')} آج کی دہرائی</h3><p>آج کی تین اہم آیات — روز نئی آیات آتی ہیں</p>${pick.map(x=>`<a href="revision.html#rev-${x.g.id}"><b>${MQ.esc(x.sn)}</b><span>${MQ.esc(x.g.label)}</span>${MQ.i('chevron-left')}</a>`).join('')}</div>`; } }
  if(rv.length) h+=`<a class="revcard rise" style="--i:4" href="revision.html"><span class="r-ic">${MQ.i('arrow-repeat')}</span><span class="r-tx"><b>ریویژن — اہم آیات</b><small>${MQ.nUr(rvSet.size)} اہم آیات · ${MQ.nUr(rv.length)} اسباق سے</small></span>${MQ.i('chevron-left')}</a>`;
  let k=5;
  MQ.registry.surahs.forEach(s=>{ h+=`<div class="sec-head rise" style="--i:${k++}"><b>${MQ.esc(s.ur)}</b><span>${MQ.esc(s.en||'')}</span></div>`;
    s.chapters.forEach(c=>{ const d=MQ.chapters[c.id], q=d?MQ.counts(d):{v:0,m:0,q:0}, ops=[['content',q.v],['qa',q.q],['quiz',q.m],['ex',c.ex||0]].filter(o=>o[1]>0);
      h+=`<article class="lcard rise${MQ.isRead(c.id)?' done':''}" style="--i:${k++}" data-id="${c.id}" data-name="سبق ${MQ.nUr(c.n)}"><button class="lhead" aria-expanded="false"><span class="l-ic">${MQ.i('journal-text')}</span><h3>سبق ${MQ.nUr(c.n)} — ${MQ.rangeLabel(c.range)}${c.title?' · '+MQ.esc(c.title):''}</h3><p>${MQ.nUr(q.v)} آیات · ${MQ.nUr(q.m)} MCQ · ${MQ.nUr(q.q)} سوالات${(()=>{ const pp=!MQ.isRead(c.id)&&POS.get(c.id+':content'), bs=S.get('best',{})[c.id]; return (pp?` · <em class="pct">${MQ.nUr(pp.p)}% پڑھا</em>`:'')+(bs!=null?` · <em class="pct">ٹیسٹ ${MQ.nUr(bs)}%</em>`:''); })()}</p></button>
        <div class="lbody"><div><hr><div class="pick">چنیں:</div>${ops.map(o=>`<label class="popt"><input type="radio" name="o-${c.id}" value="${o[0]}"><span>${SECTIONS[o[0]].t}</span>${MQ.i(SECTIONS[o[0]].ic)}</label>`).join('')}<button class="go">سبق ${MQ.nUr(c.n)} کھولیں</button></div></div></article>`; }); });
  h+=`<footer class="foot rise"><div class="orn">${MQ.star}</div><p>مزید سورتیں اور آیات آتی رہیں گی</p><small>${MQ.nUr(N)} اسباق · ${MQ.nUr(tot.v)} آیات · ${MQ.nUr(tot.q)} سوالات</small></footer>`;
  a.innerHTML=h;
  /* tap a lesson card → it opens its options (one at a time); pick one, press the grey button */
  a.addEventListener('click',e=>{
    const head=e.target.closest('.lhead'); if(head){ const card=head.closest('.lcard'), open=!card.classList.contains('sel');
      a.querySelectorAll('.lcard.sel').forEach(x=>{ x.classList.remove('sel'); x.querySelector('.lhead').setAttribute('aria-expanded','false'); });
      if(open){ card.classList.add('sel'); head.setAttribute('aria-expanded','true'); setTimeout(()=>card.scrollIntoView({behavior:'smooth',block:'nearest'}),260); } return; }
    const go=e.target.closest('.go'); if(go){ const card=go.closest('.lcard'), pick=card.querySelector('input:checked');
      if(!pick){ MQ.toast(`${card.dataset.name} کے لیے ایک چیز چنیں`); return; } location.href=`section.html?id=${card.dataset.id}&s=${pick.value}`; } });
};

/* ---------- SECTION ---------- */
P.section=async function(){
  const id=MQ.qs('id'), s=MQ.qs('s'), r=MQ.ref(id), a=app();
  if(!r||!SECTIONS[s]){ MQ.shell({title:'مطالعہ قرآن',back:'index.html'}); a.innerHTML='<div class="empty">یہ صفحہ موجود نہیں۔</div>'; return; }
  MQ.shell({title:SECTIONS[s].t,sub:`${r.surah.ur} · سبق ${MQ.nUr(r.ref.n)}`,back:'index.html',progress:s==='content'}); const c=await MQ.load(id);
    if(!c){ a.innerHTML='<div class="empty">سبق کی فائل کھل نہیں سکی۔</div>'; return; }
  const hero=`<section class="ch-hero rise"><div class="sn">${MQ.esc(r.surah.ar||r.surah.ur)}</div>${s==='content'?`<div class="rt">${MQ.i('clock')} پڑھنے کا وقت تقریباً ${MQ.nUr(Math.max(1,Math.round(wordsOf(c)/150)))} منٹ · ${MQ.nUr(MQ.counts(c).v)} آیات</div>`:''}</section>`;
  a.innerHTML=hero; const body=document.createElement('div'); a.appendChild(body);
  if(s==='content'&&c.groups.length>3){ const nv=document.createElement('nav'); nv.className='jump'; nv.setAttribute('aria-label','آیات پر جائیں');
    nv.innerHTML='<span>جائیں:</span>'+c.groups.map(g=>`<button type="button" data-g="${g.id}">${MQ.esc(String(g.label).split(' (')[0].replace(/^آیت\s*/,''))}</button>`).join('');
    nv.onclick=e=>{ const b=e.target.closest('[data-g]'); if(!b) return; const t=document.getElementById(b.dataset.g); if(t){ t.scrollIntoView({block:'start',behavior:'smooth'}); t.classList.add('flash'); setTimeout(()=>t.classList.remove('flash'),2200); } };
    a.insertBefore(nv,body); }
  const refs=MQ.allRefs(), ix=refs.findIndex(x=>x.ref.id===id), prev=refs[ix-1], next=refs[ix+1];
  const pn=()=>{ if(!prev&&!next) return; const d=document.createElement('nav'); d.className='pn'; d.setAttribute('aria-label','دوسرے اسباق');
    d.innerHTML=(prev?`<a href="section.html?id=${prev.ref.id}&s=${s}">${MQ.i('chevron-right')} سبق ${MQ.nUr(prev.ref.n)}</a>`:'<span></span>')+(next?`<a href="section.html?id=${next.ref.id}&s=${s}">سبق ${MQ.nUr(next.ref.n)} ${MQ.i('chevron-left')}</a>`:'<span></span>'); a.appendChild(d); };
  if(s==='content'){
    body.innerHTML=(c.intro?`<section class="intro rise"><h4>${MQ.i('journal-text')} ${MQ.esc(c.intro.title)}</h4><ul>${c.intro.points.map(p=>typeof p==='string'?`<li class="ur">${MQ.rich(p)}</li>`:`<li class="ur">${MQ.rich(p.t)}<ul class="subpts">${p.sub.map(x=>`<li>${MQ.rich(x)}</li>`).join('')}</ul></li>`).join('')}</ul></section>`:'')+c.groups.map((g,i)=>verseHtml(g,i,null,c.id)).join('')+(c.takeaways?`<section class="intro takeaways rise"><h4>${MQ.i('lightbulb')} ${MQ.esc(c.takeaways.title)}</h4><ul>${c.takeaways.points.map(p=>typeof p==='string'?`<li class="ur">${MQ.rich(p)}</li>`:`<li class="ur">${MQ.rich(p.t)}<ul class="subpts">${p.sub.map(x=>`<li>${MQ.rich(x)}</li>`).join('')}</ul></li>`).join('')}</ul></section>`:'')+`<button class="read-btn" id="rb"></button>`;
    body.addEventListener('click',e=>{ if(bmClick(e)) return; const sh=e.target.closest('[data-share]'); if(sh){ shareIt(shareText(c.groups[+sh.dataset.share],r.surah.ur)); return; }
      const tr=e.target.closest('.v-tr'); if(tr&&document.body.classList.contains('test')) tr.classList.toggle('shown'); });
    const rb=$('#rb'), set=()=>{ const on=MQ.isRead(id); rb.className='read-btn'+(on?' done':''); rb.innerHTML=on?`${MQ.i('check-circle-fill')} سبق مکمل — واپس کریں`:`${MQ.i('check-lg')} سبق مکمل پڑھ لیا`; }; set();
    rb.onclick=()=>{ const on=MQ.toggleRead(id); set(); if(on){ POS.del(id+':content'); MQ.burstAt(rb,28); } };
  } else if(s==='qa'){
    if(!c.qa.length) body.innerHTML='<div class="empty">اس سبق کے سوالات ابھی موجود نہیں۔</div>'; else c.qa.forEach((q,i)=>{ const el=MQ.qaItem(q,i+1); el.id='q'+(i+1); body.appendChild(el); });
  } else if(s==='quiz'){
    if(!c.mcqs.length) body.innerHTML='<div class="empty">اس سبق کے MCQs ابھی موجود نہیں۔</div>'; else MQ.initQuiz(body,MQ.shuffle(c.mcqs),{key:id});
  } else if(s==='ex'){
    const d=await MQ.loadEx(id); if(!d) body.innerHTML='<div class="empty">اس سبق کی مشق ابھی موجود نہیں۔</div>'; else exPage(d,body);
  }
  pn();
  { const secName=SECTIONS[s].t, href=contactHref(`السلام علیکم! مطالعہ قرآن میں ${r.surah.ur} · سبق ${r.ref.n} (${secName}) میں مجھے ایک غلطی نظر آئی:\n`);
    if(href){ const d=document.createElement('div'); d.className='report'; d.innerHTML=`<a href="${href}" target="_blank" rel="noopener noreferrer">${MQ.i('flag')} اس صفحے میں کوئی غلطی نظر آئی؟ بتائیں</a>`; a.appendChild(d); } }
  MQ.dock(id,s);
  if(s==='quiz') S.set('last',{id,s,t:Date.now()}); else POS.track(id+':'+s,body,{id,s},!location.hash,s==='content'?()=>MQ.isRead(id):null);
  if(location.hash) alignTo(decodeURIComponent(location.hash.slice(1)),true);
};
/* ---------- REVISION: only the important ayahs of every lesson, in one page ---------- */
P.revision=async function(){
  MQ.shell({title:'ریویژن',sub:'اہم آیات · KPK بورڈ',back:'index.html',progress:true}); const chs=await MQ.loadAll(), a=app(), rv=MQ.revision(chs), items=[];
  if(!rv.length){ a.innerHTML=`<div class="empty">${MQ.i('journal')}ابھی کوئی اہم آیت موجود نہیں۔</div>`; return; }
  const nA=new Set(); rv.forEach(x=>x.groups.forEach(g=>g.ayahs.forEach(n=>{ if((x.c.important||[]).includes(n)) nA.add(x.c.surah+':'+n); })));
  let h=`<section class="hero rise"><h1>ریویژن</h1><div class="orn">${MQ.star}</div><p>${MQ.nUr(nA.size)} اہم آیات · ${MQ.nUr(rv.length)} اسباق</p><button type="button" class="print-btn" id="print-rev">${MQ.i('printer')} پرنٹ / PDF بنائیں</button></section>`;
  rv.forEach(x=>{ const imp=(x.c.important||[]).filter(n=>x.groups.some(g=>g.ayahs.includes(n)));
    h+=`<div class="rev-head"><div><b>${MQ.esc(x.r.surah.ur)} · سبق ${MQ.nUr(x.r.ref.n)}</b><span>آیات: ${MQ.esc(imp.join('، '))}</span></div><a href="section.html?id=${x.c.id}&s=content">پورا سبق ${MQ.i('chevron-left')}</a></div>`;
    x.groups.forEach(g=>{ items.push({g,sn:x.r.surah.ur}); h+=verseHtml(g,items.length-1,'rev-'+g.id,x.c.id); }); });
  a.innerHTML=h; POS.track('rev',a,{id:'rev',s:'rev'},!location.hash);
  $('#print-rev').onclick=()=>{ document.documentElement.classList.add('printing'); setTimeout(()=>{ try{ print(); }catch(_){} setTimeout(()=>document.documentElement.classList.remove('printing'),500); },80); };
  if(location.hash) alignTo(decodeURIComponent(location.hash.slice(1)));
  a.addEventListener('click',e=>{ if(bmClick(e)) return; const sh=e.target.closest('[data-share]'); if(sh){ const it=items[+sh.dataset.share]; shareIt(shareText(it.g,it.sn)); return; }
    const tr=e.target.closest('.v-tr'); if(tr&&document.body.classList.contains('test')) tr.classList.toggle('shown'); });
};

/* ---------- SEARCH: verses (Arabic / translation / points) and Q&A of every lesson ---------- */
const norm=t=>MQ.dig(String(t||'')).replace(/[ً-ْٰـۖ-ۭ]/g,'').replace(/[أإآٱ]/g,'ا').replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/ہ|ۃ|ة/g,'ہ').replace(/[ۂ]/g,'ہ').replace(/\s+/g,' ').toLowerCase().trim();
const flatPts=ps=>(ps||[]).flatMap(p=>typeof p==='string'?[p]:[p.t,...(p.sub||[])]);
P.search=async function(){
  MQ.shell({title:'تلاش',sub:'آیات · ترجمہ · سوال جواب',back:'index.html'}); const a=app();
  a.innerHTML=`<div class="srch rise"><label class="srch-box">${MQ.i('search')}<input id="q" type="search" inputmode="search" enterkeyhint="search" autocomplete="off" placeholder="کوئی لفظ لکھیں (اردو یا عربی)…" aria-label="تلاش"></label><div class="srch-hint" id="hint">اسباق لوڈ ہو رہے ہیں…</div></div><div id="res"></div>`;
  const chs=await MQ.loadAll(), idx=[];
  chs.forEach(c=>{ const r=MQ.ref(c.id); if(!r) return; const sn=`${r.surah.ur} · سبق ${MQ.nUr(r.ref.n)}`;
    c.groups.forEach(g=>{ const txt=[g.arabic,g.translation,g.topic,...flatPts(g.points)].filter(Boolean).join(' ‖ '); idx.push({k:'v',href:`section.html?id=${c.id}&s=content#${g.id}`,sn,t:g.label,txt,n:norm(txt)}); });
    c.qa.forEach((q,i)=>{ const txt=q.q+' ‖ '+q.a; idx.push({k:'q',href:`section.html?id=${c.id}&s=qa#q${i+1}`,sn,t:q.q,txt,n:norm(txt)}); }); });
  const inp=$('#q'), res=$('#res'), hint=$('#hint'); hint.textContent=`${MQ.nUr(idx.length)} حصوں میں تلاش ہو گی`;
  const mark=(txt,words)=>{ const diac='[\\u064B-\\u0652\\u0670\\u0640]*', rxs=words.map(w=>new RegExp('('+[...w].map(ch=>ch.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join(diac)+')','i'));
    let at=-1; rxs.forEach(rx=>{ const m=rx.exec(txt); if(m&&(at<0||m.index<at)) at=m.index; });
    const from=Math.max(0,(at<0?0:at)-50), part=txt.slice(from,from+170); let html=MQ.esc(part); rxs.forEach(rx=>{ html=html.replace(new RegExp(rx.source,'gi'),'<mark>$1</mark>'); });
    return (from>0?'… ':'')+html+(from+170<txt.length?' …':''); };
  let tm; const run=()=>{ const words=norm(inp.value).split(' ').filter(w=>w.length>0); if(!words.length){ res.innerHTML=''; hint.textContent=`${MQ.nUr(idx.length)} حصوں میں تلاش ہو گی`; return; }
    const hits=idx.filter(x=>words.every(w=>x.n.includes(w))); hint.textContent=hits.length?`${MQ.nUr(hits.length)} نتائج${hits.length>40?' (پہلے ۴۰ دکھائے گئے)':''}`:'کچھ نہیں ملا — کوئی اور لفظ لکھ کر دیکھیں';
    res.innerHTML=hits.slice(0,40).map(x=>`<a class="hit" href="${x.href}"><span class="hit-k">${MQ.i(x.k==='v'?'book-half':'chat-left-text')}${x.k==='v'?'آیت':'سوال جواب'}</span><b>${MQ.esc(x.sn)}${x.k==='v'?' · '+MQ.esc(x.t):''}</b><p class="ur">${mark(x.txt,words)}</p></a>`).join(''); };
  inp.addEventListener('input',()=>{ clearTimeout(tm); tm=setTimeout(run,180); }); const q0=MQ.qs('q'); if(q0){ inp.value=q0; run(); } else inp.focus();
};

/* ---------- BOOKMARKS ---------- */
P.bookmarks=async function(){
  MQ.shell({title:'محفوظ آیات',sub:'آپ کی منتخب آیات',back:'index.html'}); const a=app(), chs=await MQ.loadAll(), items=[]; 
  const draw=()=>{ const keys=BM.all(), list=[]; items.length=0;
    keys.forEach(k=>{ const [cid,gid]=k.split('|'), c=chs.find(x=>x.id===cid), g=c&&c.groups.find(x=>x.id===gid), r=MQ.ref(cid); if(g&&r) list.push({g,cid,sn:r.surah.ur}); });
    if(!list.length){ a.innerHTML=`<section class="hero rise"><h1>محفوظ آیات</h1><div class="orn">${MQ.star}</div></section><div class="empty">${MQ.i('bookmark-star')}ابھی کوئی آیت محفوظ نہیں۔<br>کسی بھی آیت کے اوپر ستارے والے بٹن کو دبائیں۔</div>`; return; }
    let h=`<section class="hero rise"><h1>محفوظ آیات</h1><div class="orn">${MQ.star}</div><p>${MQ.nUr(list.length)} آیات</p></section>`;
    list.forEach((x,i)=>{ items.push(x); h+=`<div class="rev-head"><div><b>${MQ.esc(x.sn)}</b></div><a href="section.html?id=${x.cid}&s=content#${x.g.id}">سبق میں دیکھیں ${MQ.i('chevron-left')}</a></div>`+verseHtml(x.g,i,'bm-'+x.g.id,x.cid); });
    a.innerHTML=h; };
  draw();
  a.addEventListener('click',e=>{ if(bmClick(e,(b,on)=>{ if(!on) setTimeout(draw,250); })) return; const sh=e.target.closest('[data-share]'); if(sh){ const it=items[+sh.dataset.share]; shareIt(shareText(it.g,it.sn)); return; }
    const tr=e.target.closest('.v-tr'); if(tr&&document.body.classList.contains('test')) tr.classList.toggle('shown'); });
};

/* ---------- EXAM TEST: random MCQs from all lessons (or one lesson) ---------- */
P.test=async function(){
  MQ.shell({title:'امتحانی ٹیسٹ',sub:'اپنی تیاری جانچیں',back:'index.html'}); const a=app(), chs=await MQ.loadAll(), all=chs.filter(c=>c.mcqs.length);
  const wrongSet=new Set(S.get('wrong',[])), wrongN=all.flatMap(c=>c.mcqs).filter(m=>wrongSet.has(m.q)).length, opts=all.map(c=>{ const r=MQ.ref(c.id); return `<option value="${c.id}">${MQ.esc(r.surah.ur)} · سبق ${MQ.nUr(r.ref.n)} (${MQ.nUr(c.mcqs.length)})</option>`; }).join(''), tot=all.reduce((n,c)=>n+c.mcqs.length,0), bs=S.get('best',{}).all;
  a.innerHTML=`<section class="hero rise"><h1>امتحانی ٹیسٹ</h1><div class="orn">${MQ.star}</div><p>${MQ.nUr(tot)} MCQs میں سے بے ترتیب سوالات</p></section>
    <div class="tcfg rise"><label>کہاں سے؟<select id="t-src"><option value="all">تمام اسباق</option><option value="imp">صرف اہم آیات والے اسباق</option><option value="wrong">میری غلطیاں (${MQ.nUr(wrongN)})</option>${opts}</select></label>
    <div class="tn"><span>کتنے سوال؟</span><div id="t-n">${[10,20,30,50].map((n,i)=>`<button type="button" data-n="${n}" class="${i===1?'on':''}">${MQ.nUr(n)}</button>`).join('')}</div></div>
    <button class="go" id="t-go">ٹیسٹ شروع کریں</button><button class="go alt" id="t-fc">سوال جواب کارڈز دیکھیں</button>${bs!=null?`<small class="tbest">آپ کا بہترین نتیجہ: ${MQ.nUr(bs)}%</small>`:''}</div><div id="t-box"></div>`;
  let n=20; $('#t-n').onclick=e=>{ const b=e.target.closest('button'); if(!b) return; n=+b.dataset.n; $('#t-n').querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b)); };

  $('#t-fc').onclick=()=>{ const v=$('#t-src').value, pool=v==='imp'?all.filter(c=>(c.important||[]).length):(v==='all'||v==='wrong')?chs:chs.filter(c=>c.id===v);
    const cards=MQ.shuffle(pool.flatMap(c=>c.qa)).slice(0,Math.max(n,10)); const box=$('#t-box'); if(!cards.length){ MQ.toast('اس میں سوال جواب موجود نہیں'); return; } let i=0;
    const show=()=>{ box.innerHTML=`<div class="fc-top">${MQ.nUr(i+1)} / ${MQ.nUr(cards.length)}</div><div id="fc-card"></div><div class="fc-nav"><button type="button" id="fc-p" ${i===0?'disabled':''}>${MQ.i('chevron-right')} پچھلا</button><button type="button" id="fc-n" ${i===cards.length-1?'disabled':''}>اگلا ${MQ.i('chevron-left')}</button></div>`;
      $('#fc-card').appendChild(MQ.qaItem(cards[i],i+1)); $('#fc-p').onclick=()=>{ i--; show(); }; $('#fc-n').onclick=()=>{ i++; show(); }; };
    show(); box.scrollIntoView({behavior:'smooth',block:'start'}); };
  $('#t-go').onclick=()=>{ const v=$('#t-src').value; let pool=v==='all'||v==='wrong'?all:v==='imp'?all.filter(c=>(c.important||[]).length):all.filter(c=>c.id===v);
    let src=pool.flatMap(c=>c.mcqs); if(v==='wrong') src=src.filter(m=>wrongSet.has(m.q)); const items=MQ.shuffle(src).slice(0,n); if(!items.length){ MQ.toast(v==='wrong'?'ابھی کوئی غلطی محفوظ نہیں — شاباش!':'اس میں MCQs موجود نہیں'); return; }
    const box=$('#t-box'); box.innerHTML=''; MQ.initQuiz(box,items,v==='all'&&items.length>=20?{key:'all'}:undefined); box.scrollIntoView({behavior:'smooth',block:'start'}); };
};
P.doc=async function(){
  MQ.shell({title:document.body.dataset.title||'مطالعہ قرآن',back:'index.html'});
  const L=(MQ.config&&MQ.config.links)||{}, ig=String(L.instagram||'').replace(/^@/,'').replace(/[^\w.]/g,''), wa=String(L.whatsapp||'').replace(/\D/g,'');
  const c=(MQ.config&&MQ.config.contact)||''; document.querySelectorAll('[data-contact]').forEach(e=>{ const cv=e.querySelector('.cv');
    if(ig){ const a=document.createElement('a'); a.href='https://instagram.com/'+ig; a.target='_blank'; a.rel='noopener noreferrer'; a.textContent='Instagram: @'+ig; a.dir='ltr'; cv.textContent=''; cv.appendChild(a); e.hidden=false; } else if(c){ cv.textContent=c; e.hidden=false; } });
  const bx=document.querySelector('[data-links]'); if(bx&&(ig||wa)){ const mk=(cls,icon,href,label,sub)=>{ const a=document.createElement('a'); a.className='me-link '+cls; a.href=href; a.target='_blank'; a.rel='noopener noreferrer'; a.innerHTML=`${MQ.i(icon)}<span><b>${label}</b><small dir="ltr">${sub}</small></span>`; bx.appendChild(a); };
    if(wa) mk('wa','whatsapp','https://wa.me/'+wa+'?text='+encodeURIComponent('السلام علیکم! مطالعہ قرآن سائٹ کے بارے میں'),'واٹس ایپ پر پیغام بھیجیں','+'+wa.replace(/^92/,'92 ').replace(/^(92 )(\d{3})(\d+)/,'$1$2 $3'));
    if(ig) mk('ig','instagram','https://instagram.com/'+ig,'انسٹاگرام پر فالو کریں','@'+ig); bx.hidden=false; }

  const pf=(MQ.config&&MQ.config.profile)||{}; document.querySelectorAll('[data-prof]').forEach(e=>{ const k=e.dataset.prof;
    if(k==='photo'&&pf.photo){ e.src=pf.photo; e.hidden=false; } else if(k==='where'){ const w=[pf.college,pf.city].filter(Boolean).join(' · '); if(w){ e.textContent=w; e.hidden=false; } } });
  const sr=MQ.registry.surahs; document.querySelectorAll('[data-stat]').forEach(e=>{ e.textContent=e.dataset.stat==='surahs'?sr.length:sr.reduce((n,x)=>n+x.chapters.length,0); });
};
MQ.boot(()=>P[document.body.dataset.page]());
})();
