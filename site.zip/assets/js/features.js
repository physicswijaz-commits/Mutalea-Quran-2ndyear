/* Student-side extras: progress sync across devices, lesson-open counts, expiry / exam reminders,
   offline download, mistake reports and the per-account device limit.
   Loaded by auth.js once an account is approved. Every call is wrapped so a failure never breaks reading. */
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const TS = 'mq_ts', SKIP = { '_ts': 1 };
const jget = (k, d) => { try { return JSON.parse(localStorage.getItem(k) || '') || d; } catch (e) { return d; } };
const jset = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { } };
const dnum = s => { const p = String(s).split('-').map(Number); return Math.round(Date.UTC(p[0], p[1] - 1, p[2]) / 864e5); };

/* ---------- 1. progress sync ---------- */
function startSync(c) {
  const { db, S, u, MQ } = c, ref = S.doc(db, 'progress', u.uid);
  let timer = null, busy = false;
  const stamps = () => jget(TS, {});
  const touch = k => { const t = stamps(); t[k] = Date.now(); jset(TS, t); schedule(); };
  const schedule = () => { clearTimeout(timer); timer = setTimeout(push, 4000); };
  if (MQ.S && !MQ.S.__sync) {
    const set = MQ.S.set, del = MQ.S.del;
    MQ.S.set = function (k, v) { set.call(MQ.S, k, v); touch(k); };
    MQ.S.del = function (k) { del.call(MQ.S, k); touch(k); };
    MQ.S.__sync = 1;
  }
  const local = () => { const d = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.indexOf('mq:') === 0) d[k.slice(3)] = localStorage.getItem(k); } return d; };
  async function push() {
    if (busy || navigator.onLine === false) return; busy = true;
    try {
      const l = local(), t = stamps(), d = {}, tt = {};
      Object.keys(l).forEach(k => { if (SKIP[k]) return; d[k] = l[k]; tt[k] = t[k] || 1; });
      Object.keys(t).forEach(k => { if (!(k in l) && !SKIP[k]) { d[k] = null; tt[k] = t[k]; } });
      await S.setDoc(ref, { d, t: tt, updatedAt: S.serverTimestamp() });
    } catch (e) { }
    busy = false;
  }
  const union = (a, b) => { const o = Object.assign({}, b, a); Object.keys(a).forEach(k => { if (b[k] != null) o[k] = Math.min(+a[k] || 0, +b[k] || 0) || a[k]; }); return o; };
  async function pull() {
    let snap; try { snap = await S.getDoc(ref); } catch (e) { return; }
    if (!snap.exists()) { push(); return; }
    const r = snap.data(), rd = r.d || {}, rt = r.t || {}, lt = stamps(), l = local(); let changed = false;
    Object.keys(rd).forEach(k => {
      const a = rt[k] || 0, b = lt[k] || 0, mine = l[k];
      if (k === 'read' || k === 'opens' || k === 'days') {
        let L = {}, R = {}; try { L = JSON.parse(mine || 'null') || (k === 'days' ? [] : {}); R = JSON.parse(rd[k] || 'null') || (k === 'days' ? [] : {}); } catch (e) { return; }
        let out;
        if (k === 'days') out = Array.from(new Set([].concat(L, R))).sort();
        else if (k === 'opens') { out = Object.assign({}, R); Object.keys(L).forEach(x => { out[x] = Math.max(+L[x] || 0, +R[x] || 0); }); }
        else out = union(L, R);
        const s = JSON.stringify(out); if (s !== mine) { localStorage.setItem('mq:' + k, s); changed = true; }
        lt[k] = Math.max(a, b); return;
      }
      if (a > b) {
        if (rd[k] === null) { if (mine != null) { localStorage.removeItem('mq:' + k); changed = true; } }
        else if (rd[k] !== mine) { localStorage.setItem('mq:' + k, rd[k]); changed = true; }
        lt[k] = a;
      }
    });
    jset(TS, lt);
    if (changed) {
      let done = false; try { done = sessionStorage.getItem('mq_synced') === '1'; sessionStorage.setItem('mq_synced', '1'); } catch (e) { }
      if (!done) { if (MQ.toast) MQ.toast('آپ کی پیش رفت بحال کر دی گئی'); setTimeout(() => location.reload(), 900); return; }
    }
    push();
  }
  /* lesson-open counter (feeds the admin "most opened lessons" list) */
  try { if (/section(\.html)?$/.test(location.pathname) && MQ.qs && MQ.qs('id') && MQ.S) { const o = MQ.S.get('opens', {}), id = MQ.qs('id'); o[id] = (o[id] || 0) + 1; MQ.S.set('opens', o); } } catch (e) { }
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') push(); });
  addEventListener('online', schedule);
  pull();
}

/* ---------- 2. local reminders shown in the bell ---------- */
function reminders(c) {
  const { MQ, expiresAt } = c, list = [], t0 = new Date(); t0.setHours(0, 0, 0, 0); const ts = t0.getTime();
  if (expiresAt) {
    const d = Math.ceil((expiresAt - Date.now()) / 864e5);
    if (d > 0 && d <= 3) list.push({ id: 'exp' + ts, title: 'آپ کی رسائی جلد ختم ہو رہی ہے', body: 'آپ کی رسائی ' + MQ.nUr(d) + ' دن میں ختم ہو جائے گی۔ تجدید کے لیے ایڈمن سے رابطہ کریں۔', type: 'warn', ts, exp: 0 });
  }
  try { const e = MQ.examLeft && MQ.examLeft(); if (e != null && e <= 60) list.push({ id: 'exam' + ts, title: e === 0 ? 'آج امتحان ہے' : 'امتحان میں ' + MQ.nUr(e) + ' دن باقی', body: 'روزانہ تھوڑا تھوڑا دہرائیں۔ اللہ آپ کو کامیاب کرے۔', type: 'info', ts, exp: 0 }); } catch (e) { }
  MQ.localNotes = list; if (MQ.refreshNotes) MQ.refreshNotes();
}

/* ---------- 3. offline download ---------- */
async function offline(c, btn) {
  const keys = c.keys().filter(k => k !== '_rev'); if (!keys.length) { c.MQ.toast('ابھی کوئی مواد دستیاب نہیں'); return; }
  const lab = btn.querySelector('span'), old = lab.textContent; btn.disabled = true; let n = 0, bad = 0;
  for (const k of keys) { try { const d = await c.MQ.fetchDoc(k); if (!d) bad++; } catch (e) { bad++; } lab.textContent = c.MQ.nUr(++n) + ' / ' + c.MQ.nUr(keys.length); }
  btn.disabled = false; lab.textContent = old;
  c.MQ.toast(bad ? 'کچھ اسباق ڈاؤن لوڈ نہیں ہوئے — انٹرنیٹ چیک کریں' : 'سب اسباق آف لائن کے لیے محفوظ ہو گئے', 3200);
}

/* ---------- 4. mistake report ---------- */
function report(c) {
  const old = document.getElementById('mq-rep'); if (old) old.remove();
  const w = document.createElement('div'); w.id = 'mq-rep';
  w.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:rgba(0,0,0,.45);display:flex;align-items:flex-end;justify-content:center';
  w.innerHTML = '<div dir="rtl" style="background:var(--card,#fff);color:var(--text,#222);width:100%;max-width:520px;border-radius:22px 22px 0 0;padding:18px 16px calc(18px + env(safe-area-inset-bottom));font-family:inherit">' +
    '<h3 style="margin:0 0 4px;font-size:1.05rem">غلطی کی اطلاع دیں</h3><p style="margin:0 0 10px;font-size:.85rem;opacity:.7">جس صفحے پر ہیں اس کا حوالہ خود بخود بھیج دیا جائے گا۔</p>' +
    '<textarea id="mq-rep-t" maxlength="500" rows="4" style="width:100%;box-sizing:border-box;border:1px solid var(--border,#ccc);border-radius:12px;padding:10px;font:inherit;background:transparent;color:inherit;resize:vertical" placeholder="کیا غلطی ہے؟"></textarea>' +
    '<div style="display:flex;gap:8px;margin-top:10px"><button id="mq-rep-s" type="button" style="flex:1;border:0;border-radius:12px;padding:12px;font:inherit;font-weight:700;background:var(--primary,#2A7459);color:#fff">بھیجیں</button><button id="mq-rep-x" type="button" style="border:1px solid var(--border,#ccc);border-radius:12px;padding:12px 16px;font:inherit;background:transparent;color:inherit">بند کریں</button></div></div>';
  document.body.appendChild(w);
  const close = () => w.remove(); w.onclick = e => { if (e.target === w) close(); }; document.getElementById('mq-rep-x').onclick = close;
  document.getElementById('mq-rep-s').onclick = async function () {
    const m = document.getElementById('mq-rep-t').value.trim(); if (m.length < 3) { c.MQ.toast('پہلے غلطی لکھیں'); return; }
    this.disabled = true;
    try {
      await c.S.addDoc(c.S.collection(c.db, 'feedback'), { uid: c.u.uid, name: c.name || '', email: c.u.email || '', page: location.pathname.split('/').pop() + location.search, msg: m, status: 'new', createdAt: c.S.serverTimestamp() });
      close(); c.MQ.toast('شکریہ! آپ کی اطلاع بھیج دی گئی');
    } catch (e) { this.disabled = false; c.MQ.toast('نہیں بھیجا جا سکا — انٹرنیٹ چیک کریں'); }
  };
}

/* ---------- 5. device limit (soft: enforced by the app, not by the server) ---------- */
async function devices(c) {
  const limit = +(c.site() || {}).deviceLimit || 0; let id = ''; try { id = localStorage.getItem('mq_dev') || ''; if (!id) { id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36); localStorage.setItem('mq_dev', id); } } catch (e) { return true; }
  const col = c.S.collection(c.db, 'users', c.u.uid, 'devices'), me = c.S.doc(col, id);
  try {
    const own = await c.S.getDoc(me);
    if (own.exists()) { c.S.updateDoc(me, { last: c.S.serverTimestamp() }).catch(() => { }); return true; }
    if (limit > 0) { const all = await c.S.getDocs(col); if (all.size >= limit) return false; }
    await c.S.setDoc(me, { ua: (navigator.userAgent || '').slice(0, 120), first: c.S.serverTimestamp(), last: c.S.serverTimestamp() });
  } catch (e) { }
  return true;
}

export function init(c) {
  try { reminders(c); } catch (e) { }
  if (!c.isAdmin) { try { startSync(c); } catch (e) { } }
  return { offline: btn => offline(c, btn), report: () => report(c), devices: () => devices(c) };
}
