/* Keeps each public site's saved progress separate. All the sites share one web address, so without this the Urdu and
   English sites would read and overwrite each other's bookmarks, vocabulary, streaks and read marks.
   Needs window.MQ_NS ("ur" or "en") and must load before the site scripts. */
(function(){
var NS=window.MQ_NS; if(!NS||window.__nsd) return; window.__nsd=1;
var P=NS+':', SP=Storage.prototype, g=SP.getItem, s=SP.setItem, r=SP.removeItem;
var keep=function(x){ return x.indexOf('mq_')===0||x.indexOf('mq:')===0||x.indexOf('ur:')===0||x.indexOf('en:')===0||x.indexOf('firebase')===0; };
var map=function(x){ x=String(x); return keep(x)?x:P+x; };
try{
  if(!g.call(localStorage,'mq_ns_'+NS)){
    var ks=[]; for(var i=0;i<localStorage.length;i++) ks.push(localStorage.key(i));
    ks.forEach(function(k){ if(k&&!keep(k)&&g.call(localStorage,P+k)===null) s.call(localStorage,P+k,g.call(localStorage,k)); });
    s.call(localStorage,'mq_ns_'+NS,'1');
  }
}catch(e){}
SP.getItem=function(x){ return this===localStorage?g.call(this,map(x)):g.call(this,x); };
SP.setItem=function(x,v){ if(this!==localStorage) return s.call(this,x,v); var k=map(x); s.call(this,k,v); try{ window.__mqTouch&&window.__mqTouch(k); }catch(e){} };
SP.removeItem=function(x){ if(this!==localStorage) return r.call(this,x); var k=map(x); r.call(this,k); try{ window.__mqTouch&&window.__mqTouch(k); }catch(e){} };
})();
