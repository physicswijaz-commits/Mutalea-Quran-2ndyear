# Login version
- Students sign in with Google; the owner approves them from admin.html.
- Lessons and exercises are no longer in the site files; they load from Firebase after approval.
- Privacy page updated for sign-in. Cache: mq-login-v1.
